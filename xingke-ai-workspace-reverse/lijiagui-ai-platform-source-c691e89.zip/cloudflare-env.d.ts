declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    BUCKET?: R2Bucket;
    BIGMODEL_API_KEY?: string;
    INITIAL_ADMIN_PASSWORD?: string;
    ADMIN_RECOVERY_TOKEN?: string;
    SESSION_PEPPER?: string;
    SCHEDULER_TOKEN?: string;
    SCHEDULER_AUTOMATION_ENABLED?: string;
  }
}
