import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const files = execFileSync("git", ["ls-files"], { encoding: "utf8" }).split(/\r?\n/u).filter(Boolean);
const rules = [
  ["BigModel key", /\b[a-f0-9]{32}\.[A-Za-z0-9_-]{10,}\b/gu],
  ["literal bearer token", /Bearer\s+(?!\$\{)[A-Za-z0-9._~-]{20,}/gu],
  ["private key", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/gu],
  ["populated dotenv secret", /^(?:BIGMODEL_API_KEY|INITIAL_ADMIN_PASSWORD|ADMIN_RECOVERY_TOKEN|SESSION_PEPPER|SCHEDULER_TOKEN)=\S+/gmu],
];
const hits = [];
for (const file of files) {
  if (/\.(?:png|jpe?g|gif|webp|woff2?|ico|pdf)$/iu.test(file)) continue;
  let text;
  try { text = readFileSync(file, "utf8"); } catch { continue; }
  for (const [name, pattern] of rules) { pattern.lastIndex = 0; if (pattern.test(text)) hits.push({ file, rule: name }); }
}
if (hits.length) { for (const hit of hits) console.error(`${hit.file}: ${hit.rule}`); process.exit(1); }
console.log(`secret-scan: clean (${files.length} tracked files)`);
