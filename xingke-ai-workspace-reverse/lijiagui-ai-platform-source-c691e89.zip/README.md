# 李家贵AI中台（重建版）

面向培训与团队协作的多账号 AI 工作台。管理员创建学员账号；每个用户拥有隔离的对话、文件、应用和定时任务，模型调用只在服务端完成。

## 已实现

- `admin` 初始化、首次强制改密、一次性恢复码、登录锁定与会话撤销。
- 新建任务、智谱 GLM-5.3-Flash SSE 流式对话、历史会话与日用量配额。
- 专家、技能、两个真实连接器（BigModel、云盘文件）和版本固定应用。
- D1 元数据 + R2 文件对象，上传、预览、下载、文件夹和 30 天回收站。
- 手动/自动定时任务、租约防重复执行、管理员设置与审计日志。
- 桌面三栏布局与移动端导航/文件抽屉。

## 架构

- Vinext、React、TypeScript
- Cloudflare Worker、D1、R2
- Drizzle ORM
- 智谱 BigModel 对话补全 API
- Vitest + Testing Library

## 本地检查

```bash
npm test -- --run
npm run lint
npm run build
node scripts/secret-scan.mjs
```

运行时变量只在托管环境或本地进程环境中设置，不能写入仓库。名称见 `.env.example`。

## 安全边界

- PBKDF2-HMAC-SHA256，100,000 次迭代（Cloudflare Workers 支持上限），独立随机盐。
- D1 只保存会话令牌哈希；Cookie 使用 `HttpOnly`、`Secure`、`SameSite=Lax`。
- 用户数据查询必须带 `owner_user_id`；R2 对象键由服务端生成并包含用户 ID。
- 模型 Key、初始化密码、恢复码、会话 Pepper 和调度 Token 均为托管秘密。
- 不接受任意外部连接器 URL；文件交给模型前要求明确确认。

## 数据与限制

- 默认每用户每天 50 次模型请求、200,000 tokens。
- 默认 5 个启用中的定时任务、每天 20 次计划执行。
- 默认每用户 200 MB 云盘、单文件 20 MB。
- 文件软删除 30 天；审计 180 天、日级用量 365 天为保留策略目标。
- 第一版不含计费、短信/邮件找回、开放注册、组织多租户或 Office 原生编辑。
