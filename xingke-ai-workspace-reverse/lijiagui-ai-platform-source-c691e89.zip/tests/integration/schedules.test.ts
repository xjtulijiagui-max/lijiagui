import { describe, expect, it } from "vitest";
import { assertScheduleDailyQuota, SCHEDULE_EXECUTION_TIMEOUT_MS, SCHEDULE_LEASE_MS, shouldClaimSchedule, verifySchedulerHeaders } from "../../server/domain/lease";

describe("scheduler safety", () => {
  it("requires managed service access and the independent token", () => {
    expect(() => verifySchedulerHeaders(new Headers({ authorization: "Bearer token" }), "token")).toThrow(/service access/i);
    expect(() => verifySchedulerHeaders(new Headers({ "x-scheduler-service": "sites-managed", authorization: "Bearer wrong" }), "token")).toThrow(/token/i);
    expect(() => verifySchedulerHeaders(new Headers({ "x-scheduler-service": "sites-managed", authorization: "Bearer token" }), "token")).not.toThrow();
  });
  it("does not claim disabled or actively leased schedules and reclaims expired leases", () => {
    const now = new Date("2026-11-27T00:00:00Z");
    expect(shouldClaimSchedule({ enabled: false, nextRunAt: now, leaseExpiresAt: null }, now)).toBe(false);
    expect(shouldClaimSchedule({ enabled: true, nextRunAt: now, leaseExpiresAt: new Date(now.getTime() + 60_000) }, now)).toBe(false);
    expect(shouldClaimSchedule({ enabled: true, nextRunAt: now, leaseExpiresAt: new Date(now.getTime() - 1) }, now)).toBe(true);
  });
  it("limits scheduled runs to twenty per user per day", () => {
    expect(() => assertScheduleDailyQuota(19)).not.toThrow();
    expect(() => assertScheduleDailyQuota(20)).toThrow(/20/u);
    expect(() => assertScheduleDailyQuota(2, 2)).toThrow(/2/u);
  });
  it("bounds execution below the lease duration so a live run cannot be reclaimed", () => {
    expect(SCHEDULE_EXECUTION_TIMEOUT_MS).toBeLessThan(SCHEDULE_LEASE_MS);
  });
});
