import { describe, expect, it } from "vitest";

import { shouldSeedInitialAdmin } from "../../server/domain/user-policy";
import { buildSessionCookies } from "../../server/auth/cookie";
import { decideLoginLock } from "../../server/auth/login-rate-limit";
import { recoveryTokenCanBeUsed } from "../../server/auth/recovery";
import { canAccessBeforePasswordChange } from "../../server/auth/password-change-policy";

describe("authentication policy", () => {
  it("seeds admin only for an empty database with a configured secret", () => {
    expect(shouldSeedInitialAdmin(0, true)).toBe(true);
    expect(shouldSeedInitialAdmin(1, true)).toBe(false);
    expect(shouldSeedInitialAdmin(0, false)).toBe(false);
  });

  it("creates hardened session and CSRF cookies", () => {
    const cookies = buildSessionCookies("session-token", "csrf-token", new Date("2026-12-03T00:00:00Z"));
    expect(cookies.session).toContain("__Host-xk_session=session-token");
    expect(cookies.session).toContain("HttpOnly");
    expect(cookies.session).toContain("Secure");
    expect(cookies.session).toContain("SameSite=Lax");
    expect(cookies.csrf).not.toContain("HttpOnly");
  });

  it("locks after five recent failures for ten minutes", () => {
    const now = Date.parse("2026-11-26T12:00:00Z");
    const failures = Array.from({ length: 5 }, (_, index) => now - index * 30_000);
    expect(decideLoginLock(failures, now).locked).toBe(true);
    expect(decideLoginLock(failures, now + 10 * 60_000 + 1).locked).toBe(false);
  });

  it("allows an unused recovery token once", () => {
    expect(recoveryTokenCanBeUsed("same-hash", null)).toBe(true);
    expect(recoveryTokenCanBeUsed("same-hash", "same-hash")).toBe(false);
  });

  it("allows only password-maintenance APIs before the forced password change", () => {
    expect(canAccessBeforePasswordChange("/api/auth/me")).toBe(true);
    expect(canAccessBeforePasswordChange("/api/auth/change-password")).toBe(true);
    expect(canAccessBeforePasswordChange("/api/auth/logout")).toBe(true);
    expect(canAccessBeforePasswordChange("/api/chat/stream")).toBe(false);
    expect(canAccessBeforePasswordChange("/api/admin/users")).toBe(false);
  });
});
