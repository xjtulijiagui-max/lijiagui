import { describe, expect, it } from "vitest";

import { assertAdminRole } from "../../server/auth/authorization";
import { mustRevokeSessionsForUserMutation, normalizeManagedRole, shouldRequirePasswordChange, validateNewUsername } from "../../server/domain/user-policy";

describe("admin user management policy", () => {
  it("rejects members from admin operations", () => {
    expect(() => assertAdminRole({ role: "member" })).toThrowError(/forbidden/i);
    expect(() => assertAdminRole({ role: "admin" })).not.toThrow();
  });

  it("requires session revocation after disable or password reset", () => {
    expect(mustRevokeSessionsForUserMutation("disable")).toBe(true);
    expect(mustRevokeSessionsForUserMutation("reset-password")).toBe(true);
    expect(mustRevokeSessionsForUserMutation("rename")).toBe(false);
  });

  it("accepts constrained account names and rejects reserved names", () => {
    expect(validateNewUsername("student_01")).toBe("student_01");
    expect(validateNewUsername("13800138000")).toBe("13800138000");
    expect(() => validateNewUsername("admin")).toThrowError(/reserved/i);
    expect(() => validateNewUsername("a b")).toThrowError(/username/i);
  });

  it("lets an administrator assign a ready-to-use password", () => {
    expect(shouldRequirePasswordChange(true)).toBe(false);
    expect(shouldRequirePasswordChange(false)).toBe(true);
  });

  it("rejects role values outside the runtime allowlist", () => {
    expect(normalizeManagedRole(undefined)).toBe("member");
    expect(normalizeManagedRole("admin")).toBe("admin");
    expect(() => normalizeManagedRole("superadmin")).toThrowError(/role/i);
  });
});
