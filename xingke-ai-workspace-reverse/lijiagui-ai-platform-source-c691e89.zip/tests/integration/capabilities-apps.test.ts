import { describe, expect, it } from "vitest";
import { composeSystemPrompt, isCapabilitySelectable, isVisibleToUser } from "../../server/domain/capabilities";
import { applyAppPromptTemplate, assertCanPublishPublicApp, isAllowedAppModel, selectInstalledVersion } from "../../server/domain/apps";

describe("capabilities and apps", () => {
  it("composes scene then expert then skills", () => {
    const prompt = composeSystemPrompt("SCENE", { systemPrompt: "EXPERT" }, [{ instructions: "SKILL-1" }, { instructions: "SKILL-2" }], ["APP"]);
    expect(prompt.indexOf("SCENE")).toBeLessThan(prompt.indexOf("EXPERT"));
    expect(prompt.indexOf("EXPERT")).toBeLessThan(prompt.indexOf("SKILL-1"));
    expect(prompt.indexOf("SKILL-1")).toBeLessThan(prompt.indexOf("SKILL-2"));
    expect(prompt.indexOf("SKILL-2")).toBeLessThan(prompt.indexOf("APP"));
  });
  it("excludes disabled and other users' private capabilities", () => {
    expect(isCapabilitySelectable({ enabled: false })).toBe(false);
    expect(isVisibleToUser({ visibility: "public", ownerUserId: null }, "u1")).toBe(true);
    expect(isVisibleToUser({ visibility: "private", ownerUserId: "u1" }, "u1")).toBe(true);
    expect(isVisibleToUser({ visibility: "private", ownerUserId: "u2" }, "u1")).toBe(false);
  });
  it("pins installs to a version and restricts public publishing", () => {
    expect(selectInstalledVersion("version-2")).toBe("version-2");
    expect(() => assertCanPublishPublicApp("member")).toThrow(/admin/i);
    expect(() => assertCanPublishPublicApp("admin")).not.toThrow();
    expect(isAllowedAppModel("glm-5.3-flash")).toBe(true);
    expect(isAllowedAppModel("unapproved-model")).toBe(false);
  });
  it("applies an app prompt template to direct and scheduled input", () => {
    expect(applyAppPromptTemplate("请按模板处理：{{input}}", "季度复盘")).toBe("请按模板处理：季度复盘");
    expect(applyAppPromptTemplate("请按模板处理", "季度复盘")).toBe("请按模板处理\n\n用户输入：季度复盘");
  });
});
