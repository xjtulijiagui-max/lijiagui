import { describe, expect, it } from "vitest";

const baseUrl = process.env.E2E_BASE_URL;
const adminPassword = process.env.E2E_ADMIN_PASSWORD;
const nextAdminPassword = process.env.E2E_NEXT_ADMIN_PASSWORD;

async function login(password: string, username = "admin") {
  const response = await fetch(`${baseUrl}/api/auth/login`, { method: "POST", headers: { "content-type": "application/json", origin: baseUrl! }, body: JSON.stringify({ username, password }) });
  expect(response.status).toBe(200);
  const setCookies = response.headers.getSetCookie();
  const cookie = setCookies.map((value) => value.split(";", 1)[0]).join("; ");
  const csrfToken = decodeURIComponent(setCookies.find((value) => value.startsWith("xk_csrf="))!.split(";", 1)[0].slice("xk_csrf=".length));
  return { response, headers: { cookie, origin: baseUrl!, "x-csrf-token": csrfToken } };
}

describe.skipIf(!baseUrl || !adminPassword)("published API flow", () => {
  it("logs in the seeded admin and exercises the production model and file path", async () => {
    const anonymous = await fetch(`${baseUrl}/api/conversations`);
    expect(anonymous.status).toBe(401);
    let authenticated = await login(adminPassword!);
    expect(authenticated.response.headers.get("set-cookie")).toContain("__Host-xk_session");

    const me = await fetch(`${baseUrl}/api/auth/me`, { headers: authenticated.headers });
    expect(me.status).toBe(200);
    const user = (await me.json() as { user: { username: string; role: string; mustChangePassword: boolean } }).user;
    expect(user).toMatchObject({ username: "admin", role: "admin" });
    if (user.mustChangePassword) {
      expect(nextAdminPassword).toBeTruthy();
      const blocked = await fetch(`${baseUrl}/api/chat/stream`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ content: "blocked" }) });
      expect(blocked.status).toBe(403);
      const changed = await fetch(`${baseUrl}/api/auth/change-password`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ currentPassword: adminPassword, nextPassword: nextAdminPassword }) });
      expect(changed.status).toBe(200);
      authenticated = await login(nextAdminPassword!);
    }

    const suffix = Date.now().toString().slice(-8);
    const phone = `139${suffix}`;
    const memberPassword = `${crypto.randomUUID()}Aa1!`;
    const createdUser = await fetch(`${baseUrl}/api/admin/users`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ phone, password: memberPassword, displayName: "验收学员", role: "member" }) });
    expect(createdUser.status).toBe(201);
    const createdUserBody = await createdUser.json() as { id: string };
    const member = await login(memberPassword, phone);
    const memberMe = await fetch(`${baseUrl}/api/auth/me`, { headers: member.headers });
    expect(memberMe.status).toBe(200);
    expect((await memberMe.json() as { user: { mustChangePassword: boolean } }).user.mustChangePassword).toBe(false);

    const expert = await fetch(`${baseUrl}/api/experts`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ name: `验收专家${suffix}`, description: "端到端验收", systemPrompt: "回答末尾必须加上【专家已生效】", visibility: "public" }) });
    expect(expert.status).toBe(201);
    const expertId = (await expert.json() as { id: string }).id;
    const skill = await fetch(`${baseUrl}/api/skills`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ name: `验收技能${suffix}`, description: "端到端验收", instructions: "回答末尾必须加上【技能已生效】", visibility: "public" }) });
    expect(skill.status).toBe(201);
    const skillId = (await skill.json() as { id: string }).id;
    const app = await fetch(`${baseUrl}/api/apps`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ name: `验收应用${suffix}`, description: "端到端验收", visibility: "public", expertId, skillIds: [skillId], promptTemplate: "请按验收规则处理：{{input}}" }) });
    expect(app.status).toBe(201);
    const appBody = await app.json() as { version: { id: string } };

    const memberApps = await fetch(`${baseUrl}/api/apps`, { headers: member.headers });
    expect(memberApps.status).toBe(200);
    expect((await memberApps.json() as { apps: Array<{ name: string }> }).apps.some((item) => item.name === `验收应用${suffix}`)).toBe(true);
    const appChat = await fetch(`${baseUrl}/api/chat/stream`, { method: "POST", headers: { ...member.headers, "content-type": "application/json" }, body: JSON.stringify({ content: "只回复：链路正常", appVersionId: appBody.version.id }) });
    expect(appChat.status).toBe(200);
    const appStream = await appChat.text();
    expect(appStream).toContain('"type":"meta"'); expect(appStream).toContain('"type":"content"'); expect(appStream).toContain('"type":"done"');

    const schedule = await fetch(`${baseUrl}/api/schedules`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ name: `验收定时应用${suffix}`, prompt: "只回复：定时正常", appVersionId: appBody.version.id, frequency: "daily", enabled: false }) });
    expect(schedule.status).toBe(201);
    const scheduleId = (await schedule.json() as { schedule: { id: string } }).schedule.id;
    const scheduleRun = await fetch(`${baseUrl}/api/schedules/${scheduleId}/run`, { method: "POST", headers: { ...authenticated.headers, "content-type": "application/json" }, body: "{}" });
    expect(scheduleRun.status).toBe(200);
    expect((await scheduleRun.json() as { run: { status: string; conversationId: string } }).run).toMatchObject({ status: "succeeded" });

    const chat = await fetch(`${baseUrl}/api/chat/stream`, {
      method: "POST",
      headers: { ...authenticated.headers, "content-type": "application/json" },
      body: JSON.stringify({ content: "只回复两个字：正常", model: "glm-5.3-flash" }),
    });
    expect(chat.status).toBe(200);
    const stream = await chat.text();
    expect(stream).toContain('"type":"meta"');
    expect(stream).toContain('"type":"content"');
    expect(stream).toContain('"type":"done"');

    const upload = new FormData();
    upload.append("file", new Blob(["xingke-production-smoke"], { type: "text/plain" }), "production-smoke.txt");
    const stored = await fetch(`${baseUrl}/api/files`, { method: "POST", headers: authenticated.headers, body: upload });
    expect(stored.status).toBe(201);
    const storedBody = await stored.json() as { file: { id: string } };
    const preview = await fetch(`${baseUrl}/api/files/${storedBody.file.id}?preview=1`, { headers: authenticated.headers });
    expect(preview.status).toBe(200);
    expect(await preview.text()).toBe("xingke-production-smoke");
    const removed = await fetch(`${baseUrl}/api/files/${storedBody.file.id}`, { method: "DELETE", headers: authenticated.headers });
    expect(removed.status).toBe(204);
    const disabled = await fetch(`${baseUrl}/api/admin/users/${createdUserBody.id}`, { method: "PATCH", headers: { ...authenticated.headers, "content-type": "application/json" }, body: JSON.stringify({ action: "disable" }) });
    expect(disabled.status).toBe(200);
  }, 120_000);
});
