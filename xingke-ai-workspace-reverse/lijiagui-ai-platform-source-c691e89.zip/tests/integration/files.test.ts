import { describe, expect, it } from "vitest";
import { assertOwnedFile, assertOwnedFolder, buildOwnedObjectKey, requireAttachmentConfirmation } from "../../server/domain/files";

describe("owned files", () => {
  it("uses a server generated user-scoped object key", () => {
    const key = buildOwnedObjectKey("user-1", "report.pdf", "fixed-id");
    expect(key).toBe("users/user-1/fixed-id/report.pdf");
    expect(key).not.toContain("..");
  });
  it("conceals another user's file and soft-deleted files", () => {
    expect(() => assertOwnedFile({ ownerUserId: "u2", deletedAt: null }, "u1")).toThrow(/not found/i);
    expect(() => assertOwnedFile({ ownerUserId: "u1", deletedAt: new Date() }, "u1")).toThrow(/not found/i);
  });
  it("requires explicit confirmation before model attachment resolution", () => {
    expect(() => requireAttachmentConfirmation(false, ["f1"])).toThrow(/confirm/i);
    expect(() => requireAttachmentConfirmation(true, ["f1"])).not.toThrow();
  });
  it("rejects cross-user and deleted destination folders", () => {
    expect(() => assertOwnedFolder({ ownerUserId: "u2", deletedAt: null }, "u1")).toThrow();
    expect(() => assertOwnedFolder({ ownerUserId: "u1", deletedAt: new Date() }, "u1")).toThrow();
    expect(() => assertOwnedFolder({ ownerUserId: "u1", deletedAt: null }, "u1")).not.toThrow();
  });
});
