import { describe, expect, it } from "vitest";
import { assertConversationOwner } from "../../server/domain/conversations";
import { assertQuotaAvailable } from "../../server/domain/quota";
import { mapBigModelHttpError } from "../../server/bigmodel/errors";

describe("chat boundaries", () => {
  it("conceals another user's conversation", () => expect(() => assertConversationOwner({ ownerUserId: "a" }, "b")).toThrowError(/not found/i));
  it("blocks exhausted request and token quotas", () => {
    expect(() => assertQuotaAvailable({ requestCount: 50, totalTokens: 1 })).toThrowError(/请求次数/u);
    expect(() => assertQuotaAvailable({ requestCount: 1, totalTokens: 200_000 })).toThrowError(/token/i);
  });
  it("maps rate limit and balance failures", () => {
    expect(mapBigModelHttpError(429, "").code).toBe("rate_limited");
    expect(mapBigModelHttpError(400, "insufficient balance").code).toBe("insufficient_balance");
  });
});
