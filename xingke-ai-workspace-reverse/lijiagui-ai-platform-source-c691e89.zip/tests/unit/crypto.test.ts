import { describe, expect, it } from "vitest";

import { hashPassword, verifyPassword } from "../../server/auth/crypto";

describe("password hashing", () => {
  it("uses a fresh salt and the Cloudflare-compatible PBKDF2 cost", async () => {
    const first = await hashPassword("Correct-Horse-Battery-Staple");
    const second = await hashPassword("Correct-Horse-Battery-Staple");

    expect(first.algorithm).toBe("PBKDF2-SHA256");
    expect(first.iterations).toBe(100_000);
    expect(first.salt).not.toBe(second.salt);
    expect(first.hash).not.toBe(second.hash);
  });

  it("accepts the correct password and rejects an incorrect password", async () => {
    const digest = await hashPassword("A-Strong-Password-2026!");

    await expect(verifyPassword("A-Strong-Password-2026!", digest)).resolves.toBe(true);
    await expect(verifyPassword("not-the-password", digest)).resolves.toBe(false);
  });

  it("never embeds the plaintext password in the digest", async () => {
    const password = "Never-Store-Me-In-Plaintext";
    const digest = await hashPassword(password);

    expect(JSON.stringify(digest)).not.toContain(password);
  });
});
