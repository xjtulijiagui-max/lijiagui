// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { WorkspaceShell } from "../../components/workspace/workspace-shell";

const member = { id: "u1", username: "member", displayName: "测试学员", role: "member" as const, mustChangePassword: false };
afterEach(cleanup);
beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
    const url = String(input);
    const payload = url.includes("/api/apps") ? { apps: [] } : { conversations: [] };
    return new Response(JSON.stringify(payload), { status: 200, headers: { "content-type": "application/json" } });
  }));
});
afterEach(() => vi.unstubAllGlobals());

describe("workspace navigation", () => {
  it("renders the five member modules and conditionally exposes admin", () => {
    const { rerender } = render(<WorkspaceShell user={member} initialModule="task" />);
    for (const label of ["新建任务", "专家·技能·连接器", "应用", "定时任务", "云盘"]) expect(screen.getByText(label)).toBeTruthy();
    expect(screen.getByText("李家贵AI中台")).toBeTruthy();
    expect(screen.queryByText("用户管理")).toBeNull();
    rerender(<WorkspaceShell user={{ ...member, role: "admin" }} initialModule="task" />);
    expect(screen.getByText("用户管理")).toBeTruthy();
  });

  it("synchronizes the active module to the URL", () => {
    render(<WorkspaceShell user={member} initialModule="task" />);
    fireEvent.click(screen.getByRole("button", { name: /应用/u }));
    expect(new URL(window.location.href).searchParams.get("module")).toBe("apps");
  });

  it("exposes narrow-screen navigation and file drawer controls", () => {
    render(<WorkspaceShell user={member} initialModule="task" />);
    expect(screen.getByRole("button", { name: "打开导航" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "打开文件面板" })).toBeTruthy();
  });
});
