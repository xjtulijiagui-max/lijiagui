// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { AppsView } from "../../components/workspace/apps-view";
import { CapabilitiesView } from "../../components/workspace/capabilities-view";
import { TaskComposer } from "../../components/workspace/task-composer";

afterEach(cleanup);
beforeEach(() => {
  vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
    const url = String(input);
    if (url.includes("/api/experts")) return new Response(JSON.stringify({ experts: [{ id: "e1", name: "经营顾问", description: "经营分析", visibility: "public" }], connectors: [] }), { status: 200 });
    if (url.includes("/api/skills")) return new Response(JSON.stringify({ skills: [{ id: "s1", name: "事实核验", description: "核验事实", visibility: "public" }] }), { status: 200 });
    if (url.includes("/api/apps")) return new Response(JSON.stringify({ apps: [{ id: "a1", name: "复盘应用", description: "自动复盘", visibility: "private", currentVersionId: "v1", ownerUserId: "u1" }] }), { status: 200 });
    return new Response("{}", { status: 200 });
  }));
});
afterEach(() => vi.unstubAllGlobals());

describe("capability actions", () => {
  it("launches a selected expert or skill from the capability center", async () => {
    const onUse = vi.fn();
    render(<CapabilitiesView role="admin" onUse={onUse} />);
    await screen.findByText("经营顾问");
    fireEvent.click(screen.getByRole("button", { name: "使用经营顾问" }));
    expect(onUse).toHaveBeenCalledWith({ expertId: "e1", expertName: "经营顾问" });
    fireEvent.click(screen.getByRole("button", { name: "技能" }));
    await screen.findByText("事实核验");
    fireEvent.click(screen.getByRole("button", { name: "使用事实核验" }));
    expect(onUse).toHaveBeenCalledWith({ skillIds: ["s1"], skillNames: ["事实核验"] });
  });

  it("launches the current application version into a task", async () => {
    const onUseApp = vi.fn();
    render(<AppsView role="admin" onUseApp={onUseApp} />);
    await screen.findByText("复盘应用");
    fireEvent.click(screen.getByRole("button", { name: "使用复盘应用" }));
    expect(onUseApp).toHaveBeenCalledWith("v1", "复盘应用");
  });

  it("selects experts and skills inside the task composer", async () => {
    const onExpertChange = vi.fn(); const onSkillToggle = vi.fn();
    render(<TaskComposer busy={false} onSend={vi.fn()} onStop={vi.fn()} experts={[{ id: "e1", name: "经营顾问" }]} skills={[{ id: "s1", name: "事实核验" }]} selectedSkillIds={[]} onExpertChange={onExpertChange} onSkillToggle={onSkillToggle} />);
    fireEvent.click(screen.getByRole("button", { name: "专家" }));
    fireEvent.click(screen.getByRole("button", { name: "选择经营顾问" }));
    expect(onExpertChange).toHaveBeenCalledWith("e1");
    fireEvent.click(screen.getByRole("button", { name: "技能" }));
    fireEvent.click(screen.getByRole("button", { name: "选择事实核验" }));
    expect(onSkillToggle).toHaveBeenCalledWith("s1");
    await waitFor(() => expect(screen.getByLabelText("任务内容")).toBeTruthy());
  });
});
