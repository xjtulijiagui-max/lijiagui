import { describe, expect, it } from "vitest";
import { trimConversationContext } from "../../server/bigmodel/context";

describe("conversation context", () => {
  it("keeps the system message and newest complete turns within the character limit", () => {
    const messages = [{ role: "system" as const, content: "system" }, ...Array.from({ length: 8 }, (_, i) => ({ role: (i % 2 ? "assistant" : "user") as "user" | "assistant", content: `${i}`.repeat(10) }))];
    const trimmed = trimConversationContext(messages, 42);
    expect(trimmed[0].content).toBe("system");
    expect(trimmed.at(-1)?.content).toBe("7".repeat(10));
    expect(trimmed.reduce((sum, item) => sum + item.content.length, 0)).toBeLessThanOrEqual(42);
  });
});
