import { describe, expect, it } from "vitest";
import { cleanupCutoff, validateStorageQuota, validateUpload } from "../../server/domain/file-policy";

describe("file policy", () => {
  it("rejects traversal, absolute paths and executable double extensions", () => {
    for (const name of ["../secret.txt", "/etc/passwd", "C:\\secret.txt", "notes.pdf.exe"]) expect(validateUpload({ name, type: "text/plain", size: 100 }).ok).toBe(false);
  });
  it("rejects executable MIME spoofing and files over 20 MB", () => {
    expect(validateUpload({ name: "photo.png", type: "application/x-msdownload", size: 100 }).ok).toBe(false);
    expect(validateUpload({ name: "large.pdf", type: "application/pdf", size: 20 * 1024 * 1024 + 1 }).ok).toBe(false);
  });
  it("enforces 200 MB user storage and computes 30 day cleanup", () => {
    expect(() => validateStorageQuota(200 * 1024 * 1024, 1)).toThrow(/storage/i);
    expect(cleanupCutoff(new Date("2026-11-27T00:00:00Z")).toISOString()).toBe("2026-10-28T00:00:00.000Z");
  });
  it("honors configured per-file and storage limits", () => {
    expect(validateUpload({ name: "small.txt", type: "text/plain", size: 2 * 1024 * 1024 }, 1024 * 1024).ok).toBe(false);
    expect(() => validateStorageQuota(9 * 1024 * 1024, 2 * 1024 * 1024, 10 * 1024 * 1024)).toThrow(/storage/i);
  });
});
