import { describe, expect, it } from "vitest";
import { DEFAULT_WORKSPACE_SETTINGS, normalizeWorkspaceSettings } from "../../server/domain/workspace-settings";

describe("workspace settings", () => {
  it("accepts bounded integer overrides and keeps the model allowlist fixed", () => {
    const settings = normalizeWorkspaceSettings({ dailyRequestQuota: 88, maxFileMb: 25, userStorageMb: 500, allowedModels: ["other"] });
    expect(settings.dailyRequestQuota).toBe(88);
    expect(settings.maxFileMb).toBe(25);
    expect(settings.allowedModels).toEqual(["glm-5.3-flash"]);
  });
  it("rejects invalid types, ranges and file limits above storage", () => {
    expect(() => normalizeWorkspaceSettings({ dailyRequestQuota: "88" })).toThrow();
    expect(() => normalizeWorkspaceSettings({ maxOutputTokens: 100_000 })).toThrow();
    expect(() => normalizeWorkspaceSettings({ maxFileMb: 20, userStorageMb: 10 })).toThrow();
  });
  it("keeps production defaults stable", () => {
    expect(DEFAULT_WORKSPACE_SETTINGS.dailyTokenQuota).toBe(200_000);
    expect(DEFAULT_WORKSPACE_SETTINGS.dailyScheduleRuns).toBe(20);
  });
});
