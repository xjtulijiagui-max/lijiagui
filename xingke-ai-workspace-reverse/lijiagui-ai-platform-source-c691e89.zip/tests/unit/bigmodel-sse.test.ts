import { describe, expect, it } from "vitest";

import { parseBigModelSse } from "../../server/bigmodel/sse";

function stream(text: string) { return new ReadableStream<Uint8Array>({ start(controller) { controller.enqueue(new TextEncoder().encode(text)); controller.close(); } }); }

describe("BigModel SSE parser", () => {
  it("parses content, ignores empty deltas, emits usage and stops at DONE", async () => {
    const source = stream('data: {"choices":[{"delta":{"content":"你"}}]}\n\ndata: {"choices":[{"delta":{}}]}\n\ndata: {"usage":{"prompt_tokens":4,"completion_tokens":2},"choices":[]}\n\ndata: [DONE]\n\n');
    const events = [];
    for await (const event of parseBigModelSse(source)) events.push(event);
    expect(events).toEqual([{ type: "content", content: "你" }, { type: "usage", promptTokens: 4, completionTokens: 2 }, { type: "done" }]);
  });

  it("maps upstream error events", async () => {
    const source = stream('data: {"error":{"code":"1210","message":"insufficient balance"}}\n\n');
    await expect(async () => { for await (const _event of parseBigModelSse(source)) void _event; }).rejects.toThrow(/余额不足/u);
  });
});
