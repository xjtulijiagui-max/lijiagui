export function csrfToken(): string {
  if (typeof document === "undefined") return "";
  const value = document.cookie.match(/(?:^|;\s*)xk_csrf=([^;]+)/u)?.[1];
  return value ? decodeURIComponent(value) : "";
}

export async function apiFetch(input: string, init: RequestInit = {}) {
  const headers = new Headers(init.headers);
  if (init.method && init.method !== "GET") headers.set("x-csrf-token", csrfToken());
  if (init.body && !(init.body instanceof FormData) && !headers.has("content-type")) headers.set("content-type", "application/json");
  return fetch(input, { ...init, headers, credentials: "same-origin" });
}
