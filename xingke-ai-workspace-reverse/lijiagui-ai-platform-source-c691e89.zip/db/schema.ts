import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

const timestamps = {
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
};

export const users = sqliteTable("users", {
  id: text("id").primaryKey(), username: text("username").notNull(), displayName: text("display_name").notNull(),
  passwordAlgorithm: text("password_algorithm").notNull(), passwordIterations: integer("password_iterations").notNull(),
  passwordSalt: text("password_salt").notNull(), passwordHash: text("password_hash").notNull(),
  role: text("role", { enum: ["admin", "member"] }).notNull().default("member"),
  status: text("status", { enum: ["active", "disabled"] }).notNull().default("active"),
  mustChangePassword: integer("must_change_password", { mode: "boolean" }).notNull().default(true),
  lastLoginAt: integer("last_login_at", { mode: "timestamp_ms" }), ...timestamps,
}, (table) => [uniqueIndex("users_username_unique").on(table.username), index("users_status_idx").on(table.status)]);

export const sessions = sqliteTable("sessions", {
  id: text("id").primaryKey(), userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(), csrfTokenHash: text("csrf_token_hash").notNull(),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(), lastActivityAt: integer("last_activity_at", { mode: "timestamp_ms" }).notNull(),
  userAgent: text("user_agent"), ipHash: text("ip_hash"), ...timestamps,
}, (table) => [uniqueIndex("sessions_token_hash_unique").on(table.tokenHash), index("sessions_user_idx").on(table.userId), index("sessions_expiry_idx").on(table.expiresAt)]);

export const loginAttempts = sqliteTable("login_attempts", {
  id: text("id").primaryKey(), username: text("username").notNull(), ipHash: text("ip_hash").notNull(),
  succeeded: integer("succeeded", { mode: "boolean" }).notNull(), attemptedAt: integer("attempted_at", { mode: "timestamp_ms" }).notNull(), ...timestamps,
}, (table) => [index("login_attempts_lookup_idx").on(table.username, table.ipHash, table.attemptedAt)]);

export const conversations = sqliteTable("conversations", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(), scene: text("scene").notNull().default("general"), model: text("model").notNull(),
  expertId: text("expert_id"), skillIdsJson: text("skill_ids_json").notNull().default("[]"),
  archivedAt: integer("archived_at", { mode: "timestamp_ms" }), deletedAt: integer("deleted_at", { mode: "timestamp_ms" }), ...timestamps,
}, (table) => [index("conversations_owner_idx").on(table.ownerUserId, table.updatedAt)]);

export const messages = sqliteTable("messages", {
  id: text("id").primaryKey(), conversationId: text("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: text("role", { enum: ["user", "assistant", "system"] }).notNull(), content: text("content").notNull(),
  status: text("status", { enum: ["pending", "streaming", "complete", "failed"] }).notNull().default("complete"),
  model: text("model"), promptTokens: integer("prompt_tokens"), completionTokens: integer("completion_tokens"),
  latencyMs: integer("latency_ms"), errorCode: text("error_code"), ...timestamps,
}, (table) => [index("messages_conversation_idx").on(table.conversationId, table.createdAt), index("messages_owner_idx").on(table.ownerUserId)]);

export const experts = sqliteTable("experts", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(), description: text("description").notNull().default(""), systemPrompt: text("system_prompt").notNull(),
  avatarColor: text("avatar_color").notNull().default("#6d5dfc"), visibility: text("visibility", { enum: ["public", "private"] }).notNull().default("private"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true), ...timestamps,
}, (table) => [index("experts_visibility_idx").on(table.visibility, table.enabled), index("experts_owner_idx").on(table.ownerUserId)]);

export const skills = sqliteTable("skills", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(), invocationName: text("invocation_name").notNull(), description: text("description").notNull().default(""),
  instructions: text("instructions").notNull(), visibility: text("visibility", { enum: ["public", "private"] }).notNull().default("private"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true), ...timestamps,
}, (table) => [index("skills_visibility_idx").on(table.visibility, table.enabled), index("skills_owner_idx").on(table.ownerUserId)]);

export const apps = sqliteTable("apps", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(), description: text("description").notNull().default(""),
  visibility: text("visibility", { enum: ["public", "private"] }).notNull().default("private"), currentVersionId: text("current_version_id"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true), ...timestamps,
}, (table) => [index("apps_visibility_idx").on(table.visibility, table.enabled), index("apps_owner_idx").on(table.ownerUserId)]);

export const appVersions = sqliteTable("app_versions", {
  id: text("id").primaryKey(), appId: text("app_id").notNull().references(() => apps.id, { onDelete: "cascade" }),
  version: integer("version").notNull(), expertId: text("expert_id"), skillIdsJson: text("skill_ids_json").notNull().default("[]"),
  model: text("model").notNull(), promptTemplate: text("prompt_template").notNull().default(""),
  createdByUserId: text("created_by_user_id").notNull().references(() => users.id), ...timestamps,
}, (table) => [uniqueIndex("app_versions_app_version_unique").on(table.appId, table.version)]);

export const userApps = sqliteTable("user_apps", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  appId: text("app_id").notNull().references(() => apps.id, { onDelete: "cascade" }), pinnedVersionId: text("pinned_version_id").references(() => appVersions.id), ...timestamps,
}, (table) => [uniqueIndex("user_apps_owner_app_unique").on(table.ownerUserId, table.appId)]);

export const folders = sqliteTable("folders", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  parentId: text("parent_id"), name: text("name").notNull(), deletedAt: integer("deleted_at", { mode: "timestamp_ms" }), ...timestamps,
}, (table) => [index("folders_owner_parent_idx").on(table.ownerUserId, table.parentId)]);

export const files = sqliteTable("files", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  folderId: text("folder_id").references(() => folders.id, { onDelete: "set null" }), r2Key: text("r2_key").notNull(),
  name: text("name").notNull(), mimeType: text("mime_type").notNull(), sizeBytes: integer("size_bytes").notNull(), checksumSha256: text("checksum_sha256"),
  deletedAt: integer("deleted_at", { mode: "timestamp_ms" }), ...timestamps,
}, (table) => [uniqueIndex("files_r2_key_unique").on(table.r2Key), index("files_owner_folder_idx").on(table.ownerUserId, table.folderId)]);

export const schedules = sqliteTable("schedules", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(), prompt: text("prompt").notNull(), appVersionId: text("app_version_id").references(() => appVersions.id),
  frequency: text("frequency").notNull(), timezone: text("timezone").notNull().default("Asia/Shanghai"), enabled: integer("enabled", { mode: "boolean" }).notNull().default(false),
  nextRunAt: integer("next_run_at", { mode: "timestamp_ms" }), leaseToken: text("lease_token"), leaseExpiresAt: integer("lease_expires_at", { mode: "timestamp_ms" }), ...timestamps,
}, (table) => [index("schedules_due_idx").on(table.enabled, table.nextRunAt), index("schedules_owner_idx").on(table.ownerUserId)]);

export const scheduleRuns = sqliteTable("schedule_runs", {
  id: text("id").primaryKey(), scheduleId: text("schedule_id").notNull().references(() => schedules.id, { onDelete: "cascade" }),
  ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }), conversationId: text("conversation_id").references(() => conversations.id),
  status: text("status", { enum: ["queued", "running", "succeeded", "failed"] }).notNull(), startedAt: integer("started_at", { mode: "timestamp_ms" }),
  finishedAt: integer("finished_at", { mode: "timestamp_ms" }), errorCode: text("error_code"), ...timestamps,
}, (table) => [index("schedule_runs_schedule_idx").on(table.scheduleId, table.createdAt), index("schedule_runs_owner_idx").on(table.ownerUserId, table.createdAt)]);

export const usageDaily = sqliteTable("usage_daily", {
  id: text("id").primaryKey(), ownerUserId: text("owner_user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: text("date").notNull(), model: text("model").notNull(), requestCount: integer("request_count").notNull().default(0),
  promptTokens: integer("prompt_tokens").notNull().default(0), completionTokens: integer("completion_tokens").notNull().default(0), scheduleRunCount: integer("schedule_run_count").notNull().default(0), ...timestamps,
}, (table) => [uniqueIndex("usage_daily_owner_date_model_unique").on(table.ownerUserId, table.date, table.model)]);

export const auditLogs = sqliteTable("audit_logs", {
  id: text("id").primaryKey(), actorUserId: text("actor_user_id").references(() => users.id, { onDelete: "set null" }),
  action: text("action").notNull(), targetType: text("target_type"), targetId: text("target_id"), metadataJson: text("metadata_json").notNull().default("{}"),
  ipHash: text("ip_hash"), ...timestamps,
}, (table) => [index("audit_logs_created_idx").on(table.createdAt), index("audit_logs_actor_idx").on(table.actorUserId, table.createdAt)]);

export const systemSettings = sqliteTable("system_settings", {
  id: text("id").primaryKey(), key: text("key").notNull(), valueJson: text("value_json").notNull(),
  updatedByUserId: text("updated_by_user_id").references(() => users.id, { onDelete: "set null" }), ...timestamps,
}, (table) => [uniqueIndex("system_settings_key_unique").on(table.key)]);
