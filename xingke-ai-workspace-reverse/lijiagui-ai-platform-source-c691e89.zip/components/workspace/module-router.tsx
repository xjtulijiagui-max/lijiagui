"use client";

import { AdminWorkspaceView } from "../admin/admin-workspace-view";
import { AppsView } from "./apps-view";
import { CapabilitiesView, type CapabilityLaunch } from "./capabilities-view";
import { DriveView } from "./drive-view";
import type { WorkspaceModule } from "./main-nav";
import { SchedulesView } from "./schedules-view";
import type { TaskLaunch } from "./task-launch";
import { TaskView } from "./task-view";

type Props = {
  module: WorkspaceModule;
  role: "admin" | "member";
  launch: TaskLaunch;
  onUseCapability: (selection: CapabilityLaunch) => void;
  onUseApp: (versionId: string, appName: string) => void;
};

export function ModuleRouter({ module, role, launch, onUseCapability, onUseApp }: Props) {
  if (module === "task") return <TaskView launch={launch} />;
  if (module === "capabilities") return <CapabilitiesView role={role} onUse={onUseCapability} />;
  if (module === "apps") return <AppsView role={role} onUseApp={onUseApp} />;
  if (module === "drive") return <DriveView />;
  if (module === "schedules") return <SchedulesView />;
  return <AdminWorkspaceView />;
}
