"use client";

import { useEffect, useState } from "react";
import { FilePanel } from "./file-panel";
import { MainNav, type WorkspaceModule } from "./main-nav";
import { ModuleRouter } from "./module-router";
import { TopBar, type WorkspaceUser } from "./top-bar";
import type { CapabilityLaunch } from "./capabilities-view";
import type { TaskLaunch } from "./task-launch";

export function WorkspaceShell({ user, initialModule }: { user: WorkspaceUser; initialModule: WorkspaceModule }) {
  const [active, setActive] = useState<WorkspaceModule>(initialModule);
  const [navOpen, setNavOpen] = useState(false);
  const [filesOpen, setFilesOpen] = useState(false);
  const [launch, setLaunch] = useState<TaskLaunch>({ nonce: 0 });
  useEffect(() => { if (user.mustChangePassword) window.location.href = "/change-password"; }, [user.mustChangePassword]);
  function select(module: WorkspaceModule) {
    setActive(module); setNavOpen(false);
    const url = new URL(window.location.href); url.searchParams.set("module", module); window.history.replaceState({}, "", url);
  }
  function useCapability(selection: CapabilityLaunch) {
    setLaunch({ ...selection, nonce: Date.now() });
    select("task");
  }
  function useApp(versionId: string, appName: string) {
    setLaunch({ appVersionId: versionId, appName, nonce: Date.now() });
    select("task");
  }
  return <main className="workspace-shell"><div className={`nav-drawer ${navOpen ? "open" : ""}`}><MainNav active={active} role={user.role} onSelect={select} /></div>{navOpen && <button className="drawer-scrim" aria-label="关闭导航" onClick={() => setNavOpen(false)} />}
    <section className="workspace-main"><TopBar user={user} onOpenNav={() => setNavOpen(true)} onOpenFiles={() => setFilesOpen(true)} /><div className="workspace-canvas"><ModuleRouter module={active} role={user.role} launch={launch} onUseCapability={useCapability} onUseApp={useApp} /></div></section>
    <FilePanel open={filesOpen} onClose={() => setFilesOpen(false)} />{filesOpen && <button className="file-scrim" aria-label="关闭文件面板遮罩" onClick={() => setFilesOpen(false)} />}
  </main>;
}
