"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { apiFetch } from "../../lib/client-auth";
import { ChatThread, type ChatItem } from "./chat-thread";
import { EmptyState } from "./empty-state";
import type { TaskLaunch } from "./task-launch";
import { TaskComposer } from "./task-composer";

type Conversation = { id: string; title: string; updatedAt: string };
type Option = { id: string; name: string };

export function TaskView({ launch }: { launch: TaskLaunch }) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [conversationId, setConversationId] = useState<string>();
  const [messages, setMessages] = useState<ChatItem[]>([]);
  const [experts, setExperts] = useState<Option[]>([]);
  const [skills, setSkills] = useState<Option[]>([]);
  const [expertId, setExpertId] = useState<string>();
  const [skillIds, setSkillIds] = useState<string[]>([]);
  const [appVersionId, setAppVersionId] = useState<string>();
  const [appName, setAppName] = useState<string>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const abort = useRef<AbortController | null>(null);
  const lastPrompt = useRef("");

  const loadList = useCallback(async () => {
    const response = await apiFetch("/api/conversations");
    if (response.ok) setConversations(((await response.json()) as { conversations: Conversation[] }).conversations);
  }, []);
  useEffect(() => { void loadList(); }, [loadList]);
  useEffect(() => {
    void Promise.all([apiFetch("/api/experts"), apiFetch("/api/skills")]).then(async ([expertResponse, skillResponse]) => {
      if (expertResponse.ok) setExperts(((await expertResponse.json()) as { experts: Option[] }).experts);
      if (skillResponse.ok) setSkills(((await skillResponse.json()) as { skills: Option[] }).skills);
    });
  }, []);
  useEffect(() => {
    if (!launch.nonce) return;
    setConversationId(undefined); setMessages([]); setError("");
    setExpertId(launch.expertId); setSkillIds(launch.skillIds ?? []);
    setAppVersionId(launch.appVersionId); setAppName(launch.appName);
  }, [launch]);

  async function open(id: string) {
    const response = await apiFetch(`/api/conversations/${id}`); if (!response.ok) return;
    const payload = await response.json() as { conversation: { expertId?: string; skillIdsJson?: string }; messages: Array<{ id: string; role: "system" | "user" | "assistant"; content: string; status: ChatItem["status"] }> };
    setConversationId(id); setMessages(payload.messages.filter((item) => item.role !== "system") as ChatItem[]);
    setExpertId(payload.conversation.expertId); setSkillIds(JSON.parse(payload.conversation.skillIdsJson || "[]") as string[]); setAppVersionId(undefined); setAppName(undefined);
  }
  async function send(content: string) {
    lastPrompt.current = content; setBusy(true); setError(""); abort.current = new AbortController();
    const userId = crypto.randomUUID(); const assistantId = crypto.randomUUID();
    setMessages((current) => [...current, { id: userId, role: "user", content, status: "complete" }, { id: assistantId, role: "assistant", content: "", status: "streaming" }]);
    try {
      const response = await apiFetch("/api/chat/stream", { method: "POST", signal: abort.current.signal, body: JSON.stringify({ conversationId, content, model: "glm-5.3-flash", expertId, skillIds, appVersionId }) });
      if (!response.ok || !response.body) { const payload = await response.json() as { error?: string }; throw new Error(payload.error ?? "模型请求失败"); }
      const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = "";
      while (true) {
        const { value, done } = await reader.read(); if (done) break; buffer += decoder.decode(value, { stream: true });
        const blocks = buffer.split(/\r?\n\r?\n/u); buffer = blocks.pop() ?? "";
        for (const block of blocks) {
          const data = block.split(/\r?\n/u).find((line) => line.startsWith("data:"))?.slice(5).trim(); if (!data) continue;
          const event = JSON.parse(data) as { type: string; content?: string; conversationId?: string; message?: string };
          if (event.type === "meta" && event.conversationId) setConversationId(event.conversationId);
          if (event.type === "content" && event.content) setMessages((current) => current.map((item) => item.id === assistantId ? { ...item, content: item.content + event.content } : item));
          if (event.type === "error") { setMessages((current) => current.map((item) => item.id === assistantId ? { ...item, status: "failed" } : item)); throw new Error(event.message ?? "回答中断"); }
          if (event.type === "done") setMessages((current) => current.map((item) => item.id === assistantId ? { ...item, status: "complete" } : item));
        }
      }
      await loadList();
    } catch (cause) {
      if (!abort.current?.signal.aborted) setError(cause instanceof Error ? cause.message : "模型请求失败");
      setMessages((current) => current.map((item) => item.id === assistantId && item.status === "streaming" ? { ...item, status: "failed" } : item));
    } finally { setBusy(false); abort.current = null; }
  }
  async function rename() { if (!conversationId) return; const title = window.prompt("输入新标题"); if (!title) return; await apiFetch(`/api/conversations/${conversationId}`, { method: "PATCH", body: JSON.stringify({ title }) }); await loadList(); }
  async function archive() { if (!conversationId) return; await apiFetch(`/api/conversations/${conversationId}`, { method: "PATCH", body: JSON.stringify({ archived: true }) }); setConversationId(undefined); setMessages([]); await loadList(); }
  function clearApp() { setAppVersionId(undefined); setAppName(undefined); }

  return <div className={`task-module ${messages.length ? "has-chat" : ""}`}><div className="conversation-strip"><button className="new-conversation" onClick={() => { setConversationId(undefined); setMessages([]); }}>＋ 新任务</button><div>{conversations.slice(0, 5).map((item) => <button className={item.id === conversationId ? "active" : ""} key={item.id} onClick={() => void open(item.id)}>{item.title}</button>)}</div>{conversationId && <span><button onClick={() => void rename()}>重命名</button><button onClick={() => void archive()}>归档</button></span>}</div>
    <div className="task-content">{messages.length ? <ChatThread messages={messages} onRetry={() => void send(lastPrompt.current)} /> : <EmptyState />}</div>{error && <div className="chat-error">{error}</div>}<TaskComposer busy={busy} onSend={send} onStop={() => abort.current?.abort()} experts={experts} skills={skills} selectedExpertId={expertId} selectedSkillIds={skillIds} appName={appName} onExpertChange={(id) => { clearApp(); setExpertId(id); }} onSkillToggle={(id) => { clearApp(); setSkillIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]); }} /></div>;
}
