"use client";

type PreviewFile = { id: string; name: string; mimeType: string; sizeBytes: number };
export function FilePreview({ file, onClose }: { file: PreviewFile; onClose: () => void }) {
  const url = `/api/files/${file.id}?preview=1`;
  return <div className="preview-layer"><section><header><div><strong>{file.name}</strong><span>{file.mimeType} · {(file.sizeBytes / 1024).toFixed(1)} KB</span></div><a href={`/api/files/${file.id}`}>下载</a><button onClick={onClose}>×</button></header><div className="preview-body">{file.mimeType.startsWith("image/") ? <img src={url} alt={file.name} /> : file.mimeType === "application/pdf" ? <iframe src={url} title={file.name} /> : /^(text\/|application\/json)/u.test(file.mimeType) ? <iframe src={url} title={file.name} /> : <div className="no-preview"><span>▤</span><strong>此文件支持下载和模型引用</strong><p>当前版本不提供 Office 原生编辑。</p></div>}</div></section></div>;
}
