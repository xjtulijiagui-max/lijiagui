"use client";

export function FilePanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  return <aside className={`file-panel ${open ? "open" : ""}`}><header><div><strong>文件工作区</strong><span>当前任务</span></div><button aria-label="关闭文件面板" onClick={onClose}>×</button></header><div className="file-empty"><div>⇧</div><strong>把资料带进任务</strong><p>从云盘选择，或拖放文件到这里。只有你明确选择的文件才会交给模型处理。</p><button type="button">选择云盘文件</button></div><footer><span>0 个文件</span><a href="/?module=drive">管理云盘 →</a></footer></aside>;
}
