"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { apiFetch } from "../../lib/client-auth";

type AppItem = { id: string; name: string; description: string; visibility: "public" | "private"; currentVersionId: string | null; ownerUserId: string };
type CapabilityOption = { id: string; name: string };

export function AppsView({ role, onUseApp }: { role: "admin" | "member"; onUseApp?: (versionId: string, appName: string) => void }) {
  const [apps, setApps] = useState<AppItem[]>([]);
  const [experts, setExperts] = useState<CapabilityOption[]>([]);
  const [skills, setSkills] = useState<CapabilityOption[]>([]);
  const [query, setQuery] = useState("");
  const [creating, setCreating] = useState(false);
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    const [appResponse, expertResponse, skillResponse] = await Promise.all([apiFetch("/api/apps"), apiFetch("/api/experts"), apiFetch("/api/skills")]);
    if (appResponse.ok) setApps(((await appResponse.json()) as { apps: AppItem[] }).apps);
    if (expertResponse.ok) setExperts(((await expertResponse.json()) as { experts: CapabilityOption[] }).experts);
    if (skillResponse.ok) setSkills(((await skillResponse.json()) as { skills: CapabilityOption[] }).skills);
  }, []);
  useEffect(() => { void load(); }, [load]);
  const filtered = useMemo(() => apps.filter((item) => `${item.name} ${item.description}`.toLowerCase().includes(query.toLowerCase())), [apps, query]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    const response = await apiFetch("/api/apps", { method: "POST", body: JSON.stringify({
      name: form.get("name"), description: form.get("description"), promptTemplate: form.get("promptTemplate"),
      visibility: form.get("visibility"), expertId: form.get("expertId") || undefined, skillIds: form.getAll("skillIds"),
    }) });
    if (response.ok) { setCreating(false); setNotice("应用已创建并发布第 1 版，可立即使用"); await load(); }
    else setNotice(((await response.json()) as { error?: string }).error ?? "应用创建失败");
  }
  async function install(item: AppItem) {
    if (!item.currentVersionId) return;
    const response = await apiFetch(`/api/apps/${item.id}/install`, { method: "POST", body: JSON.stringify({ versionId: item.currentVersionId }) });
    setNotice(response.ok ? `已安装「${item.name}」并固定当前版本` : "安装失败");
  }

  return <section className="catalog-view">
    <header><div><p>应用中心</p><h1>把成熟流程变成一键应用</h1><span>应用会固定专家、技能、模型和任务模板的版本。</span></div><button onClick={() => setCreating(true)}>＋ 创建应用</button></header>
    <div className="catalog-toolbar"><nav><button className="active">全部应用</button><button>我的应用</button></nav><input aria-label="搜索应用" placeholder="搜索应用" value={query} onChange={(event) => setQuery(event.target.value)} /></div>
    {notice && <div className="catalog-notice">{notice}</div>}
    <div className="app-grid">{filtered.map((item, index) => <article key={item.id}><div className={`app-cover tone-${index % 4}`}><span>✦</span><small>{item.visibility === "public" ? "团队应用" : "私人应用"}</small></div><div><h2>{item.name}</h2><p>{item.description || "尚未填写应用说明"}</p><footer><button onClick={() => void install(item)}>安装当前版本</button><button aria-label={`使用${item.name}`} disabled={!item.currentVersionId} onClick={() => { if (item.currentVersionId) onUseApp?.(item.currentVersionId, item.name); }}>立即使用</button></footer></div></article>)}</div>
    {creating && <div className="modal-layer"><form className="cap-modal" onSubmit={create}><h2>创建应用</h2><label>应用名称<input name="name" required /></label><label>应用说明<input name="description" /></label><label>绑定专家<select name="expertId"><option value="">不绑定专家</option>{experts.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><fieldset><legend>绑定技能</legend>{skills.map((item) => <label className="check-line" key={item.id}><input type="checkbox" name="skillIds" value={item.id} /> {item.name}</label>)}</fieldset><label>启动提示模板<textarea name="promptTemplate" rows={5} placeholder="例如：请根据以下资料生成……；可用 {{input}} 插入用户内容" required /></label><label>可见范围<select name="visibility"><option value="private">仅自己</option>{role === "admin" && <option value="public">所有用户</option>}</select></label><div><button type="button" onClick={() => setCreating(false)}>取消</button><button>创建并发布第 1 版</button></div></form></div>}
  </section>;
}
