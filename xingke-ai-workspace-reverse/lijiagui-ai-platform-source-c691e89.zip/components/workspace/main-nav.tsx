"use client";

export type WorkspaceModule = "task" | "capabilities" | "apps" | "schedules" | "drive" | "admin";

const modules: Array<{ key: WorkspaceModule; label: string; icon: string; admin?: boolean }> = [
  { key: "task", label: "新建任务", icon: "✦" },
  { key: "capabilities", label: "专家·技能·连接器", icon: "⌘" },
  { key: "apps", label: "应用", icon: "▦" },
  { key: "schedules", label: "定时任务", icon: "◷" },
  { key: "drive", label: "云盘", icon: "☁" },
  { key: "admin", label: "用户管理", icon: "◇", admin: true },
];

export function MainNav({ active, role, onSelect }: { active: WorkspaceModule; role: "admin" | "member"; onSelect: (module: WorkspaceModule) => void }) {
  return <nav className="main-nav" aria-label="主导航">
    <div className="workspace-brand"><span>李</span><div><strong>李家贵AI中台</strong><small>团队工作台</small></div></div>
    <p className="nav-section">工作空间</p>
    {modules.filter((item) => !item.admin || role === "admin").map((item) => <button key={item.key} type="button" className={active === item.key ? "active" : ""} onClick={() => onSelect(item.key)}><i>{item.icon}</i><span>{item.label}</span></button>)}
    <div className="nav-spacer" />
    <div className="plan-card"><span>团队版</span><strong>今天还有充足额度</strong><small>50 次模型请求 / 天</small><div><b style={{ width: "34%" }} /></div></div>
  </nav>;
}
