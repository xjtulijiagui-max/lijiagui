"use client";

export type ChatItem = { id: string; role: "user" | "assistant"; content: string; status?: "streaming" | "complete" | "failed" };

export function ChatThread({ messages, onRetry }: { messages: ChatItem[]; onRetry: () => void }) {
  return <section className="chat-thread" aria-live="polite">{messages.map((message) => <article key={message.id} className={`chat-message ${message.role}`}><div className="message-avatar">{message.role === "assistant" ? "李" : "我"}</div><div className="message-body"><header><strong>{message.role === "assistant" ? "李家贵AI" : "你"}</strong>{message.status === "streaming" && <span>正在生成</span>}</header><div className="message-content">{message.content || <i className="typing"><b /><b /><b /></i>}</div>{message.status === "failed" && <footer><span>回答中断，已保留当前内容</span><button onClick={onRetry}>重试</button></footer>}</div></article>)}</section>;
}
