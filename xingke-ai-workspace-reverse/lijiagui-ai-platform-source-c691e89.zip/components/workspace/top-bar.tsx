"use client";

import { apiFetch } from "../../lib/client-auth";

export type WorkspaceUser = { id: string; username: string; displayName: string; role: "admin" | "member"; mustChangePassword: boolean };

export function TopBar({ user, onOpenNav, onOpenFiles }: { user: WorkspaceUser; onOpenNav: () => void; onOpenFiles: () => void }) {
  async function logout() { await apiFetch("/api/auth/logout", { method: "POST" }); window.location.href = "/login"; }
  return <header className="top-bar"><button className="mobile-control" aria-label="打开导航" onClick={onOpenNav}>☰</button><div className="top-title"><strong>AI 工作空间</strong><span>让每一个想法快速落地</span></div><div className="top-actions"><button className="mobile-control" aria-label="打开文件面板" onClick={onOpenFiles}>▤</button><button className="notification" aria-label="通知">⌁</button><div className="account-menu"><span>{user.displayName.slice(0, 1)}</span><div><strong>{user.displayName}</strong><small>{user.role === "admin" ? "管理员" : `@${user.username}`}</small></div><button onClick={() => void logout()}>退出</button></div></div></header>;
}
