"use client";

import { FormEvent, useState } from "react";

type Option = { id: string; name: string };
type Props = {
  busy: boolean;
  onSend: (content: string) => Promise<void>;
  onStop: () => void;
  experts?: Option[];
  skills?: Option[];
  selectedExpertId?: string;
  selectedSkillIds?: string[];
  appName?: string;
  onExpertChange?: (id?: string) => void;
  onSkillToggle?: (id: string) => void;
};

export function TaskComposer({ busy, onSend, onStop, experts = [], skills = [], selectedExpertId, selectedSkillIds = [], appName, onExpertChange, onSkillToggle }: Props) {
  const [value, setValue] = useState("");
  const [picker, setPicker] = useState<"expert" | "skills" | null>(null);
  const selectedExpert = experts.find((item) => item.id === selectedExpertId);
  const selectedSkills = skills.filter((item) => selectedSkillIds.includes(item.id));
  async function submit(event: FormEvent) { event.preventDefault(); const content = value.trim(); if (!content || busy) return; setValue(""); await onSend(content); }

  return <form className="composer" onSubmit={submit}>
    {(appName || selectedExpert || selectedSkills.length > 0) && <div className="composer-selections">{appName && <span>应用：{appName}</span>}{selectedExpert && <span>专家：{selectedExpert.name}</span>}{selectedSkills.map((item) => <span key={item.id}>技能：{item.name}</span>)}</div>}
    <div className="composer-input"><textarea aria-label="任务内容" placeholder="描述你想完成的任务…" rows={3} value={value} onChange={(event) => setValue(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); event.currentTarget.form?.requestSubmit(); } }} />
      <div className="composer-tools"><div><button type="button" aria-label="添加文件">＋</button><button type="button" className={selectedExpert ? "selected" : ""} onClick={() => setPicker(picker === "expert" ? null : "expert")}>专家</button><button type="button" className={selectedSkills.length ? "selected" : ""} onClick={() => setPicker(picker === "skills" ? null : "skills")}>技能</button></div>{busy ? <button type="button" className="send stop" aria-label="停止生成" onClick={onStop}>■</button> : <button className="send" aria-label="发送任务">↑</button>}</div>
      {picker === "expert" && <div className="composer-picker"><strong>选择专家</strong><button type="button" onClick={() => { onExpertChange?.(undefined); setPicker(null); }}>不使用专家</button>{experts.map((item) => <button type="button" aria-label={`选择${item.name}`} className={selectedExpertId === item.id ? "active" : ""} key={item.id} onClick={() => { onExpertChange?.(item.id); setPicker(null); }}>{item.name}</button>)}</div>}
      {picker === "skills" && <div className="composer-picker"><strong>选择技能（可多选）</strong>{skills.map((item) => <button type="button" aria-label={`选择${item.name}`} className={selectedSkillIds.includes(item.id) ? "active" : ""} key={item.id} onClick={() => onSkillToggle?.(item.id)}>{selectedSkillIds.includes(item.id) ? "✓ " : ""}{item.name}</button>)}</div>}
    </div>
    <div className="composer-meta"><span>GLM-5.3-Flash</span><span>{appName || selectedExpert || selectedSkills.length ? "已组合能力" : "标准思考"}</span><small>AI 可能会犯错，请核对重要信息</small></div>
  </form>;
}
