export type TaskLaunch = {
  nonce: number;
  expertId?: string;
  expertName?: string;
  skillIds?: string[];
  skillNames?: string[];
  appVersionId?: string;
  appName?: string;
};
