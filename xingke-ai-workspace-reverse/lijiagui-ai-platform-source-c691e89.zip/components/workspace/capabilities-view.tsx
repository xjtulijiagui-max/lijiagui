"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { apiFetch } from "../../lib/client-auth";

type Capability = { id: string; name: string; description: string; visibility: string; avatarColor?: string };
type Connector = { id: string; name: string; description: string; status: string };
export type CapabilityLaunch = { expertId?: string; expertName?: string; skillIds?: string[]; skillNames?: string[] };

export function CapabilitiesView({ role, onUse }: { role: "admin" | "member"; onUse?: (launch: CapabilityLaunch) => void }) {
  const [tab, setTab] = useState<"experts" | "skills" | "connectors">("experts");
  const [experts, setExperts] = useState<Capability[]>([]);
  const [skills, setSkills] = useState<Capability[]>([]);
  const [connectors, setConnectors] = useState<Connector[]>([]);
  const [query, setQuery] = useState("");
  const [creating, setCreating] = useState(false);
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    const [expertResponse, skillResponse] = await Promise.all([apiFetch("/api/experts"), apiFetch("/api/skills")]);
    if (expertResponse.ok) {
      const data = await expertResponse.json() as { experts: Capability[]; connectors: Connector[] };
      setExperts(data.experts); setConnectors(data.connectors);
    }
    if (skillResponse.ok) setSkills(((await skillResponse.json()) as { skills: Capability[] }).skills);
  }, []);
  useEffect(() => { void load(); }, [load]);

  const items = useMemo(() => (tab === "experts" ? experts : tab === "skills" ? skills : connectors)
    .filter((item) => `${item.name} ${item.description}`.toLowerCase().includes(query.toLowerCase())), [tab, experts, skills, connectors, query]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget); const isExpert = tab === "experts";
    const response = await apiFetch(isExpert ? "/api/experts" : "/api/skills", {
      method: "POST",
      body: JSON.stringify(isExpert
        ? { name: form.get("name"), description: form.get("description"), systemPrompt: form.get("instructions"), visibility: form.get("visibility") }
        : { name: form.get("name"), description: form.get("description"), instructions: form.get("instructions"), visibility: form.get("visibility") }),
    });
    if (response.ok) { setCreating(false); setNotice(isExpert ? "专家已创建，可立即使用" : "技能已创建，可立即使用"); await load(); }
    else setNotice(((await response.json()) as { error?: string }).error ?? "保存失败");
  }

  function selectItem(item: Capability | Connector) {
    if (tab === "experts") onUse?.({ expertId: item.id, expertName: item.name });
    if (tab === "skills") onUse?.({ skillIds: [item.id], skillNames: [item.name] });
  }

  return <section className="catalog-view">
    <header><div><p>能力中心</p><h1>专家 · 技能 · 连接器</h1><span>创建后可直接带入任务或应用。</span></div><button onClick={() => setCreating(true)} disabled={tab === "connectors"}>＋ 新建{tab === "experts" ? "专家" : "技能"}</button></header>
    <div className="catalog-toolbar"><nav>{[["experts", "专家"], ["skills", "技能"], ["connectors", "连接器"]].map(([key, label]) => <button key={key} className={tab === key ? "active" : ""} onClick={() => setTab(key as typeof tab)}>{label}</button>)}</nav><input aria-label="搜索能力" placeholder="搜索名称或说明" value={query} onChange={(event) => setQuery(event.target.value)} /></div>
    {notice && <div className="catalog-notice">{notice}</div>}
    <div className="catalog-grid">{items.map((item) => <article key={item.id}>
      <i style={{ background: "avatarColor" in item ? item.avatarColor : undefined }}>{tab === "experts" ? item.name.slice(0, 1) : tab === "skills" ? "⌘" : "↗"}</i>
      <span className="cap-tag">{"status" in item ? "已连接" : item.visibility === "public" ? "公共" : "私有"}</span>
      <h2>{item.name}</h2><p>{item.description}</p>
      <button aria-label={tab === "connectors" ? `查看${item.name}说明` : `使用${item.name}`} onClick={() => selectItem(item)}>{tab === "connectors" ? "查看说明" : "选择使用"}</button>
    </article>)}</div>
    {creating && <div className="modal-layer"><form className="cap-modal" onSubmit={create}><h2>新建{tab === "experts" ? "专家" : "技能"}</h2><label>名称<input name="name" required /></label><label>说明<input name="description" /></label><label>{tab === "experts" ? "系统指令" : "技能指令"}<textarea name="instructions" rows={6} required /></label><label>可见范围<select name="visibility"><option value="private">仅自己</option>{role === "admin" && <option value="public">所有用户</option>}</select></label><div><button type="button" onClick={() => setCreating(false)}>取消</button><button>保存</button></div></form></div>}
  </section>;
}
