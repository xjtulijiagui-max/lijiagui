"use client";
import { useEffect, useState } from "react";
import { apiFetch } from "../../lib/client-auth";
type Audit = { id: string; action: string; targetType: string | null; targetId: string | null; createdAt: string; metadataJson: string };
export function AuditView() { const [logs, setLogs] = useState<Audit[]>([]); useEffect(() => { void apiFetch("/api/admin/audit").then(async (response) => { if (response.ok) setLogs(((await response.json()) as { logs: Audit[] }).logs); }); }, []); return <div className="audit-list">{logs.map((item) => <article key={item.id}><i>◎</i><div><strong>{item.action}</strong><span>{item.targetType ?? "system"} · {item.targetId ?? "—"}</span></div><time>{new Date(item.createdAt).toLocaleString("zh-CN")}</time></article>)}{!logs.length && <div className="drive-empty"><strong>暂无审计记录</strong><p>登录与管理操作会记录在这里，不保存密码、密钥或对话正文。</p></div>}</div>; }
