"use client";

import { FormEvent, useState } from "react";

export default function LoginPage() {
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setLoading(true); setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: form.get("username"), password: form.get("password") }) });
    const payload = await response.json() as { error?: string; user?: { mustChangePassword: boolean } };
    setLoading(false);
    if (!response.ok) { setError(payload.error ?? "登录失败"); return; }
    window.location.href = payload.user?.mustChangePassword ? "/change-password" : "/";
  }

  return <main className="auth-page">
    <section className="auth-panel">
      <div className="brand-mark">杏</div>
      <p className="eyebrow">XINGKE AI WORKSPACE</p>
      <h1>登录李家贵AI中台</h1>
      <p className="muted">使用管理员为你开通的账号进入工作空间</p>
      <form onSubmit={submit} className="auth-form">
        <label>手机号码或用户名<input name="username" autoComplete="username" required minLength={3} /></label>
        <label>密码<input name="password" type="password" autoComplete="current-password" required /></label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button disabled={loading}>{loading ? "正在登录…" : "登录"}</button>
      </form>
      <p className="security-note">账号密码仅用于本工作台，模型密钥不会发送到浏览器。</p>
    </section>
    <aside className="auth-visual"><div><span>一个账号</span><h2>把专家、技能、文件与任务放进同一张工作桌。</h2><p>独立空间 · 实时对话 · 管理员可控</p></div></aside>
  </main>;
}
