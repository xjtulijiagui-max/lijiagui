import { requireUser, responseFromError } from "../../../../server/auth/guards";
import { getConversationMessages, mutateConversation } from "../../../../server/domain/conversations";

export async function GET(request: Request, context: { params: Promise<{ id: string }> }) {
  try { const user = await requireUser(request); const { id } = await context.params; return Response.json(await getConversationMessages(id, user.userId)); }
  catch (error) { return responseFromError(error); }
}

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try { const user = await requireUser(request, true); const { id } = await context.params; const body = await request.json() as { title?: string; archived?: boolean }; await mutateConversation(id, user.userId, body); return Response.json({ ok: true }); }
  catch (error) { return responseFromError(error); }
}
