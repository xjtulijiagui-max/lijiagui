import { requireUser, responseFromError } from "../../../server/auth/guards";
import { createConversation, listConversations } from "../../../server/domain/conversations";

export async function GET(request: Request) {
  try { const user = await requireUser(request); return Response.json({ conversations: await listConversations(user.userId) }); }
  catch (error) { return responseFromError(error); }
}

export async function POST(request: Request) {
  try {
    const user = await requireUser(request, true); const body = await request.json() as { title?: string; scene?: string; model?: string };
    return Response.json({ conversation: await createConversation(user.userId, body) }, { status: 201 });
  } catch (error) { return responseFromError(error); }
}
