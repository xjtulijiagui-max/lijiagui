import { requireUser, responseFromError } from "../../../../server/auth/guards";
import { createSession } from "../../../../server/auth/session";
import { changeOwnPassword } from "../../../../server/domain/users";

export async function POST(request: Request) {
  try {
    const user = await requireUser(request, true);
    const body = await request.json() as { currentPassword?: string; nextPassword?: string };
    if (!body.currentPassword || !body.nextPassword) return Response.json({ error: "请填写当前密码和新密码" }, { status: 400 });
    await changeOwnPassword(user.userId, body.currentPassword, body.nextPassword);
    const cookie = await createSession(user.userId, request);
    const headers = new Headers({ "content-type": "application/json" });
    headers.append("set-cookie", cookie.session); headers.append("set-cookie", cookie.csrf);
    return new Response(JSON.stringify({ ok: true, csrfToken: cookie.csrfToken }), { headers });
  } catch (error) { return responseFromError(error); }
}
