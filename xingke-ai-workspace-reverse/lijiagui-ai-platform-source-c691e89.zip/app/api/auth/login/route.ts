import { assertSameOrigin } from "../../../../server/auth/csrf";
import { responseFromError } from "../../../../server/auth/guards";
import { createSession } from "../../../../server/auth/session";
import { authenticate } from "../../../../server/domain/users";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const body = await request.json() as { username?: string; password?: string };
    if (!body.username || !body.password) return Response.json({ error: "请输入用户名和密码" }, { status: 400 });
    const result = await authenticate(body.username, body.password, request);
    if (!result.ok) {
      const status = result.reason === "locked" ? 429 : 401;
      return Response.json({ error: result.reason === "locked" ? `登录已锁定，请在 ${result.retryAfterSeconds} 秒后重试` : "用户名或密码错误", retryAfterSeconds: result.retryAfterSeconds }, { status });
    }
    const cookie = await createSession(result.user.id, request);
    const headers = new Headers({ "content-type": "application/json" });
    headers.append("set-cookie", cookie.session);
    headers.append("set-cookie", cookie.csrf);
    return new Response(JSON.stringify({ user: { id: result.user.id, username: result.user.username, displayName: result.user.displayName, role: result.user.role, mustChangePassword: result.user.mustChangePassword }, csrfToken: cookie.csrfToken }), { headers });
  } catch (error) { return responseFromError(error); }
}
