import { requireUser, responseFromError } from "../../../../server/auth/guards";

export async function GET(request: Request) {
  try {
    const user = await requireUser(request);
    return Response.json({ user: { id: user.userId, username: user.username, displayName: user.displayName, role: user.role, mustChangePassword: user.mustChangePassword } });
  } catch (error) { return responseFromError(error); }
}
