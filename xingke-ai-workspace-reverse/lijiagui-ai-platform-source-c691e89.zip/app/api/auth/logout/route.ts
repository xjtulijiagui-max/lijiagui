import { eq } from "drizzle-orm";
import { getDb } from "../../../../db";
import { sessions } from "../../../../db/schema";
import { requireUser, responseFromError } from "../../../../server/auth/guards";
import { expiredSessionCookies } from "../../../../server/auth/session";

export async function POST(request: Request) {
  try {
    const user = await requireUser(request, true);
    await getDb().delete(sessions).where(eq(sessions.id, user.sessionId));
    const headers = new Headers();
    for (const cookie of expiredSessionCookies()) headers.append("set-cookie", cookie);
    return new Response(null, { status: 204, headers });
  } catch (error) { return responseFromError(error); }
}
