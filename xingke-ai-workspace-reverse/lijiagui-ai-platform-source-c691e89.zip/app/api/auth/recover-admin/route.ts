import { assertSameOrigin } from "../../../../server/auth/csrf";
import { responseFromError } from "../../../../server/auth/guards";
import { recoverAdmin } from "../../../../server/domain/users";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const body = await request.json() as { recoveryToken?: string; nextPassword?: string };
    if (!body.recoveryToken || !body.nextPassword) return Response.json({ error: "请填写恢复码和新密码" }, { status: 400 });
    await recoverAdmin(body.recoveryToken, body.nextPassword);
    return Response.json({ ok: true, message: "管理员已恢复，请使用新密码登录并立即修改密码" });
  } catch (error) { return responseFromError(error); }
}
