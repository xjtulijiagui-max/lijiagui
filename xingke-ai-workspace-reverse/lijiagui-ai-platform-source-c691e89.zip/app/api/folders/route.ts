import { requireUser, responseFromError } from "../../../server/auth/guards";
import { createFolder, listOwnedFolders } from "../../../server/domain/files";

export async function GET(request: Request) { try { const user = await requireUser(request); return Response.json({ folders: await listOwnedFolders(user.userId) }); } catch (error) { return responseFromError(error); } }
export async function POST(request: Request) { try { const user = await requireUser(request, true); const body = await request.json() as { name?: string; parentId?: string | null }; if (!body.name) return Response.json({ error: "请输入文件夹名称" }, { status: 400 }); return Response.json({ folder: await createFolder(user.userId, body.name, body.parentId) }, { status: 201 }); } catch (error) { return responseFromError(error); } }
