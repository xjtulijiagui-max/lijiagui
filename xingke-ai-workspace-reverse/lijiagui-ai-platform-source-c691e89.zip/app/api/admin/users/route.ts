import { requireAdmin, responseFromError } from "../../../../server/auth/guards";
import { createManagedUser, listUsers } from "../../../../server/domain/users";

export async function GET(request: Request) {
  try { await requireAdmin(request); return Response.json({ users: await listUsers() }); }
  catch (error) { return responseFromError(error); }
}

export async function POST(request: Request) {
  try {
    const admin = await requireAdmin(request, true);
    const body = await request.json() as { phone?: string; username?: string; displayName?: string; role?: "admin" | "member"; password?: string };
    const username = body.phone?.trim() || body.username?.trim();
    if (!username) return Response.json({ error: "请输入手机号码" }, { status: 400 });
    if (body.phone && !/^1[3-9]\d{9}$/u.test(body.phone.trim())) return Response.json({ error: "请输入有效的 11 位手机号码" }, { status: 400 });
    return Response.json(await createManagedUser({ username, displayName: body.displayName, role: body.role, password: body.password }, admin.userId), { status: 201 });
  } catch (error) {
    if (error instanceof Error && /username|reserved|unique|password|密码|role/i.test(error.message)) return Response.json({ error: error.message }, { status: 400 });
    return responseFromError(error);
  }
}
