import { requireAdmin, responseFromError } from "../../../../../server/auth/guards";
import { mutateManagedUser } from "../../../../../server/domain/users";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin(request, true);
    const { id } = await context.params;
    const body = await request.json() as { action?: string; role?: "admin" | "member" };
    if (!body.action) return Response.json({ error: "缺少操作" }, { status: 400 });
    return Response.json(await mutateManagedUser(id, { action: body.action, role: body.role }, admin.userId));
  } catch (error) { return responseFromError(error); }
}
