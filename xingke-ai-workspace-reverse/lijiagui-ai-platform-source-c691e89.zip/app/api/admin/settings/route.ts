import { requireAdmin, responseFromError } from "../../../../server/auth/guards";
import { audit } from "../../../../server/domain/users";
import { getWorkspaceSettings, saveWorkspaceSettings } from "../../../../server/domain/workspace-settings";

export async function GET(request: Request) { try { await requireAdmin(request); return Response.json({ settings: await getWorkspaceSettings() }); } catch (error) { return responseFromError(error); } }
export async function PUT(request: Request) { try { const admin = await requireAdmin(request, true); const settings = await saveWorkspaceSettings(await request.json(), admin.userId); await audit("admin.settings.update", admin.userId, "system_settings", "workspace_limits"); return Response.json({ settings }); } catch (error) { return responseFromError(error); } }
