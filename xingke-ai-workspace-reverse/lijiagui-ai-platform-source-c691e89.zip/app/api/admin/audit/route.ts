import { requireAdmin, responseFromError } from "../../../../server/auth/guards";
import { listAuditLogs } from "../../../../server/domain/audit";
export async function GET(request: Request) { try { await requireAdmin(request); return Response.json({ logs: await listAuditLogs(100) }); } catch (error) { return responseFromError(error); } }
