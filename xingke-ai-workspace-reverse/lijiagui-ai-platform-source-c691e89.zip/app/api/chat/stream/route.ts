import { buildConversationContext } from "../../../../server/bigmodel/context";
import { BigModelError } from "../../../../server/bigmodel/errors";
import { streamChat } from "../../../../server/bigmodel/client";
import { parseBigModelSse } from "../../../../server/bigmodel/sse";
import { requireUser, responseFromError } from "../../../../server/auth/guards";
import { appendMessage, createConversation, findOwnedConversation, updateAssistantMessage } from "../../../../server/domain/conversations";
import { addTokenUsage, reserveRequestQuota } from "../../../../server/domain/quota";
import { getWorkspaceSettings } from "../../../../server/domain/workspace-settings";
import { resolveSelectedCapabilities } from "../../../../server/domain/capabilities";
import { applyAppPromptTemplate, resolveAppVersionForUser } from "../../../../server/domain/apps";

const encoder = new TextEncoder();
const allowedModels = new Set(["glm-5.3-flash"]);
function event(value: unknown) { return encoder.encode(`data: ${JSON.stringify(value)}\n\n`); }

export async function POST(request: Request) {
  try {
    const user = await requireUser(request, true);
    const body = await request.json() as { conversationId?: string; content?: string; scene?: string; model?: string; expertId?: string; skillIds?: string[]; appVersionId?: string };
    const content = body.content?.trim();
    if (!content || content.length > 20_000) return Response.json({ error: "任务内容须为 1–20,000 个字符" }, { status: 400 });
    let model = allowedModels.has(body.model ?? "") ? body.model! : "glm-5.3-flash";
    let expertId = body.expertId; let skillIds = body.skillIds ?? []; let appPrompt: string | undefined;
    if (!body.conversationId && body.appVersionId) { const app = await resolveAppVersionForUser(user.userId, body.appVersionId); model = app.model; expertId = app.expertId ?? undefined; skillIds = app.skillIds; appPrompt = app.promptTemplate; }
    if (!body.conversationId) await resolveSelectedCapabilities(user.userId, expertId, skillIds);
    const conversation = body.conversationId ? await findOwnedConversation(body.conversationId, user.userId) : await createConversation(user.userId, { title: content.slice(0, 28), scene: body.scene, model, expertId, skillIds });
    await reserveRequestQuota(user.userId, model);
    if (appPrompt) await appendMessage({ conversationId: conversation.id, ownerUserId: user.userId, role: "system", content: applyAppPromptTemplate(appPrompt, content) });
    await appendMessage({ conversationId: conversation.id, ownerUserId: user.userId, role: "user", content });
    const assistantId = await appendMessage({ conversationId: conversation.id, ownerUserId: user.userId, role: "assistant", content: "", status: "streaming", model });
    const context = await buildConversationContext(conversation.id, user.userId);
    const settings = await getWorkspaceSettings();
    const upstream = await streamChat({ messages: context, model, signal: request.signal, maxTokens: settings.maxOutputTokens });
    const startedAt = Date.now();
    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        let full = ""; let promptTokens = 0; let completionTokens = 0;
        controller.enqueue(event({ type: "meta", conversationId: conversation.id, assistantMessageId: assistantId }));
        try {
          for await (const delta of parseBigModelSse(upstream.body!)) {
            if (delta.type === "content") { full += delta.content; controller.enqueue(event(delta)); }
            else if (delta.type === "usage") { promptTokens = delta.promptTokens; completionTokens = delta.completionTokens; }
            else if (delta.type === "done") break;
          }
          await updateAssistantMessage(assistantId, user.userId, { content: full, status: "complete", promptTokens, completionTokens, latencyMs: Date.now() - startedAt });
          await addTokenUsage(user.userId, model, promptTokens, completionTokens);
          controller.enqueue(event({ type: "done", usage: { promptTokens, completionTokens } }));
        } catch (error) {
          const code = error instanceof BigModelError ? error.code : request.signal.aborted ? "aborted" : "stream_interrupted";
          await updateAssistantMessage(assistantId, user.userId, { content: full, status: "failed", errorCode: code, latencyMs: Date.now() - startedAt });
          controller.enqueue(event({ type: "error", code, message: error instanceof Error ? error.message : "流式响应中断" }));
        } finally { controller.close(); }
      },
    });
    return new Response(stream, { headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" } });
  } catch (error) {
    if (error instanceof BigModelError) return Response.json({ error: error.message, code: error.code }, { status: error.status });
    if (error instanceof Error && /配额|请求次数|token/u.test(error.message)) return Response.json({ error: error.message }, { status: 429 });
    return responseFromError(error);
  }
}
