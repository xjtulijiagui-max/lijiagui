import { claimDueSchedules, runSchedule, verifySchedulerAccess } from "../../../../../server/domain/schedules";

export async function POST(request: Request) {
  try { await verifySchedulerAccess(request); const leases = await claimDueSchedules(new Date(), 10); const results = await Promise.allSettled(leases.map((lease) => runSchedule(lease))); return Response.json({ claimed: leases.length, succeeded: results.filter((result) => result.status === "fulfilled").length, failed: results.filter((result) => result.status === "rejected").length }); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Scheduler rejected" }, { status: 403 }); }
}
