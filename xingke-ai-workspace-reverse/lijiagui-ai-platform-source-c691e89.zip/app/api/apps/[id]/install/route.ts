import { requireUser, responseFromError } from "../../../../../server/auth/guards";
import { installApp } from "../../../../../server/domain/apps";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) { try { const user = await requireUser(request, true); const { id } = await context.params; const body = await request.json() as { versionId?: string }; if (!body.versionId) return Response.json({ error: "缺少应用版本" }, { status: 400 }); return Response.json(await installApp(user.userId, body.versionId, id)); } catch (error) { return responseFromError(error); } }
