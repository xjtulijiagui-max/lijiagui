import { requireUser, responseFromError } from "../../../../../server/auth/guards";
import { runScheduleManually } from "../../../../../server/domain/schedules";

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) { try { const user = await requireUser(request, true); const { id } = await context.params; return Response.json({ run: await runScheduleManually(user.userId, id) }); } catch (error) { return responseFromError(error); } }
