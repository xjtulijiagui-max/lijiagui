import type { Metadata } from "next";
import "./globals.css";
import "./capability-actions.css";

export const metadata: Metadata = {
  title: "李家贵AI中台",
  description: "面向团队的专家、技能、应用与文件一体化 AI 中台。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body className="antialiased">{children}</body></html>;
}
