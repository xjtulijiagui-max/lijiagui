"use client";

import { FormEvent, useCallback, useEffect, useState } from "react";
import { apiFetch } from "../../../lib/client-auth";

type User = { id: string; username: string; displayName: string; role: "admin" | "member"; status: "active" | "disabled"; mustChangePassword: boolean };

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([]); const [error, setError] = useState(""); const [secret, setSecret] = useState<{ username: string; password: string } | null>(null);
  const load = useCallback(async () => { const response = await apiFetch("/api/admin/users"); if (response.status === 401) { window.location.href = "/login"; return; } if (response.status === 403) { setError("仅管理员可访问此页面"); return; } const payload = await response.json() as { users?: User[]; error?: string }; setUsers(payload.users ?? []); setError(payload.error ?? ""); }, []);
  useEffect(() => { void load(); }, [load]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    const response = await apiFetch("/api/admin/users", { method: "POST", body: JSON.stringify({ phone: form.get("phone"), password: form.get("password"), displayName: form.get("displayName"), role: form.get("role") }) });
    const payload = await response.json() as { username?: string; temporaryPassword?: string; error?: string };
    if (!response.ok) { setError(payload.error ?? "创建失败"); return; }
    setSecret({ username: payload.username!, password: payload.temporaryPassword! }); event.currentTarget.reset(); await load();
  }

  async function mutate(user: User, action: string, role?: "admin" | "member") {
    const response = await apiFetch(`/api/admin/users/${user.id}`, { method: "PATCH", body: JSON.stringify({ action, role }) });
    const payload = await response.json() as { temporaryPassword?: string; error?: string };
    if (!response.ok) { setError(payload.error ?? "操作失败"); return; }
    if (payload.temporaryPassword) setSecret({ username: user.username, password: payload.temporaryPassword });
    await load();
  }

  return <main className="admin-page"><header><div><p className="eyebrow">ADMIN CONSOLE</p><h1>用户与账号</h1><p className="muted">创建学员账号、重置临时密码并即时停用访问。</p></div><a href="/">返回工作台</a></header>
    {secret && <section className="one-time-secret"><strong>请立即保存，只显示这一次</strong><span>账号：{secret.username}</span><code>{secret.password}</code><button onClick={() => setSecret(null)}>我已保存</button></section>}
    <section className="admin-grid"><form className="admin-card" onSubmit={create}><h2>新增用户</h2><label>手机号码<input name="phone" inputMode="numeric" autoComplete="tel" pattern="1[3-9][0-9]{9}" placeholder="13800138000" required /></label><label>登录密码<input name="password" type="password" autoComplete="new-password" minLength={12} placeholder="至少 12 个字符" required /></label><label>显示名<input name="displayName" placeholder="学员姓名" /></label><label>角色<select name="role"><option value="member">学员</option><option value="admin">管理员</option></select></label><button>创建可登录账号</button></form>
      <section className="admin-card table-card"><div className="card-title"><h2>账号列表</h2><span>{users.length} 个账号</span></div>{error && <p className="form-error">{error}</p>}<div className="user-list">{users.map((user) => <article key={user.id}><div className="avatar">{user.displayName.slice(0, 1)}</div><div className="user-main"><strong>{user.displayName}</strong><span>@{user.username} · {user.role === "admin" ? "管理员" : "学员"}</span></div><span className={`status ${user.status}`}>{user.status === "active" ? "正常" : "已停用"}</span><div className="row-actions"><button onClick={() => void mutate(user, "reset-password")}>重置密码</button>{user.username !== "admin" && <><button onClick={() => void mutate(user, user.status === "active" ? "disable" : "enable")}>{user.status === "active" ? "停用" : "启用"}</button><button onClick={() => void mutate(user, "role", user.role === "admin" ? "member" : "admin")}>设为{user.role === "admin" ? "学员" : "管理员"}</button></>}</div></article>)}</div></section></section>
  </main>;
}
