"use client";

import { FormEvent, useState } from "react";
import { apiFetch } from "../../lib/client-auth";

export default function ChangePasswordPage() {
  const [message, setMessage] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    const response = await apiFetch("/api/auth/change-password", { method: "POST", body: JSON.stringify({ currentPassword: form.get("currentPassword"), nextPassword: form.get("nextPassword") }) });
    const payload = await response.json() as { error?: string };
    if (!response.ok) { setMessage(payload.error ?? "修改失败"); return; }
    window.location.href = "/";
  }
  return <main className="auth-page single"><section className="auth-panel"><div className="brand-mark">杏</div><p className="eyebrow">首次登录保护</p><h1>设置你的新密码</h1><p className="muted">新密码至少 12 个字符，保存后其他登录会话将失效。</p><form onSubmit={submit} className="auth-form"><label>当前临时密码<input name="currentPassword" type="password" required /></label><label>新密码<input name="nextPassword" type="password" minLength={12} required /></label>{message && <p className="form-error">{message}</p>}<button>保存并进入工作台</button></form></section></main>;
}
