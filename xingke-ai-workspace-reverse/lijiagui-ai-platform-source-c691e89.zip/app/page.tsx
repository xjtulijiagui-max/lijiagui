import { headers } from "next/headers";
import { redirect } from "next/navigation";

import { WorkspaceShell } from "../components/workspace/workspace-shell";
import type { WorkspaceModule } from "../components/workspace/main-nav";
import { requireUser } from "../server/auth/guards";

const modules = new Set<WorkspaceModule>(["task", "capabilities", "apps", "schedules", "drive", "admin"]);

export default async function Home({ searchParams }: { searchParams: Promise<{ module?: string }> }) {
  let user;
  try {
    user = await requireUser(new Request("https://workspace.local/", { headers: new Headers(await headers()) }));
  } catch (error) { if (error instanceof Response && error.status === 403) redirect("/change-password"); redirect("/login"); }
  const requested = (await searchParams).module as WorkspaceModule | undefined;
  const initialModule = requested && modules.has(requested) && (requested !== "admin" || user.role === "admin") ? requested : "task";
  return <WorkspaceShell user={{ id: user.userId, username: user.username, displayName: user.displayName, role: user.role, mustChangePassword: user.mustChangePassword }} initialModule={initialModule} />;
}
