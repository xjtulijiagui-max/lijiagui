import { env } from "cloudflare:workers";

function bucket(): R2Bucket { if (!env.BUCKET) throw new Error("R2 BUCKET binding is unavailable"); return env.BUCKET; }
export async function putObject(key: string, body: ArrayBuffer, type: string) { await bucket().put(key, body, { httpMetadata: { contentType: type, cacheControl: "private, max-age=0, no-store" } }); }
export async function getObject(key: string) { return bucket().get(key); }
export async function deleteObject(key: string) { await bucket().delete(key); }
