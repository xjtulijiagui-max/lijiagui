import { sha256 } from "./crypto";

export function assertSameOrigin(request: Request): void {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) throw new Response("Cross-origin request rejected", { status: 403 });
}

export async function assertCsrf(request: Request, expectedHash: string): Promise<void> {
  assertSameOrigin(request);
  const supplied = request.headers.get("x-csrf-token");
  const cookie = request.headers.get("cookie")?.match(/(?:^|;\s*)xk_csrf=([^;]+)/u)?.[1];
  if (!supplied || !cookie || supplied !== decodeURIComponent(cookie) || await sha256(supplied) !== expectedHash) {
    throw new Response("Invalid CSRF token", { status: 403 });
  }
}
