const allowedPaths = new Set(["/api/auth/me", "/api/auth/change-password", "/api/auth/logout"]);
export function canAccessBeforePasswordChange(pathname: string): boolean { return allowedPaths.has(pathname); }
