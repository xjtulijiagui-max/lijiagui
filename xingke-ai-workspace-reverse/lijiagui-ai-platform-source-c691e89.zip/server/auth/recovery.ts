export function recoveryTokenCanBeUsed(tokenHash: string, usedTokenHash: string | null): boolean {
  return tokenHash.length > 0 && tokenHash !== usedTokenHash;
}
