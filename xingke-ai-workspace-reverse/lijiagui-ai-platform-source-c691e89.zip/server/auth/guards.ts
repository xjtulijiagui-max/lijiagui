import { assertCsrf } from "./csrf";
import { lookupSession } from "./session";
import { canAccessBeforePasswordChange } from "./password-change-policy";
export { assertAdminRole } from "./authorization";

export type AuthUser = NonNullable<Awaited<ReturnType<typeof lookupSession>>>;

export async function requireUser(request: Request, mutation = false): Promise<AuthUser> {
  const user = await lookupSession(request);
  if (!user) throw new Response("Unauthorized", { status: 401 });
  if (user.mustChangePassword && !canAccessBeforePasswordChange(new URL(request.url).pathname)) throw new Response("Password change required", { status: 403 });
  if (mutation) await assertCsrf(request, user.csrfTokenHash);
  return user;
}

export async function requireAdmin(request: Request, mutation = false): Promise<AuthUser> {
  const user = await requireUser(request, mutation);
  if (user.role !== "admin") throw new Response("Forbidden", { status: 403 });
  return user;
}

export function responseFromError(error: unknown): Response {
  if (error instanceof Response) return error;
  console.error("Request failed", error instanceof Error ? error.message : "Unknown error");
  return Response.json({ error: "服务器处理失败" }, { status: 500 });
}
