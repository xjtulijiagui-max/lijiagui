import { env } from "cloudflare:workers";
import { and, eq, gt } from "drizzle-orm";

import { getDb } from "../../db";
import { sessions, users } from "../../db/schema";
import { randomToken, sha256 } from "./crypto";
import { buildSessionCookies, SESSION_COOKIE } from "./cookie";

const SESSION_TTL_MS = 7 * 24 * 60 * 60_000;

export type SessionCookie = { session: string; csrf: string; csrfToken: string; expiresAt: Date };

function sessionPepper(): string {
  if (!env.SESSION_PEPPER) throw new Error("SESSION_PEPPER is not configured");
  return env.SESSION_PEPPER;
}

export async function hashSessionToken(token: string): Promise<string> {
  return sha256(`${sessionPepper()}:${token}`);
}

export async function createSession(userId: string, request?: Request): Promise<SessionCookie> {
  const token = randomToken(32);
  const csrfToken = randomToken(24);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_TTL_MS);
  await getDb().insert(sessions).values({
    id: crypto.randomUUID(), userId, tokenHash: await hashSessionToken(token), csrfTokenHash: await sha256(csrfToken),
    expiresAt, lastActivityAt: now, userAgent: request?.headers.get("user-agent")?.slice(0, 300) ?? null,
    ipHash: request ? await sha256(request.headers.get("cf-connecting-ip") ?? "local") : null, createdAt: now, updatedAt: now,
  });
  return { ...buildSessionCookies(token, csrfToken, expiresAt), csrfToken, expiresAt };
}

export async function revokeUserSessions(userId: string): Promise<void> {
  await getDb().delete(sessions).where(eq(sessions.userId, userId));
}

export function expiredSessionCookies(): string[] {
  return [
    `${SESSION_COOKIE}=; Path=/; Secure; SameSite=Lax; HttpOnly; Max-Age=0`,
    "xk_csrf=; Path=/; Secure; SameSite=Lax; Max-Age=0",
  ];
}

export async function lookupSession(request: Request) {
  const token = request.headers.get("cookie")?.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`, "u"))?.[1];
  if (!token) return null;
  const tokenHash = await hashSessionToken(decodeURIComponent(token));
  const now = new Date();
  const rows = await getDb().select({
    sessionId: sessions.id, csrfTokenHash: sessions.csrfTokenHash, userId: users.id, username: users.username,
    displayName: users.displayName, role: users.role, status: users.status, mustChangePassword: users.mustChangePassword,
  }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).where(and(eq(sessions.tokenHash, tokenHash), gt(sessions.expiresAt, now))).limit(1);
  const result = rows[0];
  if (!result || result.status !== "active") return null;
  await getDb().update(sessions).set({ lastActivityAt: now, updatedAt: now }).where(eq(sessions.id, result.sessionId));
  return result;
}
