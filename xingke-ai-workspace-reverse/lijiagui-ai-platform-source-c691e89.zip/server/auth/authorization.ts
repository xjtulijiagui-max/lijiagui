export function assertAdminRole(user: { role: string }): void {
  if (user.role !== "admin") throw new Error("Forbidden: administrator role required");
}
