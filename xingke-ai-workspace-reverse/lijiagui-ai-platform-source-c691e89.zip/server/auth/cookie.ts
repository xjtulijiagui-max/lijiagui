export const SESSION_COOKIE = "__Host-xk_session";

export function buildSessionCookies(token: string, csrfToken: string, expiresAt: Date) {
  const common = `Path=/; Secure; SameSite=Lax; Expires=${expiresAt.toUTCString()}`;
  return {
    session: `${SESSION_COOKIE}=${encodeURIComponent(token)}; ${common}; HttpOnly`,
    csrf: `xk_csrf=${encodeURIComponent(csrfToken)}; ${common}`,
  };
}
