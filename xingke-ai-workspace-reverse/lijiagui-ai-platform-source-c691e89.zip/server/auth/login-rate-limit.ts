export type LoginLockDecision = { locked: boolean; retryAfterSeconds: number };

const WINDOW_MS = 15 * 60_000;
const LOCK_MS = 10 * 60_000;

export function decideLoginLock(failureTimes: number[], now = Date.now()): LoginLockDecision {
  const recent = failureTimes.filter((time) => time >= now - WINDOW_MS).sort((a, b) => b - a);
  if (recent.length < 5) return { locked: false, retryAfterSeconds: 0 };
  const unlockAt = recent[0] + LOCK_MS;
  return unlockAt > now
    ? { locked: true, retryAfterSeconds: Math.ceil((unlockAt - now) / 1000) }
    : { locked: false, retryAfterSeconds: 0 };
}
