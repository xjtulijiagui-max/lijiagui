import { env } from "cloudflare:workers";

export type RuntimeConfig = {
  hasBigModelApiKey: boolean;
  hasInitialAdminPassword: boolean;
  hasAdminRecoveryToken: boolean;
  hasSessionPepper: boolean;
  hasSchedulerToken: boolean;
};

export function getRuntimeConfig(): RuntimeConfig {
  return Object.freeze({
    hasBigModelApiKey: Boolean(env.BIGMODEL_API_KEY),
    hasInitialAdminPassword: Boolean(env.INITIAL_ADMIN_PASSWORD),
    hasAdminRecoveryToken: Boolean(env.ADMIN_RECOVERY_TOKEN),
    hasSessionPepper: Boolean(env.SESSION_PEPPER),
    hasSchedulerToken: Boolean(env.SCHEDULER_TOKEN),
  });
}

export function getServerSecrets() {
  return {
    bigModelApiKey: env.BIGMODEL_API_KEY,
    initialAdminPassword: env.INITIAL_ADMIN_PASSWORD,
    adminRecoveryToken: env.ADMIN_RECOVERY_TOKEN,
    sessionPepper: env.SESSION_PEPPER,
    schedulerToken: env.SCHEDULER_TOKEN,
  };
}
