export type ClaimableSchedule = { enabled: boolean; nextRunAt: Date | null; leaseExpiresAt: Date | null };
export const SCHEDULE_LEASE_MS = 10 * 60_000;
export const SCHEDULE_EXECUTION_TIMEOUT_MS = 8 * 60_000;
export function shouldClaimSchedule(schedule: ClaimableSchedule, now: Date): boolean { return schedule.enabled && Boolean(schedule.nextRunAt && schedule.nextRunAt <= now) && (!schedule.leaseExpiresAt || schedule.leaseExpiresAt <= now); }
export function assertScheduleDailyQuota(runCount: number, limit = 20): void { if (runCount >= limit) throw new Error(`Daily schedule quota of ${limit} runs reached`); }
export function verifySchedulerHeaders(headers: Headers, expectedToken: string): void {
  if (headers.get("x-scheduler-service") !== "sites-managed") throw new Error("Missing managed service access");
  if (!expectedToken || headers.get("authorization") !== `Bearer ${expectedToken}`) throw new Error("Invalid scheduler token");
}
