import { and, desc, eq, or } from "drizzle-orm";
import { appVersions, apps, experts, skills, userApps } from "../../db/schema";

export function assertCanPublishPublicApp(role: string): void { if (role !== "admin") throw new Error("Admin role required to publish public apps"); }
export function selectInstalledVersion(versionId: string): string { if (!versionId) throw new Error("Version required"); return versionId; }
export function isAllowedAppModel(model: string): boolean { return model === "glm-5.3-flash"; }
export function applyAppPromptTemplate(template: string, input: string): string { const normalized = template.trim(); if (!normalized) return input; return normalized.includes("{{input}}") ? normalized.replaceAll("{{input}}", input) : `${normalized}\n\n用户输入：${input}`; }
async function db() { return (await import("../../db")).getDb(); }

async function validateAppCapabilities(userId: string, definition: { expertId?: string; skillIds?: string[]; model?: string }, requirePublic = false) {
  const database = await db(); const model = definition.model ?? "glm-5.3-flash"; if (!isAllowedAppModel(model)) throw new Response("Model not allowed", { status: 400 });
  if (definition.expertId) { const [expert] = await database.select().from(experts).where(eq(experts.id, definition.expertId)).limit(1); if (!expert || !expert.enabled || (expert.visibility !== "public" && expert.ownerUserId !== userId)) throw new Response("Expert not found", { status: 404 }); if (requirePublic && expert.visibility !== "public") throw new Response("Public apps can only use public experts", { status: 400 }); }
  const skillIds = [...new Set(definition.skillIds ?? [])]; if (skillIds.length > 12) throw new Response("Too many skills", { status: 400 });
  for (const skillId of skillIds) { const [skill] = await database.select().from(skills).where(eq(skills.id, skillId)).limit(1); if (!skill || !skill.enabled || (skill.visibility !== "public" && skill.ownerUserId !== userId)) throw new Response("Skill not found", { status: 404 }); if (requirePublic && skill.visibility !== "public") throw new Response("Public apps can only use public skills", { status: 400 }); }
  return { model, skillIds };
}

export async function createAppVersion(appId: string, definition: { expertId?: string; skillIds?: string[]; model?: string; promptTemplate?: string; createdByUserId: string }) {
  const database = await db(); const [app] = await database.select({ visibility: apps.visibility }).from(apps).where(eq(apps.id, appId)).limit(1); if (!app) throw new Response("App not found", { status: 404 }); const validated = await validateAppCapabilities(definition.createdByUserId, definition, app.visibility === "public"); const [latest] = await database.select({ version: appVersions.version }).from(appVersions).where(eq(appVersions.appId, appId)).orderBy(desc(appVersions.version)).limit(1);
  const now = new Date(); const record = { id: crypto.randomUUID(), appId, version: (latest?.version ?? 0) + 1, expertId: definition.expertId, skillIdsJson: JSON.stringify(validated.skillIds), model: validated.model, promptTemplate: definition.promptTemplate ?? "", createdByUserId: definition.createdByUserId, createdAt: now, updatedAt: now };
  await database.insert(appVersions).values(record); await database.update(apps).set({ currentVersionId: record.id, updatedAt: now }).where(eq(apps.id, appId)); return record;
}

export async function createApp(ownerUserId: string, role: string, input: { name: string; description?: string; visibility?: "public" | "private"; expertId?: string; skillIds?: string[]; promptTemplate?: string }) {
  const visibility = input.visibility ?? "private"; if (visibility === "public") assertCanPublishPublicApp(role); const validated = await validateAppCapabilities(ownerUserId, input, visibility === "public"); const now = new Date(); const id = crypto.randomUUID();
  await (await db()).insert(apps).values({ id, ownerUserId, name: input.name.trim().slice(0, 60), description: input.description?.trim().slice(0, 240) ?? "", visibility, enabled: true, createdAt: now, updatedAt: now });
  const version = await createAppVersion(id, { expertId: input.expertId, skillIds: validated.skillIds, model: validated.model, promptTemplate: input.promptTemplate, createdByUserId: ownerUserId }); return { id, version };
}

export async function listApps(userId: string) {
  return (await db()).select().from(apps).where(and(eq(apps.enabled, true), or(eq(apps.visibility, "public"), eq(apps.ownerUserId, userId)))).orderBy(desc(apps.updatedAt));
}

export async function resolveAppVersionForUser(userId: string, versionId: string) {
  const [version] = await (await db()).select({ id: appVersions.id, appId: appVersions.appId, expertId: appVersions.expertId, skillIdsJson: appVersions.skillIdsJson, model: appVersions.model, promptTemplate: appVersions.promptTemplate, appName: apps.name, visibility: apps.visibility, ownerUserId: apps.ownerUserId, enabled: apps.enabled }).from(appVersions).innerJoin(apps, eq(appVersions.appId, apps.id)).where(eq(appVersions.id, versionId)).limit(1);
  if (!version || !version.enabled || (version.visibility !== "public" && version.ownerUserId !== userId)) throw new Response("App version not found", { status: 404 });
  const skillIds = JSON.parse(version.skillIdsJson || "[]") as string[];
  await validateAppCapabilities(userId, { expertId: version.expertId ?? undefined, skillIds, model: version.model });
  return { ...version, skillIds };
}

export async function installApp(userId: string, versionId: string, expectedAppId?: string) {
  const database = await db(); const [version] = await database.select({ id: appVersions.id, appId: appVersions.appId, visibility: apps.visibility, ownerUserId: apps.ownerUserId }).from(appVersions).innerJoin(apps, eq(appVersions.appId, apps.id)).where(eq(appVersions.id, selectInstalledVersion(versionId))).limit(1);
  if (!version || (expectedAppId && version.appId !== expectedAppId) || (version.visibility !== "public" && version.ownerUserId !== userId)) throw new Response("Not found", { status: 404 }); const now = new Date(); const record = { id: crypto.randomUUID(), ownerUserId: userId, appId: version.appId, pinnedVersionId: version.id, createdAt: now, updatedAt: now };
  await database.insert(userApps).values(record).onConflictDoUpdate({ target: [userApps.ownerUserId, userApps.appId], set: { pinnedVersionId: version.id, updatedAt: now } }); return record;
}
