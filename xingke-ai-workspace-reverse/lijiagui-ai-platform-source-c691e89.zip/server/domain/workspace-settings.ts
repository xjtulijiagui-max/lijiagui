import { eq } from "drizzle-orm";

import { systemSettings } from "../../db/schema";

async function db() { return (await import("../../db")).getDb(); }

export type WorkspaceSettings = {
  allowedModels: ["glm-5.3-flash"];
  defaultModel: "glm-5.3-flash";
  maxOutputTokens: number;
  dailyRequestQuota: number;
  dailyTokenQuota: number;
  maxActiveSchedules: number;
  dailyScheduleRuns: number;
  userStorageMb: number;
  maxFileMb: number;
};

export const DEFAULT_WORKSPACE_SETTINGS: WorkspaceSettings = {
  allowedModels: ["glm-5.3-flash"],
  defaultModel: "glm-5.3-flash",
  maxOutputTokens: 4096,
  dailyRequestQuota: 50,
  dailyTokenQuota: 200_000,
  maxActiveSchedules: 5,
  dailyScheduleRuns: 20,
  userStorageMb: 200,
  maxFileMb: 20,
};

const ranges = {
  maxOutputTokens: [256, 8192],
  dailyRequestQuota: [1, 10_000],
  dailyTokenQuota: [1_000, 50_000_000],
  maxActiveSchedules: [0, 100],
  dailyScheduleRuns: [0, 1_000],
  userStorageMb: [10, 10_240],
  maxFileMb: [1, 100],
} as const;

export function normalizeWorkspaceSettings(input: unknown): WorkspaceSettings {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Response("设置格式无效", { status: 400 });
  const source = input as Record<string, unknown>;
  const result = { ...DEFAULT_WORKSPACE_SETTINGS };
  for (const [key, [minimum, maximum]] of Object.entries(ranges) as Array<[keyof typeof ranges, readonly [number, number]]>) {
    if (source[key] === undefined) continue;
    const value = source[key];
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum || value > maximum) {
      throw new Response(`${key} 必须是 ${minimum}–${maximum} 的整数`, { status: 400 });
    }
    result[key] = value;
  }
  if (result.maxFileMb > result.userStorageMb) throw new Response("单文件上限不能超过用户云盘容量", { status: 400 });
  return result;
}

export async function getWorkspaceSettings(): Promise<WorkspaceSettings> {
  const [row] = await (await db()).select().from(systemSettings).where(eq(systemSettings.key, "workspace_limits")).limit(1);
  if (!row) return { ...DEFAULT_WORKSPACE_SETTINGS };
  try { return normalizeWorkspaceSettings({ ...DEFAULT_WORKSPACE_SETTINGS, ...JSON.parse(row.valueJson) }); }
  catch { return { ...DEFAULT_WORKSPACE_SETTINGS }; }
}

export async function saveWorkspaceSettings(input: unknown, userId: string): Promise<WorkspaceSettings> {
  const settings = normalizeWorkspaceSettings(input);
  const now = new Date();
  await (await db()).insert(systemSettings).values({ id: crypto.randomUUID(), key: "workspace_limits", valueJson: JSON.stringify(settings), updatedByUserId: userId, createdAt: now, updatedAt: now })
    .onConflictDoUpdate({ target: systemSettings.key, set: { valueJson: JSON.stringify(settings), updatedByUserId: userId, updatedAt: now } });
  return settings;
}
