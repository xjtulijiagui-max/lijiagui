import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { files, folders } from "../../db/schema";
import { validateStorageQuota, validateUpload } from "./file-policy";
import { getWorkspaceSettings } from "./workspace-settings";

export function buildOwnedObjectKey(userId: string, name: string, id = crypto.randomUUID()): string {
  const safeUser = userId.replace(/[^a-zA-Z0-9_-]/gu, "_"); const safeName = name.normalize("NFC").replace(/[^\p{L}\p{N}._ -]/gu, "_").replace(/\.{2,}/gu, ".");
  return `users/${safeUser}/${id}/${safeName}`;
}
export function assertOwnedFile(file: { ownerUserId: string; deletedAt: Date | null } | null | undefined, userId: string): void { if (!file || file.ownerUserId !== userId || file.deletedAt) throw new Error("File not found"); }
export function assertOwnedFolder(folder: { ownerUserId: string; deletedAt: Date | null } | null | undefined, userId: string): void { if (!folder || folder.ownerUserId !== userId || folder.deletedAt) throw new Response("Folder not found", { status: 404 }); }
export function requireAttachmentConfirmation(confirmed: boolean, ids: string[]): void { if (ids.length && !confirmed) throw new Error("Confirm third-party file processing before attaching files"); }
async function db() { return (await import("../../db")).getDb(); }

export async function listOwnedFiles(userId: string, options: { folderId?: string | null; trash?: boolean } = {}) {
  const conditions = [eq(files.ownerUserId, userId), options.trash ? sql`${files.deletedAt} is not null` : isNull(files.deletedAt)]; if (options.folderId) conditions.push(eq(files.folderId, options.folderId));
  return (await db()).select().from(files).where(and(...conditions)).orderBy(desc(files.updatedAt));
}
export async function listOwnedFolders(userId: string) { return (await db()).select().from(folders).where(and(eq(folders.ownerUserId, userId), isNull(folders.deletedAt))).orderBy(folders.name); }
export async function createFolder(userId: string, name: string, parentId?: string | null) { const now = new Date(); const record = { id: crypto.randomUUID(), ownerUserId: userId, parentId: parentId ?? null, name: name.trim().slice(0, 80), createdAt: now, updatedAt: now }; if (!record.name) throw new Response("Invalid folder name", { status: 400 }); await (await db()).insert(folders).values(record); return record; }

export async function putOwnedFile(userId: string, file: File, folderId?: string | null) {
  const limits = await getWorkspaceSettings(); const policy = validateUpload({ name: file.name, type: file.type, size: file.size }, limits.maxFileMb * 1024 * 1024); if (!policy.ok) throw new Response(policy.error, { status: 400 });
  const database = await db(); const [{ total }] = await database.select({ total: sql<number>`coalesce(sum(${files.sizeBytes}), 0)` }).from(files).where(and(eq(files.ownerUserId, userId), isNull(files.deletedAt))); validateStorageQuota(Number(total), file.size, limits.userStorageMb * 1024 * 1024);
  if (folderId) { const [folder] = await database.select().from(folders).where(and(eq(folders.id, folderId), eq(folders.ownerUserId, userId), isNull(folders.deletedAt))).limit(1); assertOwnedFolder(folder, userId); }
  const id = crypto.randomUUID(); const r2Key = buildOwnedObjectKey(userId, file.name, id); const bytes = await file.arrayBuffer(); const digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (byte) => byte.toString(16).padStart(2, "0")).join(""); const storage = await import("../storage/files");
  await storage.putObject(r2Key, bytes, file.type); const now = new Date(); const record = { id, ownerUserId: userId, folderId: folderId ?? null, r2Key, name: file.name.normalize("NFC"), mimeType: file.type, sizeBytes: file.size, checksumSha256: digest, createdAt: now, updatedAt: now };
  try { await database.insert(files).values(record); } catch (error) { await storage.deleteObject(r2Key); throw error; } return record;
}

export async function getOwnedFile(userId: string, id: string, includeDeleted = false) { const [file] = await (await db()).select().from(files).where(and(eq(files.id, id), eq(files.ownerUserId, userId))).limit(1); if (!file || (!includeDeleted && file.deletedAt)) return null; return file; }
export async function mutateOwnedFile(userId: string, id: string, input: { name?: string; folderId?: string | null; deleted?: boolean; restore?: boolean }) { const database = await db(); const file = await getOwnedFile(userId, id, Boolean(input.restore)); if (!file) throw new Response("Not found", { status: 404 }); if (input.folderId) { const [folder] = await database.select().from(folders).where(and(eq(folders.id, input.folderId), eq(folders.ownerUserId, userId), isNull(folders.deletedAt))).limit(1); assertOwnedFolder(folder, userId); } const now = new Date(); await database.update(files).set({ ...(input.name ? { name: input.name.trim().slice(0, 180) } : {}), ...(input.folderId !== undefined ? { folderId: input.folderId } : {}), ...(input.deleted ? { deletedAt: now } : {}), ...(input.restore ? { deletedAt: null } : {}), updatedAt: now }).where(and(eq(files.id, id), eq(files.ownerUserId, userId))); }

export async function resolveModelAttachments(userId: string, ids: string[], confirmed = false) {
  requireAttachmentConfirmation(confirmed, ids); const storage = await import("../storage/files"); const attachments = [];
  for (const id of ids.slice(0, 5)) { const file = await getOwnedFile(userId, id); if (!file) throw new Response("File not found", { status: 404 }); const object = await storage.getObject(file.r2Key); if (!object) throw new Response("File data missing", { status: 410 }); if (/^(text\/|application\/json)/u.test(file.mimeType) && file.sizeBytes <= 500_000) attachments.push({ id, name: file.name, mimeType: file.mimeType, text: await object.text() }); else attachments.push({ id, name: file.name, mimeType: file.mimeType, sizeBytes: file.sizeBytes }); }
  return attachments;
}
