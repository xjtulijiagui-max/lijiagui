import { and, desc, eq, isNull } from "drizzle-orm";
import { conversations, messages } from "../../db/schema";

export function assertConversationOwner(conversation: { ownerUserId: string } | null | undefined, userId: string): void {
  if (!conversation || conversation.ownerUserId !== userId) throw new Error("Conversation not found");
}

async function db() { return (await import("../../db")).getDb(); }

export async function createConversation(ownerUserId: string, input: { title?: string; scene?: string; model?: string; expertId?: string; skillIds?: string[] } = {}) {
  const now = new Date(); const id = crypto.randomUUID();
  const record = { id, ownerUserId, title: input.title?.trim().slice(0, 80) || "新任务", scene: input.scene ?? "general", model: input.model ?? "glm-5.3-flash", expertId: input.expertId, skillIdsJson: JSON.stringify(input.skillIds ?? []), createdAt: now, updatedAt: now };
  await (await db()).insert(conversations).values(record);
  return record;
}

export async function listConversations(ownerUserId: string) {
  return (await db()).select().from(conversations).where(and(eq(conversations.ownerUserId, ownerUserId), isNull(conversations.deletedAt), isNull(conversations.archivedAt))).orderBy(desc(conversations.updatedAt));
}

export async function findOwnedConversation(id: string, ownerUserId: string) {
  const [conversation] = await (await db()).select().from(conversations).where(and(eq(conversations.id, id), eq(conversations.ownerUserId, ownerUserId), isNull(conversations.deletedAt))).limit(1);
  if (!conversation) throw new Response("Not found", { status: 404 });
  return conversation;
}

export async function getConversationMessages(id: string, ownerUserId: string) {
  const conversation = await findOwnedConversation(id, ownerUserId);
  const rows = await (await db()).select().from(messages).where(and(eq(messages.conversationId, id), eq(messages.ownerUserId, ownerUserId))).orderBy(messages.createdAt);
  return { conversation, messages: rows };
}

export async function mutateConversation(id: string, ownerUserId: string, input: { title?: string; archived?: boolean }) {
  await findOwnedConversation(id, ownerUserId); const now = new Date();
  await (await db()).update(conversations).set({ ...(input.title ? { title: input.title.trim().slice(0, 80) || "新任务" } : {}), ...(input.archived !== undefined ? { archivedAt: input.archived ? now : null } : {}), updatedAt: now }).where(and(eq(conversations.id, id), eq(conversations.ownerUserId, ownerUserId)));
}

export async function appendMessage(input: { conversationId: string; ownerUserId: string; role: "system" | "user" | "assistant"; content: string; status?: "pending" | "streaming" | "complete" | "failed"; model?: string }) {
  const now = new Date(); const id = crypto.randomUUID();
  await (await db()).insert(messages).values({ id, conversationId: input.conversationId, ownerUserId: input.ownerUserId, role: input.role, content: input.content, status: input.status ?? "complete", model: input.model, createdAt: now, updatedAt: now });
  await (await db()).update(conversations).set({ updatedAt: now }).where(and(eq(conversations.id, input.conversationId), eq(conversations.ownerUserId, input.ownerUserId)));
  return id;
}

export async function updateAssistantMessage(id: string, ownerUserId: string, input: { content: string; status: "streaming" | "complete" | "failed"; promptTokens?: number; completionTokens?: number; latencyMs?: number; errorCode?: string }) {
  await (await db()).update(messages).set({ ...input, updatedAt: new Date() }).where(and(eq(messages.id, id), eq(messages.ownerUserId, ownerUserId)));
}
