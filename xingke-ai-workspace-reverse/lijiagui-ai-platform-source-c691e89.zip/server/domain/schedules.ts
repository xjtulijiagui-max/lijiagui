import { and, count, eq, gte, isNull, lte, or } from "drizzle-orm";
import { scheduleRuns, schedules } from "../../db/schema";
import { parseBigModelSse } from "../bigmodel/sse";
import { streamChat } from "../bigmodel/client";
import { buildConversationContext } from "../bigmodel/context";
import { appendMessage, createConversation, updateAssistantMessage } from "./conversations";
import { addTokenUsage, reserveRequestQuota } from "./quota";
import { assertScheduleDailyQuota, SCHEDULE_EXECUTION_TIMEOUT_MS, SCHEDULE_LEASE_MS, verifySchedulerHeaders } from "./lease";
import { getWorkspaceSettings } from "./workspace-settings";
import { applyAppPromptTemplate, resolveAppVersionForUser } from "./apps";

export type ScheduleLease = typeof schedules.$inferSelect & { leaseToken: string };
const LEASE_RENEWAL_INTERVAL_MS = 60_000;
async function db() { return (await import("../../db")).getDb(); }
export function calculateNextRun(frequency: string, from = new Date()): Date { const ms = frequency === "hourly" ? 60 * 60_000 : frequency === "weekly" ? 7 * 24 * 60 * 60_000 : frequency === "every_5_minutes" ? 5 * 60_000 : 24 * 60 * 60_000; return new Date(from.getTime() + ms); }

export async function verifySchedulerAccess(request: Request): Promise<void> { const { env } = await import("cloudflare:workers"); verifySchedulerHeaders(request.headers, env.SCHEDULER_TOKEN ?? ""); }

export async function listSchedules(userId: string) { return (await db()).select().from(schedules).where(eq(schedules.ownerUserId, userId)); }
export async function createSchedule(userId: string, input: { name: string; prompt: string; appVersionId?: string; frequency?: string; timezone?: string; enabled?: boolean }) {
  const database = await db(); const enabled = input.enabled ?? false; const limits = await getWorkspaceSettings();
  if (input.appVersionId) await resolveAppVersionForUser(userId, input.appVersionId);
  if (enabled) { const [{ value }] = await database.select({ value: count() }).from(schedules).where(and(eq(schedules.ownerUserId, userId), eq(schedules.enabled, true))); if (value >= limits.maxActiveSchedules) throw new Response(`最多启用 ${limits.maxActiveSchedules} 个定时任务`, { status: 429 }); }
  const now = new Date(); const record = { id: crypto.randomUUID(), ownerUserId: userId, name: input.name.trim().slice(0, 80), prompt: input.prompt.trim().slice(0, 20_000), appVersionId: input.appVersionId, frequency: input.frequency ?? "daily", timezone: input.timezone ?? "Asia/Shanghai", enabled, nextRunAt: enabled ? calculateNextRun(input.frequency ?? "daily", now) : null, createdAt: now, updatedAt: now };
  await database.insert(schedules).values(record); return record;
}

export async function claimDueSchedules(now = new Date(), limit = 10): Promise<ScheduleLease[]> {
  const database = await db(); const due = await database.select().from(schedules).where(and(eq(schedules.enabled, true), lte(schedules.nextRunAt, now), or(isNull(schedules.leaseExpiresAt), lte(schedules.leaseExpiresAt, now)))).limit(Math.min(limit, 25)); const claimed: ScheduleLease[] = [];
  for (const schedule of due) { const token = crypto.randomUUID(); const rows = await database.update(schedules).set({ leaseToken: token, leaseExpiresAt: new Date(now.getTime() + SCHEDULE_LEASE_MS), updatedAt: now }).where(and(eq(schedules.id, schedule.id), or(isNull(schedules.leaseExpiresAt), lte(schedules.leaseExpiresAt, now)))).returning(); if (rows[0]) claimed.push({ ...rows[0], leaseToken: token }); }
  return claimed;
}

export async function runSchedule(lease: ScheduleLease, source: "manual" | "scheduler" = "scheduler") {
  const database = await db(); const limits = await getWorkspaceSettings(); const dayStart = new Date(); dayStart.setUTCHours(0, 0, 0, 0); const [{ value }] = await database.select({ value: count() }).from(scheduleRuns).where(and(eq(scheduleRuns.ownerUserId, lease.ownerUserId), gte(scheduleRuns.createdAt, dayStart))); assertScheduleDailyQuota(value, limits.dailyScheduleRuns);
  const now = new Date(); const runId = crypto.randomUUID(); await database.insert(scheduleRuns).values({ id: runId, scheduleId: lease.id, ownerUserId: lease.ownerUserId, status: "running", startedAt: now, createdAt: now, updatedAt: now });
  let conversationId: string | undefined; let assistantId: string | undefined; let full = ""; let promptTokens = 0; let completionTokens = 0; let renewedAt = Date.now();
  try {
    const app = lease.appVersionId ? await resolveAppVersionForUser(lease.ownerUserId, lease.appVersionId) : null; const model = app?.model ?? "glm-5.3-flash";
    await reserveRequestQuota(lease.ownerUserId, model); const conversation = await createConversation(lease.ownerUserId, { title: `定时 · ${lease.name}`, scene: "general", model, expertId: app?.expertId ?? undefined, skillIds: app?.skillIds ?? [] }); conversationId = conversation.id;
    if (app?.promptTemplate) await appendMessage({ conversationId, ownerUserId: lease.ownerUserId, role: "system", content: applyAppPromptTemplate(app.promptTemplate, lease.prompt) });
    await appendMessage({ conversationId, ownerUserId: lease.ownerUserId, role: "user", content: lease.prompt }); assistantId = await appendMessage({ conversationId, ownerUserId: lease.ownerUserId, role: "assistant", content: "", status: "streaming", model });
    const response = await streamChat({ messages: await buildConversationContext(conversationId, lease.ownerUserId), model, maxTokens: limits.maxOutputTokens, signal: AbortSignal.timeout(SCHEDULE_EXECUTION_TIMEOUT_MS) });
    for await (const delta of parseBigModelSse(response.body!)) { if (delta.type === "content") full += delta.content; else if (delta.type === "usage") { promptTokens = delta.promptTokens; completionTokens = delta.completionTokens; } if (Date.now() - renewedAt >= LEASE_RENEWAL_INTERVAL_MS) { const heartbeat = await database.update(schedules).set({ leaseExpiresAt: new Date(Date.now() + SCHEDULE_LEASE_MS), updatedAt: new Date() }).where(and(eq(schedules.id, lease.id), eq(schedules.leaseToken, lease.leaseToken))).returning({ id: schedules.id }); if (!heartbeat[0]) throw new Error("Schedule lease lost"); renewedAt = Date.now(); } }
    await updateAssistantMessage(assistantId, lease.ownerUserId, { content: full, status: "complete", promptTokens, completionTokens, latencyMs: Date.now() - now.getTime() }); await addTokenUsage(lease.ownerUserId, model, promptTokens, completionTokens);
    await database.update(scheduleRuns).set({ status: "succeeded", conversationId, finishedAt: new Date(), updatedAt: new Date() }).where(eq(scheduleRuns.id, runId));
  } catch (error) {
    if (assistantId) await updateAssistantMessage(assistantId, lease.ownerUserId, { content: full, status: "failed", errorCode: "schedule_failed" }); await database.update(scheduleRuns).set({ status: "failed", conversationId, errorCode: error instanceof Error ? error.name : "schedule_failed", finishedAt: new Date(), updatedAt: new Date() }).where(eq(scheduleRuns.id, runId)); throw error;
  } finally { await database.update(schedules).set({ leaseToken: null, leaseExpiresAt: null, nextRunAt: lease.enabled ? calculateNextRun(lease.frequency) : null, updatedAt: new Date() }).where(and(eq(schedules.id, lease.id), eq(schedules.leaseToken, lease.leaseToken))); }
  return { id: runId, conversationId, status: "succeeded" as const, source };
}

export async function runScheduleManually(userId: string, id: string) { const database = await db(); const now = new Date(); const [existing] = await database.select().from(schedules).where(and(eq(schedules.id, id), eq(schedules.ownerUserId, userId))).limit(1); if (!existing) throw new Response("Not found", { status: 404 }); const leaseToken = crypto.randomUUID(); const rows = await database.update(schedules).set({ leaseToken, leaseExpiresAt: new Date(now.getTime() + SCHEDULE_LEASE_MS), updatedAt: now }).where(and(eq(schedules.id, id), eq(schedules.ownerUserId, userId), or(isNull(schedules.leaseExpiresAt), lte(schedules.leaseExpiresAt, now)))).returning(); if (!rows[0]) throw new Response("任务正在执行", { status: 409 }); return runSchedule({ ...rows[0], leaseToken }, "manual"); }
