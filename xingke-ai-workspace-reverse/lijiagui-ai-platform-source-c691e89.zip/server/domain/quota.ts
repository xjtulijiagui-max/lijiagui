import { and, eq, sql } from "drizzle-orm";
import { usageDaily } from "../../db/schema";
import { getWorkspaceSettings } from "./workspace-settings";

export const DEFAULT_REQUEST_QUOTA = 50;
export const DEFAULT_TOKEN_QUOTA = 200_000;

export function assertQuotaAvailable(usage: { requestCount: number; totalTokens: number }, limits = { dailyRequestQuota: DEFAULT_REQUEST_QUOTA, dailyTokenQuota: DEFAULT_TOKEN_QUOTA }): void {
  if (usage.requestCount >= limits.dailyRequestQuota) throw new Error("今日模型请求次数已用完，请联系管理员调整配额");
  if (usage.totalTokens >= limits.dailyTokenQuota) throw new Error("今日 token 配额已用完，请联系管理员调整配额");
}

function today() { return new Date().toISOString().slice(0, 10); }
async function db() { return (await import("../../db")).getDb(); }

export async function reserveRequestQuota(ownerUserId: string, model: string) {
  const database = await db(); const date = today(); const now = new Date(); const limits = await getWorkspaceSettings();
  const existing = await database.select().from(usageDaily).where(and(eq(usageDaily.ownerUserId, ownerUserId), eq(usageDaily.date, date), eq(usageDaily.model, model))).limit(1);
  const current = existing[0];
  assertQuotaAvailable({ requestCount: current?.requestCount ?? 0, totalTokens: (current?.promptTokens ?? 0) + (current?.completionTokens ?? 0) }, limits);
  await database.insert(usageDaily).values({ id: crypto.randomUUID(), ownerUserId, date, model, requestCount: 1, promptTokens: 0, completionTokens: 0, scheduleRunCount: 0, createdAt: now, updatedAt: now })
    .onConflictDoUpdate({ target: [usageDaily.ownerUserId, usageDaily.date, usageDaily.model], set: { requestCount: sql`${usageDaily.requestCount} + 1`, updatedAt: now } });
}

export async function addTokenUsage(ownerUserId: string, model: string, promptTokens: number, completionTokens: number) {
  await (await db()).update(usageDaily).set({ promptTokens: sql`${usageDaily.promptTokens} + ${promptTokens}`, completionTokens: sql`${usageDaily.completionTokens} + ${completionTokens}`, updatedAt: new Date() }).where(and(eq(usageDaily.ownerUserId, ownerUserId), eq(usageDaily.date, today()), eq(usageDaily.model, model)));
}
