import { env } from "cloudflare:workers";
import { and, count, desc, eq, gte } from "drizzle-orm";

import { getDb } from "../../db";
import { auditLogs, loginAttempts, sessions, systemSettings, users } from "../../db/schema";
import { hashPassword, randomToken, sha256, verifyPassword, type PasswordDigest } from "../auth/crypto";
import { decideLoginLock } from "../auth/login-rate-limit";
import { revokeUserSessions } from "../auth/session";
import { mustRevokeSessionsForUserMutation, normalizeManagedRole, shouldRequirePasswordChange, shouldSeedInitialAdmin, validateNewUsername } from "./user-policy";

export { mustRevokeSessionsForUserMutation, normalizeManagedRole, shouldRequirePasswordChange, shouldSeedInitialAdmin, validateNewUsername } from "./user-policy";

export function validatePassword(value: string): string {
  if (value.length < 12 || value.length > 128) throw new Error("密码长度必须为 12–128 个字符");
  return value;
}

function digestValues(digest: PasswordDigest) {
  return { passwordAlgorithm: digest.algorithm, passwordIterations: digest.iterations, passwordSalt: digest.salt, passwordHash: digest.hash };
}

function digestFromUser(user: typeof users.$inferSelect): PasswordDigest {
  return { algorithm: user.passwordAlgorithm as "PBKDF2-SHA256", iterations: user.passwordIterations as 100000, salt: user.passwordSalt, hash: user.passwordHash };
}

export async function audit(action: string, actorUserId: string | null, targetType?: string, targetId?: string, metadata: Record<string, unknown> = {}) {
  const now = new Date();
  await getDb().insert(auditLogs).values({ id: crypto.randomUUID(), actorUserId, action, targetType, targetId, metadataJson: JSON.stringify(metadata), createdAt: now, updatedAt: now });
}

export async function ensureInitialAdmin(): Promise<void> {
  const [{ value }] = await getDb().select({ value: count() }).from(users);
  if (!shouldSeedInitialAdmin(value, Boolean(env.INITIAL_ADMIN_PASSWORD))) return;
  if (!env.INITIAL_ADMIN_PASSWORD) throw new Error("INITIAL_ADMIN_PASSWORD is not configured");
  const digest = await hashPassword(validatePassword(env.INITIAL_ADMIN_PASSWORD));
  const now = new Date();
  await getDb().insert(users).values({
    id: crypto.randomUUID(), username: "admin", displayName: "系统管理员", ...digestValues(digest),
    role: "admin", status: "active", mustChangePassword: true, createdAt: now, updatedAt: now,
  }).onConflictDoNothing({ target: users.username });
}

export async function authenticate(usernameInput: string, password: string, request: Request) {
  await ensureInitialAdmin();
  const username = usernameInput.trim().toLowerCase();
  const ipHash = await sha256(request.headers.get("cf-connecting-ip") ?? "local");
  const since = new Date(Date.now() - 15 * 60_000);
  const failures = await getDb().select({ attemptedAt: loginAttempts.attemptedAt }).from(loginAttempts)
    .where(and(eq(loginAttempts.username, username), eq(loginAttempts.ipHash, ipHash), eq(loginAttempts.succeeded, false), gte(loginAttempts.attemptedAt, since)))
    .orderBy(desc(loginAttempts.attemptedAt));
  const lock = decideLoginLock(failures.map((row) => row.attemptedAt.getTime()));
  if (lock.locked) return { ok: false as const, reason: "locked" as const, retryAfterSeconds: lock.retryAfterSeconds };

  const [user] = await getDb().select().from(users).where(eq(users.username, username)).limit(1);
  const ok = Boolean(user && user.status === "active" && await verifyPassword(password, digestFromUser(user)));
  const now = new Date();
  await getDb().insert(loginAttempts).values({ id: crypto.randomUUID(), username, ipHash, succeeded: ok, attemptedAt: now, createdAt: now, updatedAt: now });
  if (!ok || !user) return { ok: false as const, reason: "invalid" as const, retryAfterSeconds: 0 };
  await getDb().update(users).set({ lastLoginAt: now, updatedAt: now }).where(eq(users.id, user.id));
  await audit("auth.login", user.id, "user", user.id);
  return { ok: true as const, user };
}

export async function listUsers() {
  return getDb().select({ id: users.id, username: users.username, displayName: users.displayName, role: users.role, status: users.status, mustChangePassword: users.mustChangePassword, lastLoginAt: users.lastLoginAt, createdAt: users.createdAt }).from(users).orderBy(desc(users.createdAt));
}

export async function createManagedUser(input: { username: string; displayName?: string; role?: "admin" | "member"; password?: string }, actorUserId: string) {
  const username = validateNewUsername(input.username);
  const role = normalizeManagedRole(input.role);
  const temporaryPassword = input.password ? validatePassword(input.password) : `${randomToken(12)}Aa1!`;
  const digest = await hashPassword(temporaryPassword);
  const now = new Date();
  const id = crypto.randomUUID();
  await getDb().insert(users).values({ id, username, displayName: input.displayName?.trim().slice(0, 60) || username, ...digestValues(digest), role, status: "active", mustChangePassword: shouldRequirePasswordChange(Boolean(input.password)), createdAt: now, updatedAt: now });
  await audit("admin.user.create", actorUserId, "user", id, { username, role });
  return { id, username, temporaryPassword };
}

export async function mutateManagedUser(id: string, input: { action: string; role?: "admin" | "member" }, actorUserId: string) {
  const [target] = await getDb().select().from(users).where(eq(users.id, id)).limit(1);
  if (!target) throw new Response("Not found", { status: 404 });
  if (target.username === "admin" && ["disable", "role"].includes(input.action)) throw new Response("Cannot disable or demote primary admin", { status: 409 });
  const now = new Date();
  let temporaryPassword: string | undefined;
  if (input.action === "disable" || input.action === "enable") {
    await getDb().update(users).set({ status: input.action === "disable" ? "disabled" : "active", updatedAt: now }).where(eq(users.id, id));
  } else if (input.action === "role" && input.role) {
    await getDb().update(users).set({ role: input.role, updatedAt: now }).where(eq(users.id, id));
  } else if (input.action === "reset-password") {
    temporaryPassword = `${randomToken(12)}Aa1!`;
    const digest = await hashPassword(temporaryPassword);
    await getDb().update(users).set({ ...digestValues(digest), mustChangePassword: true, updatedAt: now }).where(eq(users.id, id));
  } else throw new Response("Invalid action", { status: 400 });
  if (mustRevokeSessionsForUserMutation(input.action)) await revokeUserSessions(id);
  await audit(`admin.user.${input.action}`, actorUserId, "user", id, input.role ? { role: input.role } : {});
  return { ok: true, temporaryPassword };
}

export async function changeOwnPassword(userId: string, currentPassword: string, nextPassword: string) {
  const [user] = await getDb().select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user || !await verifyPassword(currentPassword, digestFromUser(user))) throw new Response("当前密码不正确", { status: 400 });
  const digest = await hashPassword(validatePassword(nextPassword));
  const now = new Date();
  await getDb().update(users).set({ ...digestValues(digest), mustChangePassword: false, updatedAt: now }).where(eq(users.id, userId));
  await revokeUserSessions(userId);
  await audit("auth.password.change", userId, "user", userId);
}

export async function recoverAdmin(recoveryToken: string, nextPassword: string) {
  if (!env.ADMIN_RECOVERY_TOKEN) throw new Response("恢复功能未配置", { status: 503 });
  const suppliedHash = await sha256(recoveryToken);
  const expectedHash = await sha256(env.ADMIN_RECOVERY_TOKEN);
  if (suppliedHash !== expectedHash) throw new Response("恢复码无效", { status: 401 });
  const [admin] = await getDb().select().from(users).where(eq(users.username, "admin")).limit(1);
  if (!admin) throw new Response("管理员尚未初始化", { status: 409 });
  const digest = await hashPassword(validatePassword(nextPassword));
  const now = new Date(); const database = getDb();
  try {
    await database.batch([
      database.insert(systemSettings).values({ id: crypto.randomUUID(), key: "admin_recovery_used_hash", valueJson: JSON.stringify(suppliedHash), updatedByUserId: admin.id, createdAt: now, updatedAt: now }),
      database.update(users).set({ ...digestValues(digest), mustChangePassword: true, status: "active", updatedAt: now }).where(eq(users.id, admin.id)),
      database.delete(sessions).where(eq(sessions.userId, admin.id)),
      database.insert(auditLogs).values({ id: crypto.randomUUID(), actorUserId: admin.id, action: "auth.admin.recover", targetType: "user", targetId: admin.id, metadataJson: "{}", createdAt: now, updatedAt: now }),
    ]);
  } catch (error) {
    if (error instanceof Error && /unique|constraint|system_settings_key_unique/iu.test(error.message)) throw new Response("恢复码已使用", { status: 409 });
    throw error;
  }
}
