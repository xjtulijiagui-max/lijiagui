import { and, eq, or } from "drizzle-orm";
import { experts, skills } from "../../db/schema";

export function composeSystemPrompt(scene: string, expert?: { systemPrompt: string } | null, selectedSkills: Array<{ instructions: string }> = [], appInstructions: string[] = []): string {
  return [scene, expert?.systemPrompt, ...selectedSkills.map((skill) => skill.instructions), ...appInstructions].filter(Boolean).join("\n\n---\n\n");
}
export function isCapabilitySelectable(capability: { enabled: boolean }): boolean { return capability.enabled; }
export function isVisibleToUser(capability: { visibility: string; ownerUserId: string | null }, userId: string): boolean { return capability.visibility === "public" || capability.ownerUserId === userId; }
async function db() { return (await import("../../db")).getDb(); }

export async function ensureDefaultCapabilities() {
  const database = await db(); const existing = await database.select({ id: experts.id }).from(experts).limit(1); if (existing.length) return;
  const now = new Date();
  await database.insert(experts).values([
    { id: crypto.randomUUID(), ownerUserId: null, name: "内容创作顾问", description: "从选题、结构到成稿，兼顾清晰度与传播力", systemPrompt: "你是一名资深中文内容顾问。先确认目标读者和行动目标，再输出结构清晰的成品。", avatarColor: "#6d5ce6", visibility: "public", enabled: true, createdAt: now, updatedAt: now },
    { id: crypto.randomUUID(), ownerUserId: null, name: "经营分析师", description: "区分数据事实、业务判断与待验证假设", systemPrompt: "你是经营分析师。所有结论都要说明数据依据、口径与限制。", avatarColor: "#2b9b7a", visibility: "public", enabled: true, createdAt: now, updatedAt: now },
  ]);
  await database.insert(skills).values([
    { id: crypto.randomUUID(), ownerUserId: null, name: "结构化表达", invocationName: "structured-writing", description: "把复杂内容组织成清晰层级", instructions: "输出前先搭建层级结构；标题表达结论，段落各自只承担一个任务。", visibility: "public", enabled: true, createdAt: now, updatedAt: now },
    { id: crypto.randomUUID(), ownerUserId: null, name: "事实核验", invocationName: "fact-check", description: "标记来源、推断与待核验项", instructions: "严格区分已知事实、分析推断和待核验内容，不得编造来源。", visibility: "public", enabled: true, createdAt: now, updatedAt: now },
  ]);
}

export async function listCapabilities(userId: string) {
  await ensureDefaultCapabilities(); const database = await db();
  return {
    experts: await database.select().from(experts).where(and(eq(experts.enabled, true), or(eq(experts.visibility, "public"), eq(experts.ownerUserId, userId)))),
    skills: await database.select().from(skills).where(and(eq(skills.enabled, true), or(eq(skills.visibility, "public"), eq(skills.ownerUserId, userId)))),
    connectors: [
      { id: "bigmodel", name: "智谱 BigModel", description: "服务端安全调用 GLM 模型", status: "connected" },
      { id: "cloud-drive", name: "云盘文件", description: "引用当前账号拥有的文件", status: "connected" },
    ],
  };
}

export async function resolveSelectedCapabilities(userId: string, expertId?: string | null, skillIds: string[] = []) {
  const database = await db();
  let expert: typeof experts.$inferSelect | null = null;
  if (expertId) {
    const [row] = await database.select().from(experts).where(eq(experts.id, expertId)).limit(1);
    if (!row || !isCapabilitySelectable(row) || !isVisibleToUser(row, userId)) throw new Response("Expert not found", { status: 404 });
    expert = row;
  }
  const selectedSkills: Array<typeof skills.$inferSelect> = [];
  for (const id of [...new Set(skillIds)]) {
    const [row] = await database.select().from(skills).where(eq(skills.id, id)).limit(1);
    if (!row || !isCapabilitySelectable(row) || !isVisibleToUser(row, userId)) throw new Response("Skill not found", { status: 404 });
    selectedSkills.push(row);
  }
  if (selectedSkills.length > 12) throw new Response("Too many skills", { status: 400 });
  return { expert, skills: selectedSkills };
}

export async function createExpert(userId: string, role: string, input: { name: string; description?: string; systemPrompt: string; visibility?: "public" | "private" }) {
  if (input.visibility === "public" && role !== "admin") throw new Response("Forbidden", { status: 403 }); const now = new Date(); const id = crypto.randomUUID();
  await (await db()).insert(experts).values({ id, ownerUserId: userId, name: input.name.trim().slice(0, 60), description: input.description?.trim().slice(0, 240) ?? "", systemPrompt: input.systemPrompt.trim().slice(0, 8000), visibility: input.visibility ?? "private", enabled: true, createdAt: now, updatedAt: now }); return { id };
}
export async function createSkill(userId: string, role: string, input: { name: string; invocationName?: string; description?: string; instructions: string; visibility?: "public" | "private" }) {
  if (input.visibility === "public" && role !== "admin") throw new Response("Forbidden", { status: 403 }); const now = new Date(); const id = crypto.randomUUID();
  await (await db()).insert(skills).values({ id, ownerUserId: userId, name: input.name.trim().slice(0, 60), invocationName: (input.invocationName || input.name).toLowerCase().replace(/\s+/gu, "-").slice(0, 60), description: input.description?.trim().slice(0, 240) ?? "", instructions: input.instructions.trim().slice(0, 8000), visibility: input.visibility ?? "private", enabled: true, createdAt: now, updatedAt: now }); return { id };
}
