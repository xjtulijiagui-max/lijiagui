export function shouldSeedInitialAdmin(userCount: number, secretPresent: boolean): boolean {
  return userCount === 0 && secretPresent;
}

export function validateNewUsername(value: string, allowAdmin = false): string {
  const username = value.trim().toLowerCase();
  if (!/^[a-z0-9_]{3,32}$/u.test(username)) throw new Error("Username must be 3-32 lowercase letters, numbers, or underscores");
  if (!allowAdmin && ["admin", "root", "system", "support"].includes(username)) throw new Error("Reserved username");
  return username;
}

export function mustRevokeSessionsForUserMutation(action: string): boolean {
  return action === "disable" || action === "reset-password" || action === "change-password";
}

export function shouldRequirePasswordChange(passwordProvided: boolean): boolean {
  return !passwordProvided;
}

export function normalizeManagedRole(value: unknown): "admin" | "member" {
  if (value === undefined || value === null || value === "") return "member";
  if (value !== "admin" && value !== "member") throw new Error("Role must be admin or member");
  return value;
}
