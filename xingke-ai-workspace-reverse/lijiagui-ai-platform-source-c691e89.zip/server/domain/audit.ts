import { desc } from "drizzle-orm";
import { auditLogs } from "../../db/schema";
async function db() { return (await import("../../db")).getDb(); }
export async function listAuditLogs(limit = 100) { return (await db()).select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(Math.min(Math.max(limit, 1), 200)); }
