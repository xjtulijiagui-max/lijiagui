export const MAX_FILE_BYTES = 20 * 1024 * 1024;
export const MAX_STORAGE_BYTES = 200 * 1024 * 1024;
const forbiddenExtensions = /\.(?:exe|dll|bat|cmd|com|msi|scr|ps1|sh|jar|apk|app|dmg)$/iu;
const allowedMime = /^(?:text\/(?:plain|markdown|csv)|application\/(?:json|pdf|vnd\.openxmlformats-officedocument\.(?:wordprocessingml\.document|spreadsheetml\.sheet|presentationml\.presentation)|msword|vnd\.ms-excel|vnd\.ms-powerpoint)|image\/(?:png|jpeg|gif|webp))$/iu;

export type FilePolicyResult = { ok: true } | { ok: false; error: string };
export function validateUpload(meta: { name: string; type: string; size: number }, maxFileBytes = MAX_FILE_BYTES): FilePolicyResult {
  const name = meta.name.normalize("NFC").trim();
  if (!name || name.length > 180 || name.includes("..") || /[\\/]/u.test(name) || /^[a-z]:/iu.test(name)) return { ok: false, error: "Invalid file name" };
  if (forbiddenExtensions.test(name)) return { ok: false, error: "Executable files are not allowed" };
  if (!Number.isSafeInteger(meta.size) || meta.size <= 0 || meta.size > maxFileBytes) return { ok: false, error: "File exceeds configured size limit" };
  if (!allowedMime.test(meta.type)) return { ok: false, error: "File type is not allowed" };
  return { ok: true };
}
export function validateStorageQuota(currentBytes: number, incomingBytes: number, maxStorageBytes = MAX_STORAGE_BYTES): void { if (currentBytes + incomingBytes > maxStorageBytes) throw new Error("Storage quota exceeded"); }
export function cleanupCutoff(now = new Date()): Date { return new Date(now.getTime() - 30 * 24 * 60 * 60_000); }
