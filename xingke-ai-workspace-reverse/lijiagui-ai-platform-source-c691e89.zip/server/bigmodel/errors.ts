export class BigModelError extends Error {
  constructor(public code: string, message: string, public status = 502) { super(message); this.name = "BigModelError"; }
}

export function mapBigModelHttpError(status: number, body: string): BigModelError {
  const normalized = body.toLowerCase();
  if (status === 429) return new BigModelError("rate_limited", "模型服务繁忙，请稍后重试", 429);
  if (/balance|余额|insufficient/u.test(normalized)) return new BigModelError("insufficient_balance", "智谱账户余额不足，请联系管理员", 402);
  if (status === 401 || status === 403) return new BigModelError("invalid_credentials", "模型服务凭据无效，请联系管理员", 503);
  if (status >= 500) return new BigModelError("upstream_unavailable", "模型服务暂时不可用", 503);
  return new BigModelError("invalid_request", "模型无法处理本次请求", 400);
}

export function mapBigModelEventError(code: string, message: string): BigModelError {
  if (/balance|余额|insufficient|1210/u.test(`${code} ${message}`)) return new BigModelError("insufficient_balance", "智谱账户余额不足，请联系管理员", 402);
  if (/rate|limit|1302/u.test(`${code} ${message}`)) return new BigModelError("rate_limited", "模型服务繁忙，请稍后重试", 429);
  return new BigModelError(code || "upstream_error", message || "模型流式响应出错");
}
