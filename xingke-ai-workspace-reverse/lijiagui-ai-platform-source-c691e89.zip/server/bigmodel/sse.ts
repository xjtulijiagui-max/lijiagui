import { mapBigModelEventError } from "./errors";

export type BigModelDelta =
  | { type: "content"; content: string }
  | { type: "usage"; promptTokens: number; completionTokens: number }
  | { type: "done" };

export async function* parseBigModelSse(stream: ReadableStream<Uint8Array>): AsyncIterable<BigModelDelta> {
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value, { stream: !done });
      const blocks = buffer.split(/\r?\n\r?\n/u);
      buffer = blocks.pop() ?? "";
      for (const block of blocks) {
        const data = block.split(/\r?\n/u).filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trimStart()).join("\n");
        if (!data) continue;
        if (data === "[DONE]") { yield { type: "done" }; return; }
        const payload = JSON.parse(data) as { error?: { code?: string | number; message?: string }; choices?: Array<{ delta?: { content?: string } }>; usage?: { prompt_tokens?: number; completion_tokens?: number } };
        if (payload.error) throw mapBigModelEventError(String(payload.error.code ?? ""), payload.error.message ?? "");
        const content = payload.choices?.[0]?.delta?.content;
        if (content) yield { type: "content", content };
        if (payload.usage) yield { type: "usage", promptTokens: payload.usage.prompt_tokens ?? 0, completionTokens: payload.usage.completion_tokens ?? 0 };
      }
      if (done) break;
    }
    if (buffer.trim()) throw new Error("模型流式响应意外中断");
    throw new Error("模型流式响应在完成前中断");
  } finally { reader.releaseLock(); }
}
