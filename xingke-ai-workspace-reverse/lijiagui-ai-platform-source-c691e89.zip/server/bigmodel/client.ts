import { env } from "cloudflare:workers";
import type { ChatMessage } from "./context";
import { mapBigModelHttpError } from "./errors";

export type BigModelChatInput = { messages: ChatMessage[]; model?: string; signal?: AbortSignal; maxTokens?: number };

export async function streamChat(input: BigModelChatInput): Promise<Response> {
  if (!env.BIGMODEL_API_KEY) throw new Error("BIGMODEL_API_KEY is not configured");
  let response: Response;
  try {
    response = await fetch("https://open.bigmodel.cn/api/paas/v4/chat/completions", {
      method: "POST", signal: input.signal,
      headers: { authorization: `Bearer ${env.BIGMODEL_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({ model: input.model ?? "glm-5.3-flash", messages: input.messages, stream: true, max_tokens: input.maxTokens ?? 4096 }),
    });
  } catch (error) {
    if (input.signal?.aborted) throw error;
    await new Promise((resolve) => setTimeout(resolve, 350));
    response = await fetch("https://open.bigmodel.cn/api/paas/v4/chat/completions", {
      method: "POST", signal: input.signal,
      headers: { authorization: `Bearer ${env.BIGMODEL_API_KEY}`, "content-type": "application/json" },
      body: JSON.stringify({ model: input.model ?? "glm-5.3-flash", messages: input.messages, stream: true, max_tokens: input.maxTokens ?? 4096 }),
    });
  }
  if (!response.ok) throw mapBigModelHttpError(response.status, await response.text());
  if (!response.body) throw new Error("模型服务未返回响应流");
  return response;
}
