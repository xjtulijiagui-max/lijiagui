export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export function trimConversationContext(messages: ChatMessage[], maxCharacters = 24_000): ChatMessage[] {
  const system = messages[0]?.role === "system" ? messages[0] : null;
  const budget = Math.max(0, maxCharacters - (system?.content.length ?? 0));
  const selected: ChatMessage[] = [];
  let used = 0;
  for (let index = messages.length - 1; index >= (system ? 1 : 0); index -= 1) {
    const message = messages[index];
    if (used + message.content.length > budget) break;
    selected.unshift(message); used += message.content.length;
  }
  return system ? [system, ...selected] : selected;
}

const scenePrompts: Record<string, string> = {
  general: "你是李家贵AI中台中的可靠助手。回答清晰、诚实，并在不确定时明确说明。",
  writing: "你是资深内容编辑，先理解受众和目标，再给出结构清晰、可直接使用的中文内容。",
  data: "你是数据分析师，区分事实、计算、推断与待核验项。",
  code: "你是软件工程师，优先给出可验证、可维护的解决方案。",
  ppt: "你是演示设计顾问，先搭建叙事结构，再给出逐页内容。",
  research: "你是研究助理，重视证据来源、时效和相互验证。",
  finance: "你是经营分析顾问，不把一般分析表述成投资承诺。",
};

export async function buildConversationContext(id: string, userId: string): Promise<ChatMessage[]> {
  const { getConversationMessages } = await import("../domain/conversations");
  const { composeSystemPrompt, resolveSelectedCapabilities } = await import("../domain/capabilities");
  const result = await getConversationMessages(id, userId);
  const selected = await resolveSelectedCapabilities(userId, result.conversation.expertId, JSON.parse(result.conversation.skillIdsJson || "[]") as string[]);
  const appInstructions = result.messages.filter((message) => message.role === "system" && message.status === "complete").map((message) => message.content);
  const system: ChatMessage = { role: "system", content: composeSystemPrompt(scenePrompts[result.conversation.scene] ?? scenePrompts.general, selected.expert, selected.skills, appInstructions) };
  const history = result.messages.filter((message) => message.role !== "system" && message.status === "complete").map((message) => ({ role: message.role as "user" | "assistant", content: message.content }));
  return trimConversationContext([system, ...history]);
}
