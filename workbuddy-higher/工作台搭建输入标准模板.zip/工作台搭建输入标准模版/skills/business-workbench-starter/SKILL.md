---
name: business-workbench-starter
description: 将业务人员的 SOP、IPO、Excel、Word、PDF 和输出样本转换为 WorkBuddy 定制工作包，并指导文件导入、资料库绑定、实际开发和验收迭代。适用于搭建业务工作台、把 JSON 输入改成文件上传、把本地原型迁移到资料库；不用于冒充官方插件或在未授权时发布。
---

# 业务工作台输入与搭建 Skill

本 Skill 是配套任务规范，不提供平台资料库接口。实际接口必须读取当前 WorkBuddy 环境中的官方/已安装资料库 skill 和工具说明后使用。

## 三阶段

### A：定制输入包

读取 `references/core-spec.md`、`references/rules-and-provenance.md`、`references/deliverable-contract.md`。实际读取业务文件，抽取目标/IPO/SOP/规则/状态/输入输出/权限。仅在缺少关键业务事实时一次最多问 4 问。生成可独立交给搭建师的定制包与来源、缺口、验收，不先写网页。

涉及文件解析，读 `references/file-import.md`；涉及持久化和分享，读 `references/dataspace.md` 与 `references/security-release.md`；生成页面规格，读 `references/ui-ux.md`。

### B：开发与接入

先读定制包入口和实际业务规则，再读上述输入/资料库/安全规范。发现当前平台能力，先跑一个最小读写闭环，再扩展场景。实际编写代码、运行和测试；账号/工具缺失时记录阻塞，不能编造接口、成功回执或发布地址。

### C：验收与迭代

按定制用例检查导入、规则、保存读回、反向同步、跨端、权限、冲突、导出及恢复。每次改动先识别影响，必要时备份，经授权后执行迁移，最后回归并登记版本。未实际执行的测试一律“未测试”。

## 按需参考

| 文件 | 用途 |
|---|---|
| `references/core-spec.md` | 核心目标、MVP、平台与交付底线 |
| `references/file-import.md` | 业务文件上传、解析、预览、确认与导入 |
| `references/dataspace.md` | HTML/CSV 绑定、读写、同步、并发和复制隔离 |
| `references/ui-ux.md` | 中文响应式界面、页面/数据联动、可用性 |
| `references/rules-and-provenance.md` | IPO/SOP、计算规则、来源与假设 |
| `references/security-release.md` | 授权、分享、密钥、备份、恢复与交接 |
| `references/automation-and-memory.md` | 可选连接器、自动化和长期复用 |
| `references/deliverable-contract.md` | 定制包、成品包、验收证据格式 |
| `references/legacy-migration.md` | JSON/本地旧原型向新架构迁移 |

## 不可退让的五项

**业务用户不填 JSON；正式数据不只存在浏览器；外部平台能力不臆造；真实资料与示例隔离；未测不报通过。**

知识库检索、资料库文件存储与业务数据表读写是不同能力；连接器授权、后台调度、账号权限也不会因为写进提示词就自动生效。
