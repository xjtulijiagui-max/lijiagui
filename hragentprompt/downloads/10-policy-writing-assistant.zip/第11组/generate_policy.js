const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, PageNumber, PageBreak, LevelFormat, TableOfContents
} = require("docx");

// ====================== HELPERS ======================

const A4_W = 11906, A4_H = 16838, MARGIN = 1440, CONTENT_W = A4_W - 2 * MARGIN; // 9026
const FONT_TITLE = "SimHei", FONT_BODY = "SimSun";

const border = { style: BorderStyle.SINGLE, size: 1, color: "999999" };
const borders = { top: border, bottom: border, left: border, right: border };
const cellMargins = { top: 60, bottom: 60, left: 100, right: 100 };

function p(text, opts = {}) {
  const runs = [];
  if (typeof text === "string") {
    runs.push(new TextRun({ text, font: opts.font || FONT_BODY, size: opts.size || 24, bold: !!opts.bold }));
  } else if (Array.isArray(text)) {
    text.forEach(t => {
      if (typeof t === "string") runs.push(new TextRun({ text: t, font: opts.font || FONT_BODY, size: opts.size || 24 }));
      else runs.push(new TextRun({ ...t, font: t.font || opts.font || FONT_BODY, size: t.size || opts.size || 24 }));
    });
  }
  return new Paragraph({
    spacing: { before: opts.before || 60, after: opts.after || 60, line: opts.line || 360 },
    alignment: opts.align || AlignmentType.LEFT,
    indent: opts.indent ? { left: opts.indent } : undefined,
    children: runs,
    ...(opts.pageBreakBefore ? { pageBreakBefore: true } : {}),
    ...(opts.heading ? { heading: opts.heading } : {}),
  });
}

function h1(text) { return p(text, { font: FONT_TITLE, size: 32, bold: true, before: 360, after: 180, heading: HeadingLevel.HEADING_1 }); }
function h2(text) { return p(text, { font: FONT_TITLE, size: 28, bold: true, before: 240, after: 120, heading: HeadingLevel.HEADING_2 }); }
function h3(text) { return p(text, { font: FONT_TITLE, size: 26, bold: true, before: 180, after: 100, heading: HeadingLevel.HEADING_3 }); }
function body(text, opts = {}) { return p(text, { ...opts, font: FONT_BODY, size: 24, indent: opts.indent || 480 }); }

function bodyBoldLabel(label, text) {
  return p([
    { text: label, bold: true },
    { text: text }
  ], { font: FONT_BODY, size: 24, indent: 480 });
}

function hrNote(text) {
  return p([{ text: "【⚠️法务/HR复核】", bold: true, color: "CC0000" }, { text: " " + text, color: "CC0000" }],
    { font: FONT_BODY, size: 22, indent: 480, before: 40, after: 40 });
}

function makeCell(text, opts = {}) {
  const runs = [];
  if (typeof text === "string") {
    runs.push(new TextRun({ text, font: opts.bold ? FONT_TITLE : FONT_BODY, size: 22, bold: !!opts.bold }));
  } else if (Array.isArray(text)) {
    text.forEach(t => {
      if (typeof t === "string") runs.push(new TextRun({ text: t, font: FONT_BODY, size: 22 }));
      else runs.push(new TextRun({ ...t, font: t.font || FONT_BODY, size: 22 }));
    });
  }
  return new TableCell({
    borders,
    width: { size: opts.width || 1000, type: WidthType.DXA },
    margins: cellMargins,
    shading: opts.shading ? { fill: opts.shading, type: ShadingType.CLEAR } : undefined,
    verticalAlign: "center",
    children: [new Paragraph({ children: runs, spacing: { before: 40, after: 40 } })],
  });
}

function makeTable(headers, rows, colWidths) {
  const totalW = colWidths.reduce((a, b) => a + b, 0);
  const headerRow = new TableRow({
    children: headers.map((h, i) => makeCell(h, { bold: true, shading: "D5E8F0", width: colWidths[i] })),
    tableHeader: true,
  });
  const dataRows = rows.map(row =>
    new TableRow({ children: row.map((cell, i) => makeCell(cell, { width: colWidths[i] })) })
  );
  return new Table({
    width: { size: totalW, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headerRow, ...dataRows],
  });
}

// ====================== DOCUMENT CONTENT ======================

const children = [];

// ---- Cover / Title Page ----
children.push(p("", { before: 3000 }));
children.push(p("国任保险", { font: FONT_TITLE, size: 44, bold: true, align: AlignmentType.CENTER, before: 0, after: 200 }));
children.push(p("员工考勤及请休假管理办法", { font: FONT_TITLE, size: 36, bold: true, align: AlignmentType.CENTER, before: 200, after: 600 }));
children.push(p(`制度编号：${new Date().toISOString().slice(0, 10).replace(/-/g, "")}`, { font: FONT_BODY, size: 24, align: AlignmentType.CENTER }));
children.push(p(`发布日期：${new Date().toISOString().slice(0, 10)}`, { font: FONT_BODY, size: 24, align: AlignmentType.CENTER }));
children.push(p("国任保险人力资源部", { font: FONT_BODY, size: 24, align: AlignmentType.CENTER, before: 120 }));

// Page break
children.push(new Paragraph({ children: [new PageBreak()] }));

// =================== 一、制度名称 ===================
children.push(h1("一、制度名称"));
children.push(body("《国任保险员工考勤及请休假管理办法》（以下简称“本办法”）。"));

// =================== 二、制定目的 ===================
children.push(h1("二、制定目的"));
children.push(body(`为规范国任保险公司（以下简称"公司"）员工的考勤管理和请休假行为，保障正常工作秩序，维护员工合法权益，提高人力资源管理效率，根据《中华人民共和国劳动法》《中华人民共和国劳动合同法》《职工带薪年休假条例》及相关法律法规，结合公司实际情况，制定本办法。`));
children.push(body("具体目的包括："));
children.push(body("（一）建立统一、规范的考勤管理制度，确保出勤记录真实、准确、完整；"));
children.push(body("（二）规范员工请休假行为，保障员工依法享有的休息休假权利；"));
children.push(body("（三）明确考勤结果与薪酬、绩效、晋升的关联机制，激励员工遵守纪律；"));
children.push(body("（四）强化内部管控，防范操作风险，确保关键岗位履职安全；"));
children.push(body("（五）营造公平、公正、关爱员工的组织氛围。"));

// =================== 三、适用范围 ===================
children.push(h1("三、适用范围"));
children.push(body("本办法适用于国任保险全体正式员工。"));
children.push(body("以下人员参照本办法执行，具体管理细则另行制定："));
children.push(body("（一）实习生、劳务派遣人员——由人力资源管理部门会同用人部门参照本办法制定专项管理方案；"));
children.push(body("（二）高管及特殊岗位人员——其考勤方式可由公司另行约定，但法定休假权益不受影响；"));
children.push(body("（三）驻外机构员工——在遵守本办法基本原则的前提下，可根据所在地法规作适当调整。"));
children.push(body("待补充：__________（若有其他特殊人员类别需在此明确）"));

// =================== 四、术语定义 ===================
children.push(h1("四、术语定义"));
children.push(body("本办法涉及的关键术语定义如下："));

children.push(makeTable(
  ["术语", "定义"],
  [
    ["标准工时制", "员工每日工作不超过8小时、每周工作不超过40小时的工时制度，工作时间为周一至周五。具体工作时间由公司另行规定。"],
    ["不定时工作制", "因工作性质特殊，无法按标准工作时间衡量的工时制度，需经劳动行政部门批准后执行。"],
    ["综合计算工时制", "以周、月、季、年等为周期综合计算工作时间的工时制度，需经劳动行政部门批准后执行。"],
    ["考勤", "对公司员工出勤、迟到、早退、旷工、请假、出差等情况的记录和统计。"],
    ["漏打卡", "因非公司系统故障原因，员工在正常出勤情况下未完成考勤打卡的情形。"],
    ["旷工", "员工在正常工作时间内未到岗、未履行请休假手续，或请休假申请未被批准而擅自不到岗的行为。"],
    ["年休假", "员工连续工作满一年后，依法享有的带薪年休假。"],
    ["医疗期", "员工因患病或非因工负伤，需要停止工作进行医疗时，依法享有的治疗休养期限。"],
    ["强制休假", "为防范操作风险，对公司关键、重要岗位员工在事前不告知的情况下安排的离岗休假，并配合离岗审计或检查。"],
    ["特色休假", "公司为体现员工关爱而特别设定的带薪休假类型，包括祝寿假、贡献假、春节探亲假、家长会假等。"],
    ["免打卡", "经公司批准，特定员工可免于执行考勤打卡制度的考勤管理方式。"],
  ],
  [2400, CONTENT_W - 2400]
));

// =================== 五、职责分工 ===================
children.push(h1("五、职责分工"));
children.push(body("考勤及请休假管理工作涉及多部门协同，具体职责分工如下："));

children.push(makeTable(
  ["角色/部门", "职责"],
  [
    ["人力资源管理部门", "（1）制定、修订和解释考勤及请休假管理制度；\n（2）维护考勤系统，按月统计、汇总员工考勤数据并提供考勤计薪依据；\n（3）审核员工请休假申请并跟踪休假执行情况；\n（4）确认免打卡员工名单并动态管理；\n（5）牵头组织强制休假的实施方案制定、休假通知和手续办理；\n（6）处理考勤异常及考勤争议。"],
    ["用人部门负责人", "（1）统筹部门内工作安排，在不影响正常工作的前提下合理安排员工请休假；\n（2）审批权限范围内员工的请休假申请；\n（3）监督本部门员工考勤纪律执行情况；\n（4）配合人力资源管理部门处理考勤异常和违纪行为。"],
    ["全体员工", "（1）自觉遵守考勤制度，按时打卡、如实记录出勤情况；\n（2）按规定提前履行请休假审批手续，提供真实有效的证明材料；\n（3）休假期间保持必要联络畅通。"],
    ["稽核审计管理部门", "（1）按有关法规和公司规定，对强制休假人员办理交接手续并限期离岗；\n（2）组织实施离岗审计或检查，出具书面审计或检查报告；\n（3）在审计期间要求强制休假人员提供必要资料或情况说明。"],
    ["法务合规部门", "（1）审查本办法条款与国家法律法规的一致性；\n（2）对涉及劳动纪律处分、劳动合同解除等事项提供法律意见；\n（3）处理因考勤及请休假引起的劳动争议。"],
  ],
  [2200, CONTENT_W - 2200]
));

// =================== 六、管理原则 ===================
children.push(h1("六、管理原则"));
children.push(body("（一）合法合规原则：本办法各项规定应符合国家法律法规、地方性法规及公司相关制度，确保员工的合法休息休假权利。"));

children.push(hrNote("本章涉及工时制度、休假天数、工资支付等关键劳动权益事项，正式发布前需经法务部门和外部劳动法律顾问审核确认。"));

children.push(body("（二）公平公正原则：考勤管理一视同仁，考勤结果真实记录、透明可查，杜绝弄虚作假和选择性执法。"));
children.push(body("（三）从严管理与人文关怀相结合原则：严格执行考勤纪律的同时，通过特色休假、免打卡等机制体现公司对员工的关爱。"));
children.push(body("（四）事前审批原则：各类请休假须提前办理审批手续，紧急情况事后补办须在规定时限内完成。"));
children.push(body("（五）可追溯原则：所有考勤记录、请休假申请、审批意见、证明材料等应完整存档，保存期限不低于2年。"));
children.push(body("（六）风险防控原则：对关键岗位实施强制休假制度，完善内控机制，防范操作风险。"));

// =================== 七、流程与要求 ===================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h1("七、流程与要求"));

// --- 概况表 ---
children.push(h2("（一）核心流程概览"));
children.push(body("以下表格汇总本办法所涉核心管理流程，各流程的详细要求见后续各章条款。"));

children.push(makeTable(
  ["流程节点", "输入", "责任人", "操作要求", "输出", "时限"],
  [
    ["日常打卡", "出勤事实", "全体员工", "上下班时在考勤系统中完成打卡", "考勤记录", "实时"],
    ["请休假申请", "休假申请+证明材料", "申请人→部门负责人→HR", "在办公平台提交申请，附证明材料，逐级审批", "审批结果", "至少提前1个工作日"],
    ["出差/公出报批", "出差/公出申请", "申请人→部门负责人", "在办公平台提交出差/公出申请", "审批结果", "出发前完成"],
    ["补卡申请", "漏打卡情况说明", "申请人→部门负责人", "在办公平台提交补卡申请，说明原因", "补卡记录", "漏打卡后1个工作日内"],
    ["月考勤汇总", "月考勤原始数据", "HR", "汇总考勤数据，核对异常，生成报表", "月考勤报表", "次月5日前"],
    ["免打卡名单确定", "上年度考勤+绩效结果", "HR+部门负责人", "统计考勤及绩效数据，征询部门意见，确定名单", "免打卡名单", "每年1月底前"],
    ["强制休假方案制定", "监管要求+风险排查", "HR+稽核审计", "制定强制休假方案（人员、时间、代职安排等）", "强制休假实施方案", "按需执行"],
    ["离岗审计/检查", "强制休假决定", "稽核审计", "办理交接手续，实施离岗审计，出具报告", "离岗审计/检查报告", "强制休假期间完成"],
  ],
  [1400, 1100, 1200, 2400, 1300, 1626]
));

// --- Chapter: 考勤管理 ---
children.push(h2("（二）考勤管理"));

children.push(h3("第一条 工作时间"));
children.push(body("1. 实行标准工时制的员工，工作时间为周一至周五，具体工作时间为上午 9:00 至 12:00，下午 1:30 至 6:00。"));
children.push(body("2. 国家法定节假日依照国家和当地政府有关规定执行。"));
children.push(body("3. 遇特殊情况，公司可对工作时间进行适当调整。"));
children.push(body("4. 实行不定时工作制、综合计算工时制（含轮班制）的员工，经由当地劳动行政部门批准后，工作时间根据公司相关要求或劳动合同予以明确。"));

children.push(hrNote("工时制度的设定需符合《劳动法》第三十六条、第三十九条的规定。不定时工作制和综合计算工时制须经劳动行政部门审批，未审批不得执行。"));

children.push(h3("第二条 日常考勤管理"));
children.push(body("日常考勤管理工作由人力资源管理部门负责，按月统计、汇总月度员工考勤情况，提供考勤计薪依据。"));

children.push(h3("第三条 考勤核实"));
children.push(body("考勤情况以员工每日出勤记录为准，核实请休假、出差、市内公出等情况，结合公司考勤制度及日常检查、监督结果确定。"));

children.push(h3("第四条 考勤纪律"));
children.push(body("公司实行严格的考勤制度，考勤结果与员工的薪酬及处罚挂钩。"));

children.push(hrNote("考勤与薪酬、处罚挂钩涉及员工切身经济利益，须确保考勤系统数据准确、不可篡改，争议处理机制应明确。"));

children.push(h3("第五条 出勤异常报批"));
children.push(body("因请休假、出差、市内公出等原因无法出勤的员工，需在公司办公平台上提前履行报批手续，否则一律视为无考勤记录。"));

children.push(h3("第六条 漏打卡管理"));
children.push(body("员工漏打卡情形原则上每月不能超过 2 次，超出 2 次的根据本办法第三十三条（漏打卡处罚）的规定处理。"));

children.push(h3("第七条 加班管理"));
children.push(body("各用人部门要切实加强技能培训，提高员工工作效率，在工作时间内按期保质保量完成工作任务，尽量避免员工加班。确需加班的，须经部门负责人审批并报人力资源管理部门备案。"));

children.push(hrNote("加班审批、加班工资支付等应符合《劳动法》第四十一条、第四十四条的规定，确保不突破法定加班时长上限。"));

children.push(h3("第八条 不可抗力考勤异常"));
children.push(body("因政府公告、强台风、交通管制等不可抗力原因造成不能正常出勤的，经人力资源管理部门确认后，统一采取临时措施处理异常考勤。"));

// --- Chapter: 法定休假管理 ---
children.push(h2("（三）法定休假管理"));
children.push(body("全体员工均享受国家规定的法定节假日休假。法定休假包括年休假、婚假、产假、陪产假、哺乳假、丧假等。"));

children.push(h3("第九条 年休假"));
children.push(body("1. 员工连续工作满 1 年以上，可享受带薪年休假。连续工作指在同一或不同用人单位的连续工作时间。"));
children.push(body("2. 员工累计工龄满 1 年不满 10 年的，年休假 5 天；累计工龄满 10 年不满 20 年的，年休假 10 天；累计工龄满 20 年的，年休假 15 天。"));
children.push(body("3. 年休假的最小休假单位为 0.5 天。"));
children.push(body("4. 新招聘录用员工在试用期的前 3 个月内不安排年休假，但可累计计算年休假天数。符合休假条件的新录用员工，当年度年休假天数按照在公司剩余日历天数折算确定，折算后不足一整天的不安排年休假。折算方法为：（当年度在公司剩余日历天数÷365 天）×员工本人全年应当享受的年休假天数。"));
children.push(body("5. 公司与员工解除或者终止劳动合同时，员工未休满应休年休假的，按照员工当年已工作时间折算应休未休年休假天数，给予员工享受未休年休假，折算后不足一整天的部分不享受未休年休假。折算方法为：（当年度在公司已过日历天数÷365 天）×员工本人全年应当享受的年休假天数 - 当年度已安排年休假天数。员工离职前已提前休完全年年休假的，按照上述折算方法折算员工实际年休假天数，超出的部分应在离职工资结算时予以扣回。"));
children.push(body("6. 年休假周期自每年 1 月 1 日开始，当年 12 月 31 日结束。年休假在 1 个年度内可分段安排，由员工本人提出休假申请。公司也可以根据员工本人工作完成情况安排休假。原则上年休假天数不得跨休假周期累加，如确有特殊情况，当年可享受年休假最晚须于次年 3 月底前休完。"));
children.push(body("7. 公司鼓励员工休年休假，年初各部门应当根据年度工作计划，在不影响正常工作秩序的情况下，统筹安排员工休假。"));
children.push(body("8. 年休假期不包含公休日及国家法定节假日。"));
children.push(body("9. 员工有以下情况之一的，不享受当年年休假："));
children.push(body("（1）累计工作满 1 年不满 10 年，当年请病假累计 2 个月以上的；"));
children.push(body("（2）累计工作满 10 年不满 20 年，当年请病假累计 3 个月以上的；"));
children.push(body("（3）累计工作满 20 年以上，当年请病假累计 4 个月以上的；"));
children.push(body("（4）当年已享受年休假，休假后又有上述情况发生者，下一年度不再享受年休假；"));
children.push(body("（5）员工脱产学习享受寒暑假的。"));

children.push(hrNote("年休假天数、折算方式、不享受情形均依据《职工带薪年休假条例》及《企业职工带薪年休假实施办法》，需确保与最新法规一致。"));

children.push(h3("第十条 婚假"));
children.push(body("1. 入职后依法办理结婚登记的员工可申请婚假。婚假天数按照员工工作所在地政策执行。"));
children.push(body("2. 婚假须一次休完，不可分次使用。"));
children.push(body("3. 婚假自结婚登记之日起一年内有效。"));
children.push(body("4. 员工在婚假期间享受正常工资待遇。"));
children.push(body("5. 婚假包含公休日及国家法定节假日。"));

children.push(hrNote("婚假天数各地政策不同（如广东3天，部分省市有延长），须明确适用标准。婚假期间工资待遇须符合当地规定。"));

children.push(h3("第十一条 产假、陪产假及哺乳假"));
children.push(body("1. 女员工按国家规定生育的，凭医院开具的产假证明休假。生育产假为 98 天，其中产前可以休假 15 天。难产的，增加产假 30 天。多胞胎生育的，每多生育一个婴儿，增加产假 15 天。除享受产假外，生育奖励假具体休假天数按照员工工作所在地政策执行。"));
children.push(body("2. 男员工配偶按规定生育的，自妻子分娩（有医院证明）之日起可享受陪产假 15 天，且须在婴儿满月前休完。"));
children.push(body("3. 根据医院出具的证明，女职工怀孕未满 4 个月流产的，享受 15 天产假；怀孕满 4 个月流产的，享受 42 天产假。"));
children.push(body("4. 产假及陪产假包含公休日及国家法定节假日。"));
children.push(body("5. 女员工怀孕，在工作时间内进行产前检查，享受正常工作时间工资待遇。每次产检时间原则上为半天，以产检预约单等相关证明材料为依据，超过规定时间的需提供医院检查证明材料，否则按其他假期处理。"));
children.push(body("6. 凡生育的女员工，在婴儿一周岁之内，每个工作日享有 1 小时哺乳假；生育多胞胎的，每多哺乳 1 个婴儿每天增加 1 小时哺乳假。哺乳时间原则上应安排在正常上班时间的第一个小时或者下班前的最后一个小时。"));
children.push(body("7. 女员工在规定的产假和哺乳假期间享受正常福利待遇。"));
children.push(body("8. 员工工作所在地产假、陪产假政策不一致的，以员工工作所在地政策为准。"));

children.push(hrNote("产假/陪产假天数及生育奖励假天数各地规定差异较大（部分省市奖励假30-80天不等），需逐地核实。女职工特殊保护涉及《女职工劳动保护特别规定》等法规，薪酬福利计算须经薪酬主管复核。"));

children.push(h3("第十二条 丧假"));
children.push(body("1. 员工直系亲属或其配偶的父母去世，给予丧假 3 天。直系亲属包括（外）祖父母、父母、配偶和子女。"));
children.push(body("2. 需要到外地料理丧事的，可根据实际情况适当给予路程假 1 天。"));
children.push(body("3. 员工在丧假期间享受正常工资待遇。"));
children.push(body("4. 丧假不包含公休日及国家法定节假日。"));

// --- Chapter: 特色休假 ---
children.push(h2("（四）公司特色休假管理"));
children.push(body("公司特色假，指公司为体现员工关爱而特别设定的员工可享有的休假，包括祝寿假、贡献假、春节探亲假、家长会假等。公司特色假享受正常工资待遇。"));

children.push(h3("第十三条 祝寿假"));
children.push(body("1. 员工在试用期转正后可享受对本人或配偶父母的祝寿假。"));
children.push(body("2. 员工每自然年度内累计可申请 2 天祝寿假；员工与父母属同省、自治区、直辖市范围内的，假期折半为 1 天。祝寿假可分次使用，休假最小单位为 1 天。"));
children.push(body("3. 祝寿假应在父母生日当日享受，特殊情况可适当提前或延后，但提前或延后的时间均不得超过一个月，过期不补。"));
children.push(body("4. 祝寿假需提供父母身份证复印件。"));
children.push(body("待补充：__________（祝寿假的证明材料收集及隐私保护措施需进一步明确）"));

children.push(h3("第十四条 贡献假"));
children.push(body("1. 为奖励工作表现优秀、价值贡献大的员工，年度绩效考核为“卓越”、“优秀”的，可享受贡献假。"));
children.push(body("2. 凡年度绩效考核为“卓越”的员工，次年可享受 2 天带薪假期；凡年度绩效考核为“优秀”的员工，次年可享受 1 天带薪假期。贡献假可分次使用，休假最小单位为 0.5 天。"));
children.push(body("3. 贡献假天数不包含公休日及国家法定节假日。"));
children.push(body("4. 贡献假应在一个自然年度休完，过期不补。"));

children.push(hrNote("贡献假以绩效考核结果为前置条件，绩效评定的公平性和申诉机制需在绩效管理制度中明确。"));

children.push(h3("第十五条 春节探亲假"));
children.push(body("为错开春节期间春运高峰，方便外地员工春节期间回家探亲，外地员工春节前享受 1 天春节探亲假，春节探亲假仅限春节开始前一天使用。"));
children.push(body("待补充：__________（“外地员工”的具体认定标准需明确，如户籍地、居住地与工作地距离等）"));

children.push(h3("第十六条 家长会假"));
children.push(body("为帮助员工关注子女成长，员工需开家长会的，提供学校家长会通知，每学期享有半天的家长会假。"));

// --- Chapter: 其他假期 ---
children.push(h2("（五）其他假期管理"));
children.push(body("其他假期包括事假、病假。"));

children.push(h3("第十七条 事假"));
children.push(body("1. 员工因私事确需本人办理，在不影响正常工作秩序的情况下，在规定工作时间内不能按时出勤视为事假。"));
children.push(body("2. 原则上事假申请一次不得超过 3 天，一年累计不得超过 15 天。事假最小单位为 1 小时，实际事假时间根据考勤记录统计。"));
children.push(body("3. 员工申请事假，缺勤日不计发工资："));
children.push(body("（1）事假 1 天或以上的，扣发工资按以下规则计算：事假应扣工资 = 月度收入 / 当月应出勤天数 × 事假天数。"));
children.push(body("（2）事假不足一日的，按出勤小时数计发工资：事假应扣工资 = 月度收入 / 当月应出勤天数 / 7.5 × 事假小时数。"));
children.push(body("4. 员工申请事假，公司有权决定批准与否。公司不予批准的，员工不得强行休假，否则按旷工处理。"));

children.push(hrNote("事假期间的工资扣发计算方式、审批权限需经薪酬主管和法务复核，确保符合当地最低工资保障规定。"));

children.push(h3("第十八条 病假"));
children.push(body("1. 员工因病需要到医院就诊，应事先请假（急诊除外）。就诊后凭诊断证明休假。员工因病休假一天以内的，可不提供休假证明；超过一天的，以医院开具的休假证明时间为依据；超过一天且无病休证明的，公司视具体情况按事假或旷工处理。员工大病住院或有医院证明必须离岗休养的，按照国家有关规定享受医疗期待遇。"));
children.push(body("2. 员工休病假需提供二级以上医院或社区医疗服务机构（市医保定点）开具的病假条或诊断证明；连续休病假七天以上的，须提供二级以上医院开具的病假条或诊断证明；连续休病假十天以上的，原则上应提供二级以上医院的住院证明。"));
children.push(body("3. 员工病假期间，按照正常工作时间工资的 60% 计发工资。上述发放标准与员工工作所在地病假工资支付规定不一致的，按员工工作所在地病假工资支付规定执行。"));
children.push(body("4. 连续休病假 10 天以上（含 10 天）或 3 个月内累计休病假 30 天以上（含 30 天）的，享受医疗期待遇。"));
children.push(body("5. 员工因患病或非因工负伤，需要停止工作进行医疗时，根据其本人实际参加工作年限和在公司工作年限，给予 3 个月到 24 个月的医疗期。员工患特殊病种，在 24 个月内尚不能痊愈的，经公司和劳动主管部门批准，可适当延长医疗期。"));
children.push(body("6. 医疗期标准：员工医疗期间按照月基本薪酬的 60% 计发工资，且不低于当地最低工资标准的 80%。具体医疗期如下表："));

// 医疗期表格
children.push(makeTable(
  ["实际工作年限", "公司工作年限", "医疗期", "医疗期累计时间"],
  [
    ["10年（含）以下", "5年（含）以下", "3个月", "6个月"],
    ["10年（含）以下", "5年以上", "6个月", "12个月"],
    ["10年以上", "5年（含）以下", "6个月", "12个月"],
    ["10年以上", "5-10年（含）", "9个月", "15个月"],
    ["10年以上", "10-15年（含）", "12个月", "18个月"],
    ["10年以上", "15-20年（含）", "18个月", "24个月"],
    ["10年以上", "20年以上", "24个月", "30个月"],
  ],
  [2500, 2500, 2000, CONTENT_W - 7000]
));

children.push(body("7. 医疗期包含公休日及国家法定节假日。"));

children.push(hrNote("医疗期标准依据《企业职工患病或非因工负伤医疗期规定》（劳部发〔1994〕479号）。病假工资支付标准依据地方性法规（如《深圳市员工工资支付条例》《上海市企业工资支付办法》等），各地最低标准不同，需逐一核实。"));;

// --- Chapter: 请休假手续 ---
children.push(h2("（六）请休假手续管理"));

children.push(h3("第十九条 请休假审批流程"));
children.push(body("请休假的员工需在公司办公平台上提前履行报批手续，经审批同意后方可请休假。如因不可抗力原因造成无法事前请准，须申述合理理由，呈请准许后方可补假。请休假、出差、市内公出等补假手续每月不得超过 3 次，超过限定次数的，根据实际情况视为迟到、早退或旷工。未事前请准，或申述理由未获批准而缺少考勤记录的，视为旷工。请休假核准后未休假的，须在办公平台完成销假审批手续。"));

children.push(h3("第二十条 证明材料真实性"));
children.push(body("员工请休假需提供真实的证明材料，如一旦发现提供虚假材料的，请休假期将按旷工处理，公司有权取消员工法定假期之外的当年度全部福利假期，情节严重的，视为严重违纪行为。"));

children.push(hrNote("以提供虚假材料为由取消福利假期、认定严重违纪等涉及员工纪律处分，须确保程序合法（如给予员工申辩机会、书面通知等），相关法律风险需法务部门评估。"));

children.push(h3("第二十一条 因私出国境"));
children.push(body("公司在公安部门报备员工因私出国境的，按照公司因公（私）出国管理办法相关规定执行。"));
children.push(body("待补充：__________（因私出国境管理办法的完整引用名称及文档链接）"));

// --- Chapter: 奖惩规定 ---
children.push(h2("（七）奖惩规定"));

children.push(h3("第二十二条 免打卡管理"));
children.push(body("员工上年度考勤统计情况较好，且年度绩效考核结果“优秀”及以上的，由人力资源管理部门结合统计信息，征询用人部门意见后，确定次年一定比例的免打卡员工名单。"));
children.push(body("免打卡名单每年初确定，公司有权结合员工免打卡期间的月度、季度绩效考核结果适时调整。同时建立员工监督机制，凡被查实免打卡人员存在严重违法劳动纪律的，公司有权即时取消免打卡资格。"));

children.push(h3("第二十三条 代打卡"));
children.push(body("全体员工应严格遵守工作时间，除免打卡员工外，其余员工上下班执行考勤打卡制度，不得代打卡。代打卡属弄虚作假行为，一经发现，代打卡双方均按严重违反公司规章制度处理，公司有权依照法定程序解除劳动合同关系而不支付任何经济补偿金或赔偿金。"));

children.push(hrNote(`解除劳动合同且不支付经济补偿金的依据为《劳动合同法》第三十九条第（二）项"严重违反用人单位的规章制度"。须确保公司规章制度的制定程序合法（经民主程序、公示告知）、代打卡行为在制度中明确界定为"严重违纪"。`));

children.push(h3("第二十四条 迟到、早退"));
children.push(body("员工不得迟到、早退。迟到早退的员工，根据实际考勤记录计扣工资。"));

children.push(h3("第二十五条 漏打卡处罚"));
children.push(body("员工每月漏打卡超过 2 次的部分，按照 100 元/次计扣当月绩效工资；漏打卡情形每月达到 5 次的，根据本办法第二十七条第（三）项的规定，按旷工处理。"));

children.push(hrNote("绩效工资扣减金额是否违反工资支付规定（如扣减后低于最低工资标准等），需薪酬主管复核。"));

children.push(h3("第二十六条 旷工"));
children.push(body("旷工属于违反公司规章制度的行为，员工每旷工一天，计扣当日工资的 2 倍，依此类推。一年内连续旷工 3 天或累计旷工 10 天，属严重违反公司规章制度，公司有权依照法定程序解除劳动合同关系而不支付任何经济补偿金或赔偿金。"));

children.push(hrNote("旷工工资扣减倍数（2倍）是否符合法律法规，需法务评估。连续旷工3天/累计10天即解雇的标准需与当地司法实践对照，确保在劳动争议中具有合理性。"));

children.push(h3("第二十七条 旷工行为认定"));
children.push(body("以下情形属于旷工行为："));
children.push(body("（一）每月迟到、早退累计达 2 小时或 4 次及以上，视为旷工半天；依次累计。"));
children.push(body("（二）一次迟到 2 小时或早退 2 小时以上，未在事前、事后报批，视为旷工 1 天。"));
children.push(body("（三）每月漏打卡达到 5 次的，从第 5 次起每漏打卡 1 次，视为旷工半天；依次累计。"));
children.push(body("（四）工作时间内擅离职守每次超过 1 小时或累计达到 2 小时，视为旷工半天；超过 2 小时或累计达到 4 小时，视为旷工 1 天。"));
children.push(body("（五）缺少考勤记录，而又未在规定的时间内履行完请休假、出差、市内公出报批手续，或相关报批手续未获批准的，视为旷工。"));
children.push(body("（六）请休假期满后未按规定时间返回上班，未办理续假审批手续，或者续假申请未获批准而缺少考勤记录。"));
children.push(body("（七）不服从调动和工作分配，不按时到调配的工作岗位报到。"));
children.push(body("（八）其他无故未正常上班或未实际参加劳动的情形。"));

// --- Chapter: 强制休假 ---
children.push(h2("（八）强制休假"));

children.push(h3("第二十八条 强制休假定义"));
children.push(body("强制休假指根据监管单位和公司相关规定，为完善内控机制，防范操作风险，对关键人员、重要岗位员工或其他有必要予以强制休假的人员，在事前不告知的情况下，安排其离岗休假，并对其分管（经办）的工作进行离岗检查。关键人员和重要岗位员工范围根据员工履职回避管理办法确定。"));
children.push(body("待补充：__________（“员工履职回避管理办法”的完整名称及关键人员、重要岗位的具体范围需引用对应制度文件明确）"));

children.push(h3("第二十九条 强制休假适用情形"));
children.push(body("下列情形应实行强制休假："));
children.push(body("（一）分管（经办）业务出现或者可能出现风险的；"));
children.push(body("（二）岗位轮换有难度的人员，因特殊原因需要延期实行岗位轮换；"));
children.push(body("（三）根据公司决定的其他工作需要情形。"));

children.push(h3("第三十条 强制休假期限"));
children.push(body("（一）强制休假具体天数根据公司审批意见为准；"));
children.push(body("（二）公司安排员工强制休假的，应优先从当年度带薪年休假中扣除相应天数，当年度年休假不足的，从下一年度的年休假中扣除。"));

children.push(hrNote("强制休假从年休假中扣除是否合法，需确认：若年休假不足而从下一年度扣除，是否构成变相扣减法定休假权益。"));

children.push(h3("第三十一条 强制休假纪律"));
children.push(body("强制休假人员在休假期间必须保证联络畅通，否则按员工违规行为问责有关制度办法进行处理。"));
children.push(body("强制休假人员在休假期间未经公司人力资源管理部门书面通知，不得返回工作岗位，也不得向有关人员询问离任审计或检查情况，否则按员工违规行为问责有关制度办法进行处理。"));

children.push(h3("第三十二条 强制休假工作流程"));
children.push(body("（一）制定实施方案。人力资源管理部门结合稽核审计管理部门相关要求制定强制休假的具体方案，方案应包括休假时间、代职安排、工作交接、离岗审计或检查方式等内容。"));
children.push(body("（二）宣布休假决定。人力资源管理部门以书面形式通知强休假人员相关决定。在强制休假决定正式公布前，有关部门和知情人要严格保密。"));
children.push(body("（三）落实交接手续。稽核审计管理部门按有关规定办理强制休假人员与代职人员的交接手续并限期离岗，未经稽核审计管理部门许可，强制休假人员在强制休假期间须暂停行使其职权，不得返回工作岗位，也不得向公司内其他人员发出任何工作指令或处理有关工作。交接工作在指定专人的监督下实行。"));
children.push(body("（四）实施离岗审计或检查。稽核审计管理部门根据具体情况专门组织审计力量对强制休假人员实施离岗审计或检查，并出具书面审计或检查报告。稽核审核管理部门在审计期间，有权要求强制休假人员随时回公司提供有关资料或进行必要的情况说明。强制休假人员应当与组织实施单位保持通畅联系，按要求配合做好有关离岗审计或检查工作。"));

// =================== 八、监督与复盘机制 ===================
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(h1("八、监督与复盘机制"));

children.push(h2("（一）日常监督"));
children.push(body("1. 人力资源管理部门每月对考勤数据进行统计分析，识别异常考勤模式（如高频迟到、高频漏打卡、月末集中休假等），形成《月度考勤异常分析报告》，抄送相关部门负责人。"));
children.push(body("2. 各用人部门负责人应当每季度对本部门员工考勤纪律执行情况进行自查，发现问题及时纠正并报告人力资源管理部门。"));
children.push(body("3. 公司设立考勤违纪举报渠道，接受员工对代打卡、虚假请休假等违规行为的实名举报。举报经查实的，对举报人给予保密和保护。"));

children.push(h2("（二）定期复盘"));
children.push(body("1. 人力资源管理部门每半年组织一次考勤及请休假制度执行情况复盘，内容应包括："));
children.push(body("（1）考勤异常率趋势分析；"));
children.push(body("（2）各假期类型使用率及分布；"));
children.push(body("（3）违纪处理情况汇总；"));
children.push(body("（4）强制休假执行情况；"));
children.push(body("（5）免打卡员工履职情况抽查。"));
children.push(body("2. 根据复盘结果，人力资源管理部门应提出制度优化建议，包括但不限于条款修订、流程简化、系统改进等，报公司管理层审批。"));

children.push(h2("（三）年度审计"));
children.push(body("稽核审计管理部门每年至少一次对考勤及请休假管理的执行合规性进行专项审计，审计报告应涵盖以下方面："));
children.push(body("（一）考勤数据的完整性、准确性和不可篡改性；"));
children.push(body("（二）请休假审批流程的合规性（包括审批权限、时限、证明材料的完整性）；"));
children.push(body("（三）违纪处理的程序合法性（包括调查、申辩、告知、送达等环节）；"));
children.push(body("（四）强制休假制度的执行覆盖率。"));
children.push(body("待补充：__________（年度审计的具体抽样比例、审计标准、整改追踪机制）"));

children.push(h2("（四）绩效考核关联"));
children.push(body("1. 考勤结果纳入员工个人月度/季度/年度绩效考核，具体权重由绩效管理制度规定。"));
children.push(body("2. 部门整体考勤合规率纳入部门负责人年度管理绩效考核。"));
children.push(body("3. 全年累计旷工 1 天及以上的员工，取消当年度评优评先资格。"));

// =================== 九、附则 ===================
children.push(h1("九、附则"));

children.push(h3("第三十三条 制度编号与版本"));
children.push(body(`本办法制度编号为 ${new Date().toISOString().slice(0, 10).replace(/-/g, "")}，公司内部发文编号由行政管理部门统一编排。`));

children.push(h3("第三十四条 解释权"));
children.push(body("本办法由人力资源管理部门负责解释。"));

children.push(h3("第三十五条 生效日期"));
children.push(body(`本办法自 ${new Date().toISOString().slice(0, 10)} 起生效，原有考勤及请休假管理规定同时废止。`));

children.push(h3("第三十六条 修订"));
children.push(body("本办法根据国家法律法规变化及公司管理需要适时修订，修订程序按公司制度管理办法执行。"));

children.push(h3("第三十七条 冲突处理"));
children.push(body("本办法如与国家法律法规、地方性法规或上级主管部门规定不一致的，以法律法规和上级规定为准。"));

children.push(h3("第三十八条 未尽事宜"));
children.push(body("本办法未尽事宜，按照国家有关法律法规及公司其他相关制度执行。"));

// ====================== ASSEMBLE & SAVE ======================

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT_BODY, size: 24 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, font: FONT_TITLE },
        paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: FONT_TITLE },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT_TITLE },
        paragraph: { spacing: { before: 180, after: 100 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: A4_W, height: A4_H },
        margin: { top: MARGIN, bottom: MARGIN, left: MARGIN, right: MARGIN }
      }
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "国任保险员工考勤及请休假管理办法", font: FONT_TITLE, size: 18, color: "888888" })],
        })]
      })
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: "- ", size: 18 }), new TextRun({ children: [PageNumber.CURRENT], size: 18 }), new TextRun({ text: " -", size: 18 })],
        })]
      })
    },
    children,
  }]
});

const outPath = "C:/Users/Lenovo/WorkBuddy/2026-06-16-10-19-35/国任保险员工考勤及请休假管理办法（制度初稿）.docx";
Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outPath, buf);
  console.log("Done: " + outPath + " (" + buf.length + " bytes)");
}).catch(e => { console.error(e); process.exit(1); });
