# -*- coding: utf-8 -*-
"""
岗位说明书 Word 文档生成器

基于"附件4.分公司岗位说明书(2020版）"模板格式生成 Word 文档。

使用方式:
  python generate_jd_docx.py <input_json> <output_docx>

参数:
  input_json  - 岗位说明书数据的 JSON 文件路径
  output_docx - 输出的 Word 文档路径

JSON 格式参见 scripts/jd_sample_input.json

依赖: python-docx
安装: pip install python-docx
"""

import json
import sys
import os
from datetime import datetime
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml

# ========== 工具函数 ==========

def set_cell_shading(cell, color):
    """设置单元格背景色"""
    shading_elm = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color}"/>')
    cell._tc.get_or_add_tcPr().append(shading_elm)


def set_cell_width(cell, width_cm):
    """设置单元格宽度"""
    cell.width = Cm(width_cm)


def add_formatted_paragraph(doc, text, font_name='微软雅黑', font_size=11,
                            bold=False, color=None, alignment=None,
                            space_before=0, space_after=6, first_line_indent=None):
    """添加格式化段落"""
    para = doc.add_paragraph()
    run = para.add_run(text)
    run.font.name = font_name
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    if color:
        run.font.color.rgb = RGBColor(*color)
    if alignment is not None:
        para.alignment = alignment
    para.paragraph_format.space_before = Pt(space_before)
    para.paragraph_format.space_after = Pt(space_after)
    if first_line_indent:
        para.paragraph_format.first_line_indent = Cm(first_line_indent)
    return para


def add_bullet_point(doc, text, font_size=10, indent_level=0):
    """添加项目符号"""
    para = doc.add_paragraph(style='List Bullet')
    para.clear()
    run = para.add_run(text)
    run.font.name = '微软雅黑'
    run.font.size = Pt(font_size)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    para.paragraph_format.space_before = Pt(2)
    para.paragraph_format.space_after = Pt(2)
    if indent_level > 0:
        para.paragraph_format.left_indent = Cm(1.27 * indent_level)
    return para


def add_numbered_item(doc, number, text, font_size=10.5, bold_prefix=None):
    """添加编号条目"""
    para = doc.add_paragraph()
    if bold_prefix:
        run_bold = para.add_run(f"{number}. {bold_prefix}")
        run_bold.font.name = '微软雅黑'
        run_bold.font.size = Pt(font_size)
        run_bold.font.bold = True
        run_bold._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        run_normal = para.add_run(text)
        run_normal.font.name = '微软雅黑'
        run_normal.font.size = Pt(font_size)
        run_normal._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    else:
        run = para.add_run(f"{number}. {text}")
        run.font.name = '微软雅黑'
        run.font.size = Pt(font_size)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    para.paragraph_format.space_before = Pt(3)
    para.paragraph_format.space_after = Pt(3)
    para.paragraph_format.left_indent = Cm(0.63)
    return para


def add_info_table(doc, data_dict):
    """添加信息表格（键值对，2列）"""
    table = doc.add_table(rows=len(data_dict), cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, (key, value) in enumerate(data_dict.items()):
        cell_key = table.rows[i].cells[0]
        cell_val = table.rows[i].cells[1]
        cell_key.width = Cm(3.5)
        cell_val.width = Cm(12.5)
        # 键列
        run_key = cell_key.paragraphs[0].add_run(str(key))
        run_key.font.name = '微软雅黑'
        run_key.font.size = Pt(10)
        run_key.font.bold = True
        run_key.font.color.rgb = RGBColor(89, 89, 89)
        run_key._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        set_cell_shading(cell_key, 'F2F2F2')
        # 值列
        run_val = cell_val.paragraphs[0].add_run(str(value) if value else '')
        run_val.font.name = '微软雅黑'
        run_val.font.size = Pt(10)
        run_val._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    return table


def add_responsibility_table(doc, responsibilities):
    """添加主要职责表格（4列：职责模块、具体职责、交付成果、协作对象）"""
    rows = len(responsibilities) + 1  # +1 for header
    table = doc.add_table(rows=rows, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.style = 'Table Grid'

    # 表头
    headers = ['职责模块', '具体职责', '交付成果', '协作对象']
    header_widths = [2.5, 6.5, 3.5, 3.5]
    for j, header in enumerate(headers):
        cell = table.rows[0].cells[j]
        cell.width = Cm(header_widths[j])
        run = cell.paragraphs[0].add_run(header)
        run.font.name = '微软雅黑'
        run.font.size = Pt(10)
        run.font.bold = True
        run.font.color.rgb = RGBColor(255, 255, 255)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        set_cell_shading(cell, '1F4981')
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    # 数据行
    for i, resp in enumerate(responsibilities):
        row_data = [
            resp.get('module', ''),
            resp.get('duties', ''),
            resp.get('deliverables', ''),
            resp.get('collaborators', '')
        ]
        for j, val in enumerate(row_data):
            cell = table.rows[i + 1].cells[j]
            cell.width = Cm(header_widths[j])
            run = cell.paragraphs[0].add_run(str(val))
            run.font.name = '微软雅黑'
            run.font.size = Pt(9)
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
            if i % 2 == 1:
                set_cell_shading(cell, 'F5F8FC')
    return table


def add_kpi_table(doc, kpi_list):
    """添加绩效指标表格（4列：指标、指标定义、评价周期、数据来源）"""
    rows = len(kpi_list) + 1
    table = doc.add_table(rows=rows, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.style = 'Table Grid'

    headers = ['指标', '指标定义', '评价周期', '数据来源']
    header_widths = [3.0, 7.0, 2.5, 3.5]
    for j, header in enumerate(headers):
        cell = table.rows[0].cells[j]
        cell.width = Cm(header_widths[j])
        run = cell.paragraphs[0].add_run(header)
        run.font.name = '微软雅黑'
        run.font.size = Pt(10)
        run.font.bold = True
        run.font.color.rgb = RGBColor(255, 255, 255)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        set_cell_shading(cell, '1F4981')
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    for i, kpi in enumerate(kpi_list):
        row_data = [
            kpi.get('indicator', ''),
            kpi.get('definition', ''),
            kpi.get('cycle', ''),
            kpi.get('source', '')
        ]
        for j, val in enumerate(row_data):
            cell = table.rows[i + 1].cells[j]
            cell.width = Cm(header_widths[j])
            run = cell.paragraphs[0].add_run(str(val))
            run.font.name = '微软雅黑'
            run.font.size = Pt(9)
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
            if i % 2 == 1:
                set_cell_shading(cell, 'F5F8FC')
    return table


def add_section_header(doc, text):
    """添加章节标题（蓝色带底线）"""
    para = doc.add_paragraph()
    run = para.add_run(text)
    run.font.name = '微软雅黑'
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.color.rgb = RGBColor(31, 73, 125)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    para.paragraph_format.space_before = Pt(18)
    para.paragraph_format.space_after = Pt(8)
    pPr = para._element.get_or_add_pPr()
    pBdr = parse_xml(
        f'<w:pBdr {nsdecls("w")}>'
        f'  <w:bottom w:val="single" w:sz="4" w:space="1" w:color="1F4891"/>'
        f'</w:pBdr>'
    )
    pPr.append(pBdr)
    return para


def add_subsection_header(doc, text):
    """添加子章节标题"""
    para = doc.add_paragraph()
    run = para.add_run(text)
    run.font.name = '微软雅黑'
    run.font.size = Pt(11)
    run.font.bold = True
    run.font.color.rgb = RGBColor(68, 114, 196)
    run._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    para.paragraph_format.space_before = Pt(12)
    para.paragraph_format.space_after = Pt(6)
    return para


def add_compliance_item(doc, status, text):
    """添加合规检查条目（带彩色标记）"""
    para = doc.add_paragraph()
    icons = {'pass': ('  [PASS] ', (0, 128, 0)), 'warn': ('  [WARN] ', (255, 165, 0)), 'fail': ('  [FAIL] ', (255, 0, 0))}
    icon, color = icons.get(status, ('  [INFO] ', (128, 128, 128)))
    run_icon = para.add_run(icon)
    run_icon.font.name = '微软雅黑'
    run_icon.font.size = Pt(10)
    run_icon.font.bold = True
    run_icon.font.color.rgb = RGBColor(*color)
    run_icon._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    run_text = para.add_run(text)
    run_text.font.name = '微软雅黑'
    run_text.font.size = Pt(10)
    run_text._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    para.paragraph_format.space_before = Pt(2)
    para.paragraph_format.space_after = Pt(2)
    return para


def add_horizontal_line(doc):
    """添加水平分隔线"""
    para = doc.add_paragraph()
    pPr = para._element.get_or_add_pPr()
    pBdr = parse_xml(
        f'<w:pBdr {nsdecls("w")}>'
        f'  <w:bottom w:val="single" w:sz="6" w:space="1" w:color="D9E2F3"/>'
        f'</w:pBdr>'
    )
    pPr.append(pBdr)


def add_highlight_box(doc, title, content, box_color='FFF2CC', border_color='D6B656'):
    """添加高亮提示框"""
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, box_color)
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(
        f'<w:tcBorders {nsdecls("w")}>'
        f'  <w:top w:val="single" w:sz="8" w:space="0" w:color="{border_color}"/>'
        f'  <w:left w:val="single" w:sz="8" w:space="0" w:color="{border_color}"/>'
        f'  <w:bottom w:val="single" w:sz="8" w:space="0" w:color="{border_color}"/>'
        f'  <w:right w:val="single" w:sz="8" w:space="0" w:color="{border_color}"/>'
        f'</w:tcBorders>'
    )
    tcPr.append(tcBorders)
    run_title = cell.paragraphs[0].add_run(title)
    run_title.font.name = '微软雅黑'
    run_title.font.size = Pt(10)
    run_title.font.bold = True
    run_title.font.color.rgb = RGBColor(156, 101, 0)
    run_title._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    run_content = cell.add_paragraph().add_run(content)
    run_content.font.name = '微软雅黑'
    run_content.font.size = Pt(9)
    run_content._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')


# ========== 主生成函数 ==========

def generate_jd_docx(data, output_path):
    """根据岗位说明书数据生成 Word 文档"""
    doc = Document()

    # ===== 页面设置 =====
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.5)
    section.bottom_margin = Cm(2.5)
    section.left_margin = Cm(2.5)
    section.right_margin = Cm(2.5)

    # ===== 文档标题 =====
    add_formatted_paragraph(doc, '岗 位 说 明 书', font_name='微软雅黑',
                           font_size=20, bold=True,
                           color=(31, 73, 125),
                           alignment=WD_ALIGN_PARAGRAPH.CENTER,
                           space_before=6, space_after=4)

    gen_time = data.get('generated_at', datetime.now().strftime('%Y-%m-%d %H:%M'))
    add_formatted_paragraph(doc, f'文档生成时间：{gen_time}',
                           font_size=9, color=(128, 128, 128),
                           alignment=WD_ALIGN_PARAGRAPH.CENTER,
                           space_before=0, space_after=6)
    add_horizontal_line(doc)

    # ===== 一、岗位基本信息 =====
    add_section_header(doc, '一、岗位基本信息')
    basic_info = data.get('basic_info', {})
    info_labels = {
        'role_name': '岗位名称',
        'organization': '所属部门',
        'job_code': '岗位编号',
        'level': '职级',
        'report_to': '汇报对象',
        'headcount': '岗位编制'
    }
    info_pairs = {}
    for key, label in info_labels.items():
        val = basic_info.get(key, '')
        if val:
            info_pairs[label] = val
    add_info_table(doc, info_pairs)

    # ===== 二、岗位使命 =====
    mission = data.get('mission', '')
    if mission:
        add_section_header(doc, '二、岗位使命')
        add_formatted_paragraph(doc, mission, font_size=10.5,
                               first_line_indent=0.74, space_before=4, space_after=4)

    # ===== 三、主要职责 =====
    responsibilities = data.get('responsibilities', [])
    if responsibilities:
        add_section_header(doc, '三、主要职责')
        add_responsibility_table(doc, responsibilities)

    # ===== 四、任职资格 =====
    qualifications = data.get('qualifications', {})
    if qualifications:
        add_section_header(doc, '四、任职资格')

        # 任职资格维度表
        qual_labels = {
            'education': '学历要求',
            'knowledge_skills': '知识/资格证书/专业技能',
            'work_experience': '工作经验要求',
            'competency': '胜任能力'
        }
        qual_pairs = {}
        for key, label in qual_labels.items():
            val = qualifications.get(key, '')
            if val:
                qual_pairs[label] = val
        add_info_table(doc, qual_pairs)

        # 必备条件
        must_have = qualifications.get('must_have', [])
        if must_have:
            add_subsection_header(doc, '必备条件')
            for i, item in enumerate(must_have, 1):
                add_numbered_item(doc, i, item)

        # 加分条件
        nice_to_have = qualifications.get('nice_to_have', [])
        if nice_to_have:
            add_subsection_header(doc, '加分条件')
            for i, item in enumerate(nice_to_have, 1):
                add_numbered_item(doc, i, item)

    # ===== 五、权限边界 =====
    authority = data.get('authority', {})
    if authority:
        add_section_header(doc, '五、权限边界')
        auth_labels = {
            'personnel': '人事权限',
            'financial': '财务权限',
            'business': '业务决策权限'
        }
        auth_pairs = {}
        for key, label in auth_labels.items():
            val = authority.get(key, '')
            if val:
                auth_pairs[label] = val
        add_info_table(doc, auth_pairs)

    # ===== 六、绩效指标建议 =====
    kpi_list = data.get('kpi', [])
    if kpi_list:
        add_section_header(doc, '六、绩效指标建议')
        add_kpi_table(doc, kpi_list)

    # ===== 七、版本变更说明 =====
    change_log = data.get('change_log', {})
    if change_log:
        add_section_header(doc, '七、版本变更说明')

        added = change_log.get('added', [])
        if added:
            add_subsection_header(doc, '新增内容')
            for item in added:
                add_bullet_point(doc, item)

        removed = change_log.get('removed', [])
        if removed:
            add_subsection_header(doc, '删除内容')
            for item in removed:
                add_bullet_point(doc, item)

        modified = change_log.get('modified', [])
        if modified:
            add_subsection_header(doc, '调整内容')
            for item in modified:
                add_bullet_point(doc, item)

        to_confirm = change_log.get('items_to_confirm', [])
        if to_confirm:
            add_subsection_header(doc, '待确认问题')
            for item in to_confirm:
                add_bullet_point(doc, item)

    # ===== 合规检查 =====
    compliance = data.get('compliance', {})
    if compliance:
        add_section_header(doc, '八、合规检查')

        checks = compliance.get('checks', [])
        for item in checks:
            add_compliance_item(doc, item.get('status', 'pass'), item.get('text', ''))

        avoided = compliance.get('avoided_expressions', [])
        if avoided:
            add_subsection_header(doc, '已规避的敏感表述')
            for expr in avoided:
                add_bullet_point(doc, expr)

        to_confirm = compliance.get('items_to_confirm', [])
        if to_confirm:
            add_subsection_header(doc, '需要 HR 确认的内容')
            for item in to_confirm:
                add_bullet_point(doc, item)

    # ===== 免责声明 =====
    add_horizontal_line(doc)
    add_highlight_box(
        doc,
        '免责声明',
        '本岗位说明书为 HR 教学练习草稿，基于模拟数据生成，仅供练习使用。正式使用前须由 HR 专业人士、用人部门负责人及相关合规人员进行人工复核确认。'
    )

    # ===== 保存 =====
    doc.save(output_path)
    print(f"Word 文档已生成: {output_path}")
    return output_path


def main():
    if len(sys.argv) < 3:
        print("使用方式: python generate_jd_docx.py <input.json> <output.docx>")
        print("  input.json  - 岗位说明书数据的 JSON 文件路径")
        print("  output.docx - 输出的 Word 文档路径")
        sys.exit(1)

    input_json = sys.argv[1]
    output_docx = sys.argv[2]

    with open(input_json, 'r', encoding='utf-8') as f:
        data = json.load(f)

    generate_jd_docx(data, output_docx)


if __name__ == '__main__':
    main()
