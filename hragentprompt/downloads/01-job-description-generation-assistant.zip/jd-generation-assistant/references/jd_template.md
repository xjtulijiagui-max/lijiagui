# JD 标准模板

## 一、基本信息

| 字段 | 内容 |
|---|---|
| 岗位名称 | {{role_name}} |
| 所属部门 | {{department}} |
| 汇报对象 | {{report_to}}（可选） |
| 工作地点 | {{location}} |
| 用工类型 | {{employment_type}} |
| 职级 | {{seniority}} |

## 二、岗位背景与业务目标

{{business_goal}}

（说明该岗位为何设立、需要解决什么核心问题、对业务的价值贡献）

## 三、岗位职责

### 核心职责（必须完成）

1. {{core_responsibility_1}}
2. {{core_responsibility_2}}
3. {{core_responsibility_3}}

### 辅助职责（配合完成）

1. {{supporting_responsibility_1}}
2. {{supporting_responsibility_2}}

## 四、任职要求

### 必备条件（Must Have）

1. {{must_have_skill_1}}
2. {{must_have_skill_2}}
3. {{must_have_skill_3}}

### 加分条件（Nice to Have）

1. {{nice_to_have_skill_1}}
2. {{nice_to_have_skill_2}}

## 五、面试关注点

| 考察维度 | 建议提问方向 |
|---|---|
| {{competency_1}} | {{interview_question_1}} |
| {{competency_2}} | {{interview_question_2}} |
| {{competency_3}} | {{interview_question_3}} |

## 六、反歧视合规声明

本岗位说明不含任何基于性别、年龄、民族、婚育状况、健康状况、宗教信仰、户籍/地域等敏感属性的限制性条款。

---

> **模板使用说明**
> - `{{}}` 中的变量为占位符，实际生成时替换为具体内容
> - 核心职责一般 3-5 条，辅助职责 2-3 条
> - 面试关注点一般 3-5 个考察维度
> - 最后必须包含反歧视合规声明
