#!/usr/bin/env python3
"""
离职处理辅助报告 → PDF 生成脚本

用法:
  python generate_pdf.py <markdown_file> <output_pdf>

示例:
  python generate_pdf.py report.md 离职处理报告-张三.pdf

依赖: fpdf2 (自动安装于隔离 venv)
字体: 使用 Windows 系统自带中文字体 (simhei.ttf + simsun.ttc)
"""

import sys
import os
import re
import textwrap
import subprocess
from datetime import datetime

# ── 隔离环境：使用 WorkBuddy 管理的 Python venv ──────────────────────
VENV_DIR = r"C:\ProgramData\WorkBuddy\chromium-env\135xu5z\.workbuddy\binaries\python\envs\default"
MANAGED_PYTHON = r"C:\ProgramData\WorkBuddy\chromium-env\135xu5z\.workbuddy\binaries\python\versions\3.13.12\python.exe"

# 如果不是在 venv 中运行，用 subprocess 重新在 venv 中执行
VENV_PYTHON = os.path.join(VENV_DIR, "Scripts", "python.exe")
if os.path.normcase(sys.executable) != os.path.normcase(VENV_PYTHON):
    if not os.path.exists(VENV_PYTHON):
        subprocess.run([MANAGED_PYTHON, "-m", "venv", VENV_DIR], check=True)
    result = subprocess.run([VENV_PYTHON] + sys.argv)
    sys.exit(result.returncode)

# ── 自动安装 fpdf2 ──────────────────────────────────────────────────
try:
    from fpdf import FPDF
except ImportError:
    pip = os.path.join(VENV_DIR, "Scripts", "pip.exe")
    subprocess.run([pip, "install", "fpdf2"], check=True)
    from fpdf import FPDF

# ── 字体路径 ────────────────────────────────────────────────────────
FONT_DIR = r"C:\Windows\Fonts"
FONT_BOLD = os.path.join(FONT_DIR, "simhei.ttf")    # 黑体 → 标题
FONT_REGULAR = os.path.join(FONT_DIR, "simsun.ttc")  # 宋体 → 正文
FONT_MONO = os.path.join(FONT_DIR, "simkai.ttf")     # 楷体 → 引用/提示

# 检查字体是否存在
for fp in [FONT_BOLD, FONT_REGULAR, FONT_MONO]:
    if not os.path.exists(fp):
        print(f"[错误] 找不到字体文件: {fp}", file=sys.stderr)
        sys.exit(1)


class HRReportPDF(FPDF):
    """离职处理辅助报告 PDF 生成器"""

    def __init__(self):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.set_auto_page_break(True, margin=15)

        # 注册中文字体
        self.add_font("Bold", "", FONT_BOLD)
        self.add_font("Regular", "", FONT_REGULAR)
        self.add_font("Mono", "", FONT_MONO)

        # 中文排版常用字号（pt）
        self.SZ_TITLE = 18
        self.SZ_H1 = 14
        self.SZ_H2 = 12
        self.SZ_BODY = 10
        self.SZ_SMALL = 8

        # 行高倍数
        self.LH_BODY = 5.5
        self.LH_TIGHT = 4.5
        self.LH_TABLE = 7.0

    # ── helpers ─────────────────────────────────────────────────────

    def _is_bullet(self, line: str) -> bool:
        return bool(re.match(r"^\s*[-•]\s", line))

    def _is_numbered(self, line: str) -> bool:
        return bool(re.match(r"^\s*\d+[\.\、)]\s", line))

    def _escape(self, text: str) -> str:
        """移除 markdown 标记和 emoji，保留纯文本"""
        # 移除加粗标记
        text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
        # 移除代码标记
        text = re.sub(r"`([^`]+)`", r"\1", text)
        # 移除链接 [text](url)
        text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
        # 移除 emoji 和特殊符号（保留中文标点和常用符号）
        text = re.sub(r'[\U0001F300-\U0001F9FF\u2600-\u27BF\uFE00-\uFEFF\U0001FA00-\U0001FAFF]', '', text)
        return text

    def _parse_table(self, line: str) -> list:
        """解析 markdown 表格行，返回单元格列表"""
        cells = [c.strip() for c in line.strip("|").split("|")]
        return cells

    def _is_separator_row(self, line: str) -> bool:
        return bool(re.match(r"^\|[\s\-:|]+\|$", line))

    # ── 绘制方法 ─────────────────────────────────────────────────────

    def draw_title(self, text: str):
        """绘制一级标题（居中大号）"""
        self.ln(4)
        self.set_font("Bold", "", self.SZ_TITLE)
        text = self._escape(text).lstrip("#").strip()
        self.cell(0, 12, text, new_x="LMARGIN", new_y="NEXT", align="C")
        self.ln(2)

    def draw_meta(self, text: str):
        """绘制报告元信息（灰色小字居中）"""
        self.set_font("Mono", "", self.SZ_SMALL)
        self.set_text_color(120, 120, 120)
        text = self._escape(text).lstrip(">").strip()
        self.multi_cell(0, self.LH_TIGHT, text, align="C")
        self.set_text_color(0, 0, 0)
        self.ln(2)

    def draw_separator(self):
        """绘制分隔线"""
        self.set_draw_color(180, 180, 180)
        y = self.get_y()
        self.line(15, y, self.w - 15, y)
        self.ln(4)

    def draw_h1(self, text: str):
        """绘制二级标题 (## 开头)"""
        self.ln(2)
        self.set_font("Bold", "", self.SZ_H1)
        text = self._escape(text)
        text = re.sub(r"^#+\s*", "", text)
        self.cell(0, 8, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def draw_h2(self, text: str):
        """绘制三级标题 (### 开头)"""
        self.ln(1)
        self.set_font("Bold", "", self.SZ_H2)
        text = self._escape(text)
        text = re.sub(r"^#+\s*", "", text)
        self.cell(0, 7, text, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def draw_paragraph(self, text: str):
        """绘制普通段落"""
        if not text.strip():
            self.ln(1)
            return
        self.set_font("Regular", "", self.SZ_BODY)
        text = self._escape(text)
        self.multi_cell(0, self.LH_BODY, text, align="L")

    def draw_quote(self, text: str):
        """绘制引用块（灰色背景 + 楷体）"""
        self.set_fill_color(245, 245, 245)
        self.set_text_color(80, 80, 80)
        self.set_font("Mono", "", self.SZ_BODY)
        text = self._escape(text).lstrip(">").strip()
        x0 = self.get_x()
        self.set_x(x0 + 3)
        self.multi_cell(self.w - 36, self.LH_BODY, text, fill=True)
        self.set_text_color(0, 0, 0)
        self.ln(1)

    def draw_bullet(self, text: str, indent: int = 0):
        """绘制列表项"""
        self.set_font("Regular", "", self.SZ_BODY)
        text = self._escape(text)
        text = re.sub(r"^\s*[-•]\s*", "• ", text)
        text = re.sub(r"^\s*\d+[\.\、)]\s*", "", text)
        x0 = self.get_x()
        self.set_x(x0 + 5 + indent)
        self.multi_cell(self.w - 20 - indent, self.LH_BODY, text, align="L")

    def draw_table(self, rows: list[list[str]], col_widths: list[int] | None = None):
        """绘制表格"""
        if not rows:
            return

        avail = self.w - 20  # 可用宽度
        ncols = len(rows[0])

        if col_widths is None:
            col_widths = [avail / ncols] * ncols
        else:
            # 按比例缩放
            total = sum(col_widths)
            col_widths = [w * avail / total for w in col_widths]

        self.ln(1)

        for i, row in enumerate(rows):
            # 计算该行所需的最大行高
            cell_texts = []
            max_lines = 1
            for j, cell in enumerate(row):
                clean = self._escape(cell)
                # 计算需要多少行
                char_width = self.get_string_width("测")  # 近似中文字符宽度
                if char_width > 0:
                    chars_per_line = max(1, int((col_widths[j] - 2) / char_width))
                else:
                    chars_per_line = max(1, int(col_widths[j] / 3))
                lines = []
                for paragraph in clean.split("\n"):
                    if paragraph.strip():
                        wrapped = textwrap.wrap(paragraph, width=chars_per_line)
                        if not wrapped:
                            wrapped = [""]
                        lines.extend(wrapped)
                if not lines:
                    lines = [""]
                cell_texts.append(lines)
                max_lines = max(max_lines, len(lines))

            row_height = max(self.LH_TABLE, max_lines * self.LH_BODY + 1)

            # 检查分页
            if self.get_y() + row_height > self.h - 25:
                self.add_page()

            # 背景色
            if i == 0:
                self.set_fill_color(220, 220, 220)
                self.set_font("Bold", "", self.SZ_SMALL)
            else:
                if i % 2 == 0:
                    self.set_fill_color(248, 248, 248)
                else:
                    self.set_fill_color(255, 255, 255)
                self.set_font("Regular", "", self.SZ_SMALL)

            x_start = self.get_x()
            y_start = self.get_y()

            # 绘制单元格背景
            for j in range(ncols):
                x_pos = x_start + sum(col_widths[:j])
                self.set_xy(x_pos, y_start)
                self.cell(col_widths[j], row_height, "", fill=True, border=0)

            # 绘制文字
            for j, lines in enumerate(cell_texts):
                x_pos = x_start + sum(col_widths[:j]) + 1
                for li, line in enumerate(lines):
                    self.set_xy(x_pos, y_start + 1 + li * self.LH_BODY)
                    if i == 0:
                        self.set_font("Bold", "", self.SZ_SMALL)
                    else:
                        self.set_font("Regular", "", self.SZ_SMALL)
                    self.cell(col_widths[j] - 2, self.LH_BODY, line, align="L")

            # 绘制边框
            y_end = y_start + row_height
            x_end = x_start + sum(col_widths)
            self.set_draw_color(200, 200, 200)
            self.line(x_start, y_start, x_end, y_start)  # top
            self.line(x_start, y_end, x_end, y_end)      # bottom
            for j in range(ncols + 1):
                xx = x_start + sum(col_widths[:j])
                self.line(xx, y_start, xx, y_end)        # vertical

            self.set_xy(x_start, y_end)
            self.set_text_color(0, 0, 0)

        self.ln(3)

    # ── 分段解析 ─────────────────────────────────────────────────────

    def render_markdown(self, md_text: str):
        """解析并渲染 markdown 文本为 PDF"""
        lines = md_text.split("\n")

        # 表格解析状态
        table_rows = []
        in_table = False

        # 跳过空行处理
        i = 0
        while i < len(lines):
            line = lines[i]

            # 表格结束判断
            if in_table and not line.strip().startswith("|"):
                self.draw_table(table_rows)
                table_rows = []
                in_table = False

            # 空行
            if not line.strip():
                if in_table:
                    # 表格内的空行跳过
                    pass
                else:
                    self.ln(1)
                i += 1
                continue

            # 引用块 (blockquote)
            if line.strip().startswith(">"):
                quote_lines = []
                while i < len(lines) and lines[i].strip().startswith(">"):
                    quote_lines.append(lines[i].strip())
                    i += 1
                self.draw_quote(" ".join(quote_lines))
                continue

            # 表格行
            if line.strip().startswith("|"):
                if self._is_separator_row(line):
                    i += 1
                    continue
                if not in_table:
                    in_table = True
                    table_rows = []
                table_rows.append(self._parse_table(line))
                i += 1
                continue

            # 分隔线 ---
            if re.match(r"^[\-]{3,}$", line.strip()):
                self.draw_separator()
                i += 1
                continue

            # 标题
            if line.strip().startswith("# "):
                self.draw_title(line)
                i += 1
                continue
            if line.strip().startswith("## "):
                self.draw_h1(line)
                i += 1
                continue
            if line.strip().startswith("### "):
                self.draw_h2(line)
                i += 1
                continue

            # 列表项
            if self._is_bullet(line) or self._is_numbered(line):
                self.draw_bullet(line)
                i += 1
                continue

            # 普通段落
            self.draw_paragraph(line)
            i += 1

        # 剩余表格
        if in_table and table_rows:
            self.draw_table(table_rows)


def main():
    if len(sys.argv) != 3:
        print("用法: python generate_pdf.py <markdown_file> <output_pdf>", file=sys.stderr)
        print("示例: python generate_pdf.py report.md 离职处理报告-张三.pdf", file=sys.stderr)
        sys.exit(1)

    md_path = sys.argv[1]
    pdf_path = sys.argv[2]

    if not os.path.exists(md_path):
        print(f"[错误] 找不到文件: {md_path}", file=sys.stderr)
        sys.exit(1)

    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()

    pdf = HRReportPDF()
    pdf.add_page()
    pdf.render_markdown(md_text)

    # 确保输出目录存在
    os.makedirs(os.path.dirname(os.path.abspath(pdf_path)) or ".", exist_ok=True)
    pdf.output(pdf_path)
    print(f"[完成] PDF 已生成: {pdf_path}")


if __name__ == "__main__":
    main()
