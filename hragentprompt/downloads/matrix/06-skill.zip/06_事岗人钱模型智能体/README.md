# 事—岗—人—钱模型智能体

以战略任务为起点，贯通岗位设置、人才配置、绩效责任与薪酬激励。

本包为平台无关的Markdown Skill包，可用于Claude Code、OpenCode、WorkBuddy或企业内部智能体平台。不同平台的安装目录、触发描述和工具调用方式可能不同，可保留核心提示词和工作流后做适配。

## 目录

- `SKILL.md`：Skill主定义；
- `prompts/`：系统、澄清、分析和交付提示词；
- `templates/`：输入与输出模板；
- `examples/`：示例输入与示例输出；
- `tests/`：测试用例与验收标准；
- `schemas/`：结构化输入输出Schema；
- `manifest.json`：版本与文件清单。
