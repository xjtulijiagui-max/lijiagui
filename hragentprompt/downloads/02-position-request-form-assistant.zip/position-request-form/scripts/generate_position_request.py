#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
岗位需求申请表 Word 文档生成器

根据岗位信息生成标准格式的 Word 文档。
用法: python generate_position_request.py --output <输出路径>
输入数据通过 stdin 传入 JSON 格式的岗位信息。
"""

import json
import sys
import argparse
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn


def set_cell_text(cell, text, bold=False, font_size=10, font_name='宋体'):
    """设置单元格文本样式"""
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(str(text))
    run.bold = bold
    run.font.size = Pt(font_size)
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)


def set_table_style(table):
    """设置表格样式"""
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_before = Pt(2)
                paragraph.paragraph_format.space_after = Pt(2)


def generate_position_request(data, output_path):
    """生成岗位需求申请表 Word 文档"""
    doc = Document()

    # 设置默认字体
    style = doc.styles['Normal']
    font = style.font
    font.name = '宋体'
    font.size = Pt(10)
    font._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

    # ============ 标题 ============
    title = doc.add_heading('岗位需求申请表', level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        run.font.size = Pt(18)
        run.font.color.rgb = RGBColor(0, 0, 0)

    # ============ 一、岗位基本信息 ============
    doc.add_heading('一、岗位基本信息', level=2)

    basic_info = data.get('basic_info', {})
    info_table = doc.add_table(rows=8, cols=2, style='Table Grid')
    set_table_style(info_table)

    info_fields = [
        ('所属层级', basic_info.get('level', '')),
        ('部门名称', basic_info.get('department', '')),
        ('岗位名称', basic_info.get('position', '')),
        ('岗位编号', basic_info.get('position_code', '')),
        ('岗位类别', basic_info.get('position_type', '')),
        ('直接上级', basic_info.get('superior', '')),
        ('直接下级', basic_info.get('subordinate', '')),
        ('编制人数', basic_info.get('staffing', '')),
    ]

    for i, (field, value) in enumerate(info_fields):
        set_cell_text(info_table.rows[i].cells[0], field, bold=True, font_size=10)
        # 值单元格靠左
        cell = info_table.rows[i].cells[1]
        cell.text = str(value)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:
            run.font.size = Pt(10)
            run.font.name = '宋体'

    # ============ 二、主要职责 ============
    doc.add_heading('二、主要职责', level=2)

    responsibilities = data.get('responsibilities', [])
    if responsibilities:
        resp_table = doc.add_table(rows=len(responsibilities) + 1, cols=3, style='Table Grid')
        set_table_style(resp_table)

        # 表头
        set_cell_text(resp_table.rows[0].cells[0], '职责模块', bold=True)
        set_cell_text(resp_table.rows[0].cells[1], '具体职责', bold=True)
        set_cell_text(resp_table.rows[0].cells[2], '权重(%)', bold=True)

        for i, resp in enumerate(responsibilities):
            set_cell_text(resp_table.rows[i + 1].cells[0], resp.get('module', ''), font_size=10)
            # 具体职责左对齐
            cell = resp_table.rows[i + 1].cells[1]
            cell.text = resp.get('detail', '')
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            for run in p.runs:
                run.font.size = Pt(10)
                run.font.name = '宋体'
            set_cell_text(resp_table.rows[i + 1].cells[2], resp.get('weight', ''), font_size=10)

    # ============ 三、绩效指标 ============
    doc.add_heading('三、绩效指标', level=2)

    kpis = data.get('kpis', [])
    if kpis:
        kpi_table = doc.add_table(rows=len(kpis) + 1, cols=3, style='Table Grid')
        set_table_style(kpi_table)

        set_cell_text(kpi_table.rows[0].cells[0], '职责模块', bold=True)
        set_cell_text(kpi_table.rows[0].cells[1], 'KPI指标', bold=True)
        set_cell_text(kpi_table.rows[0].cells[2], '考核标准', bold=True)

        for i, kpi in enumerate(kpis):
            set_cell_text(kpi_table.rows[i + 1].cells[0], kpi.get('module', ''), font_size=10)
            # KPI和考核标准左对齐
            for col_idx, key in enumerate(['kpi_name', 'standard']):
                cell = kpi_table.rows[i + 1].cells[col_idx + 1]
                cell.text = kpi.get(key, '')
                p = cell.paragraphs[0]
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.size = Pt(10)
                    run.font.name = '宋体'

    # ============ 四、任职资格 ============
    doc.add_heading('四、任职资格', level=2)

    qualifications = data.get('qualifications', {})
    qual_table = doc.add_table(rows=6, cols=2, style='Table Grid')
    set_table_style(qual_table)

    qual_fields = [
        ('学历要求', qualifications.get('education', '')),
        ('工作经验', qualifications.get('experience', '')),
        ('专业知识', qualifications.get('knowledge', '')),
        ('核心技能', qualifications.get('skills', '')),
        ('能力素质', qualifications.get('competency', '')),
        ('证书/资质', qualifications.get('certificates', '')),
    ]

    for i, (field, value) in enumerate(qual_fields):
        set_cell_text(qual_table.rows[i].cells[0], field, bold=True, font_size=10)
        cell = qual_table.rows[i].cells[1]
        cell.text = str(value)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:
            run.font.size = Pt(10)
            run.font.name = '宋体'

    # ============ 五、协作关系 ============
    doc.add_heading('五、协作关系', level=2)

    collaborations = data.get('collaborations', [])
    if collaborations:
        collab_table = doc.add_table(rows=len(collaborations) + 1, cols=3, style='Table Grid')
        set_table_style(collab_table)

        set_cell_text(collab_table.rows[0].cells[0], '类型', bold=True)
        set_cell_text(collab_table.rows[0].cells[1], '对象', bold=True)
        set_cell_text(collab_table.rows[0].cells[2], '协作内容', bold=True)

        for i, collab in enumerate(collaborations):
            set_cell_text(collab_table.rows[i + 1].cells[0], collab.get('type', ''), font_size=10)
            set_cell_text(collab_table.rows[i + 1].cells[1], collab.get('target', ''), font_size=10)
            # 协作内容左对齐
            cell = collab_table.rows[i + 1].cells[2]
            cell.text = collab.get('content', '')
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            for run in p.runs:
                run.font.size = Pt(10)
                run.font.name = '宋体'

    # ============ 六、工作条件 ============
    doc.add_heading('六、工作条件', level=2)

    work_conditions = data.get('work_conditions', {})
    cond_table = doc.add_table(rows=3, cols=2, style='Table Grid')
    set_table_style(cond_table)

    cond_fields = [
        ('工作地点', work_conditions.get('location', '')),
        ('工作时间', work_conditions.get('schedule', '')),
        ('特殊条件', work_conditions.get('special', '')),
    ]

    for i, (field, value) in enumerate(cond_fields):
        set_cell_text(cond_table.rows[i].cells[0], field, bold=True, font_size=10)
        cell = cond_table.rows[i].cells[1]
        cell.text = str(value)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:
            run.font.size = Pt(10)
            run.font.name = '宋体'

    # ============ 七、版本变更说明 ============
    doc.add_heading('七、版本变更说明', level=2)

    changes = data.get('changes', {})
    change_items = [
        ('新增内容：', changes.get('added', '')),
        ('删除内容：', changes.get('removed', '')),
        ('调整内容：', changes.get('modified', '')),
        ('待确认问题：', changes.get('pending', '')),
    ]

    for label, content in change_items:
        p = doc.add_paragraph()
        run_label = p.add_run(label)
        run_label.bold = True
        run_label.font.size = Pt(10)
        run_label.font.name = '宋体'
        run_content = p.add_run(str(content))
        run_content.font.size = Pt(10)
        run_content.font.name = '宋体'

    # 保存文档
    doc.save(output_path)
    print(f'文档已生成：{output_path}')
    return output_path


def main():
    parser = argparse.ArgumentParser(description='生成岗位需求申请表 Word 文档')
    parser.add_argument('--output', '-o', required=True, help='输出文件路径')
    parser.add_argument('--input', '-i', required=False, help='输入JSON文件路径（如未提供则从stdin读取）')
    args = parser.parse_args()

    if args.input:
        with open(args.input, 'r', encoding='utf-8') as f:
            input_data = f.read()
    else:
        input_data = sys.stdin.read()
    data = json.loads(input_data)

    generate_position_request(data, args.output)


if __name__ == '__main__':
    main()