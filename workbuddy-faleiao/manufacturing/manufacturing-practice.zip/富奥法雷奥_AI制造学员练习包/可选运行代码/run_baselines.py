"""Classroom baselines. All model metrics refer ONLY to generated teaching data.
Usage: python run_baselines.py --root /path/to/富奥法雷奥_AI制造学员练习包
Requires numpy, scikit-learn, pillow. No cloud calls and no connection to production control.
"""
from __future__ import annotations
import argparse,csv,json,pathlib,datetime,collections
import numpy as np
from PIL import Image
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier,RandomForestClassifier
from sklearn.metrics import precision_score,recall_score,average_precision_score,roc_auc_score,confusion_matrix,fbeta_score

def read(path):
 if not path.exists():raise FileNotFoundError(f'缺少输入文件: {path}')
 with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save(path,rows):
 if not rows:return
 with path.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def metrics(y,p,threshold):
 pred=np.asarray(p)>=threshold;y=np.asarray(y,dtype=int)
 return {'n':len(y),'positive_count':int(y.sum()),'prevalence':float(y.mean()),'threshold':float(threshold),'precision':float(precision_score(y,pred,zero_division=0)),'recall':float(recall_score(y,pred,zero_division=0)),'average_precision':float(average_precision_score(y,p)),'roc_auc':float(roc_auc_score(y,p)) if len(set(y))==2 else None,'alert_rate':float(pred.mean()),'confusion_matrix_tn_fp_fn_tp':list(map(int,confusion_matrix(y,pred,labels=[0,1]).ravel()))}
def select_threshold(y,p):
 # Illustrative policy: maximize F2 on validation only; factory thresholds need agreed loss/quality limits.
 ts=np.unique(np.r_[np.linspace(.01,.99,80),np.quantile(p,np.linspace(0,1,100))])
 return float(max(ts,key=lambda t:(fbeta_score(y,np.asarray(p)>=t,beta=2,zero_division=0),t)))
def matrix(rows,features):return np.array([[float(r[k]) if r[k]!='' else np.nan for k in features] for r in rows],dtype=float)
def run(root):
 d=root/'数据集';o=root/'讲师参考'/'基线实跑结果';o.mkdir(parents=True,exist_ok=True);results={'scope':'SIMULATED_ONLY_NOT_FACTORY_EVIDENCE','threshold_selection':'仅用validation；测试集不参与选模调参；数值是本次程序实跑，不是客户模型效果。'}
 p=read(d/'S01_印刷前工艺参数.csv');q=read(d/'S02_SPI检测与独立复核结果.csv');qm={r['board_id']:r for r in q};assert len(qm)==len(q)
 joined=[{**r,**qm[r['board_id']]} for r in p];train=np.array([r['suggested_split']=='train' for r in joined]);val=np.array([r['suggested_split']=='validation' for r in joined]);test=np.array([r['suggested_split']=='test' for r in joined]); y=np.array([int(r['qa_confirmed_ng']) for r in joined])
 for a,b in [(train,val),(train,test),(val,test)]:assert not(set(joined[i]['material_lot_id'] for i in np.where(a)[0])&set(joined[i]['material_lot_id'] for i in np.where(b)[0]))
 pref=['print_speed_mm_s','squeegee_pressure_N','separation_speed_mm_s','paste_open_age_min','prints_since_clean','fixture_offset_mm'];postf=pref+['spi_volume_ratio_mean','spi_volume_ratio_std','low_volume_pad_count','high_volume_pad_count','reference_board_bias_ratio']
 preds={};qualityresults=[]
 for name,features in [('印刷前风险预测',pref),('检测后复判分流',postf)]:
  x=matrix(joined,features)
  for alg,model in [('逻辑回归',make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),LogisticRegression(max_iter=2000,class_weight='balanced',C=.3))),('梯度提升树',make_pipeline(SimpleImputer(strategy='median'),HistGradientBoostingClassifier(max_iter=100,max_leaf_nodes=9,l2_regularization=4,learning_rate=.06,random_state=42)))]:
   model.fit(x[train],y[train]);pv=model.predict_proba(x[val])[:,1];th=select_threshold(y[val],pv);pt=model.predict_proba(x[test])[:,1]
   record={'task':name,'algorithm':alg,'features':features,'validation':metrics(y[val],pv,th),'test':metrics(y[test],pt,th)};qualityresults.append(record)
   preds[(name,alg)]=(pv,pt,th)
 # Model selection uses validation AP; never choose by test performance.
 chosen={}
 for name in ['印刷前风险预测','检测后复判分流']:
  winner=max([r for r in qualityresults if r['task']==name],key=lambda r:r['validation']['average_precision']);chosen[name]=winner['algorithm']
 testrows=[]
 for k,i in enumerate(np.where(test)[0]):
  pre=preds[('印刷前风险预测',chosen['印刷前风险预测'])];post=preds[('检测后复判分流',chosen['检测后复判分流'])]
  testrows.append({'board_id':joined[i]['board_id'],'line_id':joined[i]['line_id'],'print_time':joined[i]['print_time'],'gold_ng':int(y[i]),'pre_risk_score':round(float(pre[1][k]),6),'pre_threshold':pre[2],'post_risk_score':round(float(post[1][k]),6),'post_threshold':post[2],'machine_alarm':joined[i]['machine_alarm'],'data_origin':'MODEL_OUTPUT_ON_SIMULATION'})
 save(o/'M01_质量模型_测试集预测.csv',testrows);results['quality_models']=qualityresults;results['quality_selected_by_validation']=chosen
 # Equipment future-event prediction: observations and future labels remain in separate files.
 t=read(d/'S03_打螺丝运行反馈_5分钟窗口.csv');lab=read(d/'S05_未来30分钟故障标签_勿作特征.csv');lm={r['sample_id']:r for r in lab};er=[{**r,**lm[r['sample_id']]} for r in t if lm[r['sample_id']]['label_mature']=='1'];ef=['torque_std_Nm','angle_std_deg','feed_retry_ratio','cycle_p95_s','servo_current_mean_A','minutes_since_maintenance'];ex=matrix(er,ef);ey=np.array([int(r['failure_next_30min']) for r in er]);etr=np.array([r['suggested_split']=='train' for r in er]);ev=np.array([r['suggested_split']=='validation' for r in er]);et=np.array([r['suggested_split']=='test' for r in er])
 model=RandomForestClassifier(n_estimators=120,max_depth=7,min_samples_leaf=6,class_weight='balanced_subsample',random_state=42,n_jobs=2);model.fit(ex[etr],ey[etr]);epv=model.predict_proba(ex[ev])[:,1];eth=select_threshold(ey[ev],epv);ept=model.predict_proba(ex[et])[:,1]
 eout=[]
 for score,i in zip(ept,np.where(et)[0]):
  r=er[i];eout.append({'sample_id':r['sample_id'],'window_end':r['window_end'],'line_id':r['line_id'],'equipment_id':r['equipment_id'],'gold_failure_next_30min':int(ey[i]),'risk_score':round(float(score),6),'threshold':eth,'raw_alert':int(score>=eth),'linked_failure_id_for_evaluation':r['next_failure_id_for_evaluation'],'lead_minutes_for_evaluation':r['lead_minutes_for_evaluation'],'data_origin':'MODEL_OUTPUT_ON_SIMULATION'})
 save(o/'M02_设备模型_测试集预测.csv',eout)
 # One alert episode per equipment per 30 minutes; event recall uses actual dispatched episodes.
 last={};episodes=[]
 for r in sorted(eout,key=lambda r:(r['window_end'],r['equipment_id'])):
  dt=datetime.datetime.fromisoformat(r['window_end']);eq=r['equipment_id']
  if r['raw_alert'] and (eq not in last or (dt-last[eq]).total_seconds()>=1800):episodes.append(r);last[eq]=dt
 faults=read(d/'S04_故障与维护金标准.csv');testfaults=[f for f in faults if f['failure_start'][:10]>='2026-09-11'];hit={r['linked_failure_id_for_evaluation'] for r in episodes if r['linked_failure_id_for_evaluation']};false=[r for r in episodes if not r['linked_failure_id_for_evaluation']];leads=[float(r['lead_minutes_for_evaluation']) for r in episodes if r['linked_failure_id_for_evaluation']]
 # Denominator is exposure in the scored/eligible windows, not all equipment elapsed time.
 hours=sum(float(er[i]['operating_exposure_min']) for i in np.where(et)[0])/60
 results['equipment']={'features':ef,'validation':metrics(ey[ev],epv,eth),'test':metrics(ey[et],ept,eth),'test_failure_events':len(testfaults),'detected_events_after_cooldown':len(hit),'event_recall_after_cooldown':len(hit)/len(testfaults),'median_lead_minutes':float(np.median(leads)) if leads else None,'false_alert_episodes':len(false),'scored_operating_hours':hours,'false_alerts_per_100_scored_operating_hours':len(false)/hours*100,'cooldown_minutes':30,'limits':'6台模拟工站48个模拟故障；未知故障仅在测试集；不适合估计真实寿命或客户准确率。'}
 save(o/'M03_设备告警去重事件.csv',episodes)
 # Vision baseline uses IMAGE PIXELS only. Filename, labels, masks, split and lighting annotations are not features.
 vroot=root/'视觉样本';vm=read(vroot/'V01_视觉样本清单.csv');vfeatures=[]
 for r in vm:
  im=np.asarray(Image.open(vroot/r['relative_image_path']).convert('L').resize((16,16)),dtype=float)/255.
  vfeatures.append(im.ravel())
 vx=np.array(vfeatures);vy=np.array([r['gold_defect_type'] for r in vm]);vtr=np.array([r['split']=='train' for r in vm]);vv=np.array([r['split']=='validation' for r in vm]);vt=np.array([r['split']=='test' for r in vm])
 groups={s:{r['board_group'] for r in vm if r['split']==s} for s in ['train','validation','test']};assert not(groups['train']&groups['test'] or groups['train']&groups['validation'] or groups['validation']&groups['test'])
 assert 'bridge_unknown' not in vy[vtr] and 'bridge_unknown' not in vy[vv]
 clf=make_pipeline(StandardScaler(),LogisticRegression(C=.2,max_iter=2000));clf.fit(vx[vtr],vy[vtr]);vp=clf.predict_proba(vx);vc=clf.classes_[vp.argmax(1)];conf=vp.max(1)
 # Normal-only nearest-neighbour distance is a transparent anomaly baseline, NOT a production PatchCore model.
 normal=vx[vtr&(vy=='normal')];dist=np.sqrt(((vx[:,None,:]-normal[None,:,:])**2).mean(2)).min(1)
 ath=float(np.quantile(dist[vv&(vy=='normal')],.95));review=(vc!='normal')|(dist>ath)|(conf<.7)
 vang=(vy!='normal').astype(int);vr=[]
 for i in np.where(vt)[0]:
  r=vm[i];vr.append({'image_id':r['image_id'],'board_group':r['board_group'],'gold_defect_type':r['gold_defect_type'],'gold_is_ng':int(vang[i]),'known_classifier_label':str(vc[i]),'known_classifier_confidence':round(float(conf[i]),6),'anomaly_distance':round(float(dist[i]),6),'anomaly_threshold':ath,'suggest_review':int(review[i]),'lighting_shift':int(r['lighting_shift']),'data_origin':'MODEL_OUTPUT_ON_SYNTHETIC_PIXELS'})
 save(o/'M04_视觉模型_测试集预测.csv',vr)
 def subgroup(mask):
  return {'n':int(mask.sum()),'review_rate':float(review[mask].mean()) if mask.any() else None}
 results['vision']={'method':'16x16像素逻辑回归 + 仅正常训练样本的最近邻异常距离；仅教学基线，不是工业视觉验收','anomaly_threshold_from_validation_normal_95pct':ath,'train_images':int(vtr.sum()),'validation_images':int(vv.sum()),'test_images':int(vt.sum()),'test':metrics(vang[vt],review[vt].astype(float),.5),'unknown_bridge_test':subgroup(vt&(vy=='bridge_unknown')),'normal_lighting_shift_test':subgroup(vt&np.array([r['lighting_shift']=='1' for r in vm])),'normal_no_shift_test':subgroup(vt&(vy=='normal')&np.array([r['lighting_shift']=='0' for r in vm])),'limits':'合成图像520张，仅能练流程；金标准mask为粗粒度演示，非精细分割标签；不得以本成绩替代真实相机验证。'}
 (o/'baseline_metrics.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);args=ap.parse_args();run(args.root.resolve())
