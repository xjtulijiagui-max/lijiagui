# 协议规则解析与分润返佣校验

本ZIP为银盛支付WorkBuddy培训用Skill。核心文件为`SKILL.md`。按平台当前技能导入方式上传；若要求目录导入，则解压后选择包含`SKILL.md`的目录。
