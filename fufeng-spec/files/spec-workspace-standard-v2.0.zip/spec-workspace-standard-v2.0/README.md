# Spec Workspace 初始化标准 v2.0

用途：把一份 PRD / IPO 需求定义书，转成**可继续开发的 Workspace 初始化输入包**。
本包只解决第一阶段：目录、规格、候选基线、缺口清单。**不写业务代码，不装业务依赖，不发布站点。**

## 一分钟上手

1. 解压本包，得到 `spec-workspace-standard-v2.0/`。
2. 在 AI 工具里同时提供两份材料：你的 PRD / IPO 文件 + 本包。
3. 复制下面这段开场指令：

```text
请把我提供的 PRD（或 IPO）与《Spec Workspace 初始化标准 v2.0》一起处理，
生成本项目专属的 Workspace 初始化输入包。
先读取标准包的 AGENTS.md 和 .agents/skills/spec-workspace-init/SKILL.md，
再按需读取 references/ 与 templates/。此次模式为 new，只做初始化。
```

4. 拿到 `outputs/<project_id>_Workspace_v<版本>_r<修订>.zip` 与同名 `.html`。
5. 只读 HTML 里的「已初始化 / 关键缺口 / 下一步确认」三节，再决定是否进入开发。

## 目录

| 路径 | 作用 |
|---|---|
| `AGENTS.md` | 进入本包必须遵守的硬约定（优先级最高） |
| `.agents/skills/spec-workspace-init/SKILL.md` | 初始化四阶段流程与判定标准 |
| `references/spec-contract.md` | 十份规格文件各写什么、最少要有哪些证据 |
| `references/traceability.md` | 需求/规则/用例编号规则与追踪矩阵 |
| `references/validation-checklist.md` | 结构校验清单与缺口分级 |
| `references/modes.md` | new / iterate / review 三模式差异 |
| `templates/workspace/` | 输出目录契约（含可自足使用的 Skill 与打包工具副本） |
| `tools/workspace_pack.py` | 结构校验 + 打包 ZIP/HTML，只需 Python 3.9+ 标准库 |
| `examples/` | 课堂示例，仅示范格式，**不是**你的需求 |

## 版本

- 标准版本：v2.0
- 输出包状态：`BASELINE_DRAFT`（候选基线，未批准）
- 业务测试：`NOT_RUN`（本阶段不执行任何业务测试）
