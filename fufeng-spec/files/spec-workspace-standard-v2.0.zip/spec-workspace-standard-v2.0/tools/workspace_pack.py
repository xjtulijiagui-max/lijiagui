#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""workspace_pack.py · Spec Workspace 结构校验与打包工具

只依赖 Python 3.9+ 标准库，输出包脱离标准包后仍可使用。

用法：
  python tools/workspace_pack.py --validate <workspace_dir>
  python tools/workspace_pack.py --pack <workspace_dir> --project-id hjt-lab --version 1.0.0 --rev 1 --out outputs/
  python tools/workspace_pack.py --pack . --standard .. --selfcheck

退出码：0 全部通过 / 1 存在 FAIL / 2 参数或路径错误
"""

import argparse
import datetime as dt
import html
import os
import re
import shutil
import sys
import zipfile
from pathlib import Path

SPEC_FILES = [
    "01-business.md", "02-ipo.md", "03-sop.md", "04-rules.md", "05-data.md",
    "06-architecture.md", "07-ui.md", "08-security.md", "09-acceptance.md",
    "10-traceability.md",
]
REQUIRED_DIRS = ["specs", "decisions", "evidence"]
REQUIRED_FILES = ["WORKSPACE.md", "open-questions.md", "specs/10-traceability.md"]
SELF_FILES = [".agents/skills/spec-workspace-init/SKILL.md", "tools/workspace_pack.py"]

SECRET_PATTERNS = [
    r"password\s*=\s*\S+", r"BEGIN [A-Z ]*PRIVATE KEY", r"ghp_[A-Za-z0-9]{20,}",
    r"sk-[A-Za-z0-9]{20,}", r"AKIA[0-9A-Z]{16}",
]
LOCAL_PATH_PATTERNS = [r"C:\\\\Users\\\\", r"C:/Users/", r"/Users/[A-Za-z0-9._-]+/", r"D:\\\\"]
EXCLUDE_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".idea", ".vscode", "dist", "build"}
EXCLUDE_SUFFIX = {".pyc", ".log", ".tmp", ".zip", ".env"}
EXCLUDE_NAMES = {".env", ".DS_Store", "Thumbs.db"}


def read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def count(pattern: str, text: str) -> int:
    return len(re.findall(pattern, text))


def validate(root: Path) -> list:
    """返回 [(编号, 名称, PASS/FAIL/WARN, 明细)]"""
    r = []
    if not root.is_dir():
        return [(0, "路径", "FAIL", "目录不存在：%s" % root)]

    missing_dirs = [d for d in REQUIRED_DIRS if not (root / d).is_dir()]
    r.append((1, "目录完整", "PASS" if not missing_dirs else "FAIL",
              "缺失目录：" + "、".join(missing_dirs) if missing_dirs else "specs/decisions/evidence 齐全"))

    miss_spec = [s for s in SPEC_FILES if not (root / "specs" / s).is_file()]
    miss_req = [f for f in REQUIRED_FILES if not (root / f).is_file()]
    r.append((1, "契约文件", "PASS" if not miss_spec and not miss_req else "FAIL",
              "缺失：" + "、".join(miss_spec + miss_req) if (miss_spec or miss_req) else "十份规格与根文件齐全"))

    miss_self = [f for f in SELF_FILES if not (root / f).is_file()]
    r.append((2, "自足副本", "PASS" if not miss_self else "WARN",
              "缺少：" + "、".join(miss_self) if miss_self else "Skill 与打包工具已复制"))

    thin = []
    for s in SPEC_FILES:
        p = root / "specs" / s
        if not p.is_file():
            continue
        t = read(p)
        has_struct = ("|" in t) or bool(re.search(r"(REQ-|RULE-|I-\d|P-\d|AC-)", t))
        if len(t) < 400 or not has_struct:
            thin.append("%s(%d字)" % (s, len(t)))
    r.append((3, "无空规格", "PASS" if not thin else "FAIL",
              "内容不足：" + "、".join(thin) if thin else "十份规格均有实质结构与 400 字以上内容"))

    ws = read(root / "WORKSPACE.md")
    ok_state = "BASELINE_DRAFT" in ws
    r.append((4, "状态字段", "PASS" if ok_state else "FAIL",
              "init_state 未标 BASELINE_DRAFT" if not ok_state else "init_state: BASELINE_DRAFT"))

    ok_test = "NOT_RUN" in ws or (root / "evidence").is_dir()
    r.append((5, "测试状态", "PASS" if ok_test else "WARN",
              "未声明 business_tests: NOT_RUN" if not ok_test else "隐含或显式声明 NOT_RUN"))

    all_text = "\n".join(read(p) for p in root.rglob("*.md"))
    n_req = len(set(re.findall(r"REQ-[A-Z]{2,6}-\d{2,3}|REQ-\d{2,3}", all_text)))
    n_rule = len(set(re.findall(r"RULE-[A-Z]{2,6}-\d{2,3}|RULE-\d{2,3}", all_text)))
    n_ac = len(set(re.findall(r"AC-\d{2,3}", all_text)))
    ok_code = n_req >= 5 and n_rule >= 3 and n_ac >= 3
    r.append((6, "编号存在", "PASS" if ok_code else "WARN",
              "REQ=%d RULE=%d AC=%d（建议 ≥5/3/3）" % (n_req, n_rule, n_ac)))

    tr = read(root / "specs" / "10-traceability.md")
    rows = len([l for l in tr.splitlines() if l.strip().startswith("|") and "---" not in l and re.search(r"REQ-", l)])
    r.append((7, "追踪矩阵", "PASS" if rows >= max(n_req, 1) else "WARN",
              "矩阵数据行 %d，需求 %d" % (max(rows, 0), n_req)))

    oq = read(root / "open-questions.md")
    blocks = re.findall(r"Q-\d{2,3}[^\n]*", oq)
    graded = len(re.findall(r"BLOCKER|NON-BLOCKER|WATCH", oq))
    r.append((8, "缺口分级", "PASS" if graded >= max(len(blocks), 1) else "WARN",
              "问题 %d 条，分级标记 %d 处" % (len(blocks), graded)))

    vague = len(re.findall(r"来源不明|^\s*待补充\s*$", all_text, re.M))
    r.append((9, "来源标注", "PASS" if vague == 0 else "WARN", "可疑占位 %d 处" % vague))

    sec = [p for p in re.findall("|".join(SECRET_PATTERNS), all_text)]
    r.append((10, "无密钥", "PASS" if not sec else "FAIL",
              "命中高危串 %d 处" % len(sec) if sec else "未发现密钥类字符串"))

    paths = []
    for pat in LOCAL_PATH_PATTERNS:
        paths += re.findall(pat, all_text)
    r.append((11, "无本机路径", "PASS" if not paths else "FAIL",
              "命中本机绝对路径 %d 处" % len(paths) if paths else "未发现本机绝对路径"))

    m = re.search(r"semver:\s*([0-9][0-9.]*)", ws)
    r.append((12, "版本一致", "PASS" if m else "WARN",
              "WORKSPACE 版本 %s" % (m.group(1) if m else "未声明")))

    r.append((13, "产物成对", "WARN", "打包后由工具校验 ZIP/HTML 同名（此处仅提示）"))

    ex = root / "examples" / "README.md"
    if ex.is_file():
        ok_ex = "非需求" in read(ex)
        r.append((14, "示例隔离", "PASS" if ok_ex else "WARN",
                  "示例 README 已声明非需求" if ok_ex else "示例目录缺少‘非需求’声明"))
    else:
        r.append((14, "示例隔离", "PASS", "未包含示例目录"))
    return r


def print_result(rows: list) -> int:
    fails = [x for x in rows if x[2] == "FAIL"]
    print("=" * 72)
    print("Spec Workspace 结构校验")
    print("=" * 72)
    for no, name, state, detail in rows:
        print("[%-4s] %02d %-10s %s" % (state, no, name, detail))
    print("-" * 72)
    print("合计 %d 项：PASS %d / WARN %d / FAIL %d" % (
        len(rows), sum(1 for x in rows if x[2] == "PASS"),
        sum(1 for x in rows if x[2] == "WARN"), len(fails)))
    if fails:
        print("判定：不可交付或无证据交付 —— 先修复 FAIL 项")
        return 1
    print("判定：可交付候选包（状态 BASELINE_DRAFT，业务测试 NOT_RUN）")
    return 0


def iter_files(root: Path):
    for p in sorted(root.rglob("*")):
        if p.is_dir():
            continue
        parts = set(p.relative_to(root).parts)
        if parts & EXCLUDE_DIRS:
            continue
        if p.name in EXCLUDE_NAMES or p.suffix.lower() in EXCLUDE_SUFFIX:
            continue
        yield p


def gap_stats(root: Path):
    oq = read(root / "open-questions.md")
    return {
        "BLOCKER": len(re.findall(r"BLOCKER", oq)) - len(re.findall(r"NON-BLOCKER", oq)),
        "NON-BLOCKER": len(re.findall(r"NON-BLOCKER", oq)),
        "WATCH": len(re.findall(r"WATCH", oq)),
    }


def build_html(project_name, project_id, version, rev, files, rows, gaps) -> str:
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    file_rows = "\n".join(
        "<tr><td>%s</td><td>%s</td></tr>" % (html.escape(str(f)), f.stat().st_size) for f in files[:200]
    )
    check_rows = "\n".join(
        '<tr><td>%02d</td><td>%s</td><td class="s-%s">%s</td><td>%s</td></tr>'
        % (no, html.escape(name), state.lower(), state, html.escape(detail)) for no, name, state, detail in rows
    )
    return """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>%(name)s · Workspace 初始化摘要 %(ver)s_%(rev)s</title>
<style>
body{margin:0;background:#f5f7fa;color:#152232;font:15px/1.7 "Microsoft YaHei",sans-serif}
.in{max-width:920px;margin:auto;padding:32px 22px 48px}
h1{font-size:24px;margin:0 0 6px}h2{font-size:18px;margin:28px 0 10px}
.meta{color:#5f7085;font-size:13.5px}
.card{background:#fff;border:1px solid #e3e8ef;border-radius:12px;padding:20px 22px;margin-top:16px}
table{width:100%%;border-collapse:collapse;font-size:13.5px}
th,td{border-bottom:1px solid #eef1f5;padding:7px 8px;text-align:left;vertical-align:top}
th{background:#f7f9fc;font-weight:700}
.s-pass{color:#1a6b4a}.s-warn{color:#8a5b00}.s-fail{color:#b3261e}
.badge{display:inline-block;background:#0b2743;color:#fff;border-radius:6px;padding:3px 9px;font-size:12.5px;margin-right:6px}
.note{background:#fff8e8;border:1px solid #f0dcae;color:#8a5b00;border-radius:10px;padding:12px 14px;font-size:13.5px;margin-top:14px}
</style></head><body><div class="in">
<h1>%(name)s</h1>
<p class="meta"><span class="badge">BASELINE_DRAFT</span><span class="badge">business_tests: NOT_RUN</span>
project_id: %(pid)s · v%(ver)s_%(rev)s · 生成于 %(now)s</p>
<div class="note">本摘要只说明「初始化产出了什么」：候选基线未批准，业务测试未执行，未开发业务代码，未发布站点。</div>
<h2>一、缺口统计</h2><div class="card"><table><tr><th>级别</th><th>数量</th><th>处理</th></tr>
<tr><td>BLOCKER</td><td>%(b)d</td><td>进入开发前必须回答</td></tr>
<tr><td>NON-BLOCKER</td><td>%(nb)d</td><td>可带缺口交付，注明影响面</td></tr>
<tr><td>WATCH</td><td>%(w)d</td><td>下一阶段跟踪</td></tr></table></div>
<h2>二、结构校验</h2><div class="card"><table><tr><th>#</th><th>检查项</th><th>结果</th><th>明细</th></tr>%(checks)s</table></div>
<h2>三、包内文件</h2><div class="card"><table><tr><th>文件</th><th>字节</th></tr>%(files)s</table></div>
<h2>四、下一步</h2><div class="card"><ol>
<li>先读 <code>open-questions.md</code> 里的 BLOCKER，逐条回答。</li>
<li>确认 <code>specs/04-rules.md</code> 与 <code>specs/09-acceptance.md</code> 能否作为开发基线。</li>
<li>确认后才进入第二阶段：计划、TDD、评审、验收。</li></ol></div>
</div></body></html>""" % dict(
        name=html.escape(project_name), pid=html.escape(project_id), ver=version, rev=rev, now=now,
        b=gaps["BLOCKER"], nb=gaps["NON-BLOCKER"], w=gaps["WATCH"],
        checks=check_rows, files=file_rows,
    )


def guess_name(root: Path) -> str:
    m = re.search(r"project_name:\s*(.+)", read(root / "WORKSPACE.md"))
    return m.group(1).strip() if m else root.name


def pack(root: Path, project_id: str, version: str, rev: str, out: Path, standard: Path = None) -> int:
    rows = validate(root)
    code = print_result(rows)
    if any(x[2] == "FAIL" for x in rows):
        print("存在 FAIL 项，按标准不得打包。修复后重试，或显式加 --force-pack 并说明原因。")
        if "--force-pack" not in sys.argv:
            return 1

    if standard and standard.is_dir():
        for rel in SELF_FILES:
            src, dst = standard / rel, root / rel
            if src.is_file() and not dst.is_file():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                print("已复制自足文件：%s" % rel)

    out.mkdir(parents=True, exist_ok=True)
    base = "%s_Workspace_v%s_%s" % (project_id, version, rev)
    zip_path, html_path = out / (base + ".zip"), out / (base + ".html")
    files = list(iter_files(root))

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            info = zipfile.ZipInfo(str(Path(base) / f.relative_to(root)).replace(os.sep, "/"))
            info.date_time = (2026, 1, 1, 0, 0, 0)
            info.external_attr = 0o644 << 16
            z.writestr(info, f.read_bytes())

    gaps = gap_stats(root)
    html_path.write_text(build_html(guess_name(root), project_id, version, rev, files, rows, gaps), encoding="utf-8")

    pair_ok = zip_path.is_file() and html_path.is_file()
    print("-" * 72)
    print("ZIP  : %s (%d 文件, %.1f KB)" % (zip_path.name, len(files), zip_path.stat().st_size / 1024))
    print("HTML : %s (%.1f KB)" % (html_path.name, html_path.stat().st_size / 1024))
    print("成对 : %s" % ("PASS" if pair_ok else "FAIL"))
    return 0 if pair_ok else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="Spec Workspace 结构校验与打包")
    ap.add_argument("--validate", metavar="DIR", help="只做结构校验")
    ap.add_argument("--pack", metavar="DIR", help="校验并打包")
    ap.add_argument("--project-id", default="project")
    ap.add_argument("--version", default="1.0.0")
    ap.add_argument("--rev", default="r001")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--standard", default=None, help="标准包根目录，用于复制自足文件")
    ap.add_argument("--force-pack", action="store_true")
    a = ap.parse_args()

    if a.validate:
        return print_result(validate(Path(a.validate)))
    if a.pack:
        rev = a.rev if a.rev.startswith("r") else "r" + a.rev.zfill(3)
        return pack(Path(a.pack), a.project_id, a.version, rev, Path(a.out), Path(a.standard) if a.standard else None)
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
