# 结构校验清单

`tools/workspace_pack.py --validate` 会自动检查下表 1–14 项，并输出 PASS/FAIL 与明细。

| # | 检查项 | 通过标准 |
|---|---|---|
| 1 | 目录完整 | `specs/` 十份齐全；`decisions/`、`evidence/`、`open-questions.md`、`WORKSPACE.md` 存在 |
| 2 | 自足副本 | `.agents/skills/spec-workspace-init/SKILL.md` 与 `tools/workspace_pack.py` 已复制 |
| 3 | 无空规格 | 每份规格 ≥ 400 字符且含至少一个表格或编号条目 |
| 4 | 状态字段 | `WORKSPACE.md` 含 `init_state: BASELINE_DRAFT` |
| 5 | 测试状态 | 含 `business_tests: NOT_RUN`，或附实际执行证据路径 |
| 6 | 编号存在 | 至少 5 个 `REQ-`、3 个 `RULE-`、3 个 `AC-` |
| 7 | 追踪矩阵 | `10-traceability.md` 含表格，行数 ≥ REQ 数 |
| 8 | 缺口分级 | `open-questions.md` 每条含 BLOCKER / NON-BLOCKER / WATCH 之一 |
| 9 | 来源标注 | 抽样检查规格文件不含「来源不明」「待补充」独立成段 |
| 10 | 无密钥 | 不含 `password=`、`BEGIN PRIVATE KEY`、`ghp_`、`sk-` 等高危串 |
| 11 | 无本机路径 | 不含 `C:\Users\`、`/Users/`、`D:\` 等本机绝对路径 |
| 12 | 版本一致 | `WORKSPACE.md` 的版本与打包参数一致 |
| 13 | 产物成对 | 打包后 ZIP 与 HTML 同名同版本 |
| 14 | 示例隔离 | 若复制了 `examples/`，其 README 含「非需求」声明 |

## 判定等级

- **可交付候选**：1–14 全通过。
- **需补充**：存在 FAIL 但均为格式类，缺口已登记 → 可交付但首页必须标注「需补充项」。
- **不可交付**：出现密钥泄漏、本机路径、虚构证据、阻断项被默认值绕过。

## 缺口分级写法

```markdown
### Q-004 · 客户验收口径未提供
- 级别：BLOCKER
- 影响：AC-003 无法判定合格/不合格；规则 RULE-EXP-002 的阈值不可定
- 已尝试：核对 PRD 第 3 节、附件清单，未找到客户标准
- 需要谁回答：研发负责人（提供客户技术协议或内部判定标准）
- 不回答的后果：只能交付候选包，不能进入开发
```
