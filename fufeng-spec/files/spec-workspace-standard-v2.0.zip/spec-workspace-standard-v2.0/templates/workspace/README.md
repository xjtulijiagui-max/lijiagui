# 输出 Workspace 骨架（交付契约）

复制本目录为你项目的根目录，然后把每个文件里的「填写指引」替换成**本项目实质内容**。
保留文件名与编号规则；保留 `specs/` 十份，不得合并或删除。

## 复制后必须做的事

1. 改 `WORKSPACE.md`：项目名、`project_id`、版本、状态、本轮范围。
2. 按 `specs/01` → `specs/09` 顺序填，最后填 `specs/10-traceability.md`（它要引用前面所有编号）。
3. 把无法确定的问题写进 `open-questions.md`，逐条判 BLOCKER / NON-BLOCKER / WATCH。
4. 复制标准包的 `.agents/` 与 `tools/workspace_pack.py` 到本项目根目录，保证脱离标准包也能续作。
5. 跑 `python tools/workspace_pack.py --validate .`，通过后打包。

## 不要做的事

- 不要把 `README.md`（本文件）留在交付包里当说明页，替换成项目自己的说明或删除。
- 不要保留任何「填写指引」「示例」段落作为正式内容。
- 不要在规格里写「后续再定」而不登记到 `open-questions.md`。
