# WORKSPACE · <项目名>

```yaml
project_id: <英文小写连字符，例：hjt-lab-review>
project_name: <中文项目名>
init_state: BASELINE_DRAFT          # 本阶段固定，不得改成 APPROVED
business_tests: NOT_RUN             # 未实际执行就必须保持
standard: spec-workspace-standard v2.0
semver: 1.0.0
revision: r001
owner: <需求负责人>
created: <YYYY-MM-DD>
```

## 一页范围

- 业务目标：<一句可度量的话>
- 本轮包含：<3–6 条>
- 本轮不含：<3–6 条，写清越界请求怎么处理>
- 关键角色：<角色 → 能看到什么 → 能做什么>
- 输入材料：<文件 → 版本 → 覆盖了哪些规格>
- 未读取材料：<文件 → 原因>

## 基线清单

| 规格 | 文件 | 条目数 | 状态 |
|---|---|---|---|
| 业务边界 | specs/01-business.md | | 候选 |
| IPO | specs/02-ipo.md | | 候选 |
| SOP | specs/03-sop.md | | 候选 |
| 规则与状态机 | specs/04-rules.md | | 候选 |
| 数据与导入 | specs/05-data.md | | 候选 |
| 架构与接口 | specs/06-architecture.md | | 候选 |
| 页面与输出 | specs/07-ui.md | | 候选 |
| 权限安全 | specs/08-security.md | | 候选 |
| 验收 | specs/09-acceptance.md | | 候选 |
| 追踪 | specs/10-traceability.md | | 候选 |

## 下一步

- 先确认的基线：<文件 + 为什么它先>
- 阻断项数量：<n>（见 open-questions.md）
