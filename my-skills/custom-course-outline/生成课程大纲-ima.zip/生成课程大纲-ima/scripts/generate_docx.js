/**
 * generate_docx.js — 「生成课程大纲-ima」技能的 Word 生成器
 *
 * 排版完全复刻 `assets/standard_template.docx`（《AI场景创新培训_课程大纲》）。
 * 所有字号/颜色/对齐/段距/底色均从模板 docx 实测而来，不要凭印象修改。
 *
 * ============ 实测样式表（half-points，1pt = 2 hp） ============
 *
 *   主标题            楷体  30pt(60)   #1F3864 深蓝  bold   center  before480 after100
 *   副标题            楷体  18pt(36)   #2E75B6 蓝    bold   center  before480 after80
 *   课程大纲行        楷体  14pt(28)   #666666 灰           center  before60  after360
 *
 *   章节标题(一二三)  楷体  14pt(28)   #2E75B6 蓝    bold   默认    before360 after120
 *   模块说明段        楷体  14pt(28)   #444444               默认    before80  after120
 *   列表项            楷体  14pt(28)   #333333               默认    before40  after40
 *   空行段            -     -          -                     -       before60  after60
 *
 *   表头格底色 = #2E75B6 蓝；表头字 = #FFFFFF 白，居中
 *   标签格底色 = #DEEAF1 浅蓝；标签字 = #1F3864 深蓝（9.5pt）
 *   主题格底色 = #F2F2F2 浅灰；主题字 = #2E75B6 蓝（9.5pt），左对齐
 *   值格底色   = #FFFFFF 白；值字 = #333333（9.5pt），左对齐
 *   组合表方案格底色：行1=DEEAF1浅蓝, 行2=FCE4D6浅橙, 行3=FFFFFF白（交替）
 *
 *   ★ 模块表 detail 列要点对齐（关键，与模板一致）：
 *     每个单元格内多条要点用 <w:br/> 软换行分隔，每条要点前置「· 」前缀。
 *     generate_docx.js 通过 buildDetailRuns() 自动拆分：
 *       输入 "· A · B · C"  →  渲染为三行软换行的 "· A" / "· B" / "· C"
 *     切勿把多条要点拼成一坨单段长文本（视觉会糊成一片）。
 *
 *   表格边框 single sz=4 color=auto；表格总宽 9360 dxa
 *   页边距 1440 twips（上下左右）
 *
 * 输入：JSON 文件
 * 输出：.docx 文件
 * 用法：node generate_docx.js <input.json> <output.docx>
 */

const fs = require("fs");
const path = require("path");
const {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  Header,
  Footer,
  AlignmentType,
  BorderStyle,
  WidthType,
  ShadingType,
  VerticalAlign,
  PageNumber,
  LevelFormat,
} = require("docx");

// ============ 排版常量（实测复刻 standard_template.docx） ============
const FONT = "楷体";

// 颜色
const COLOR_TITLE = "1F3864";   // 深蓝（主标题、表头标签）
const COLOR_BLUE = "2E75B6";    // 蓝（副标题、章节标题、主题列）
const COLOR_GRAY = "666666";    // 灰（课程大纲行）
const COLOR_TEXT = "333333";    // 深灰（列表、值格）
const COLOR_NOTE = "444444";    // 说明文字
const COLOR_WHITE = "FFFFFF";   // 表头字
const COLOR_HEADER_BG = "2E75B6"; // 表头底色
const COLOR_LABEL_BG = "DEEAF1";  // 标签格底色（浅蓝）
const COLOR_THEME_BG = "F2F2F2";  // 主题格底色（浅灰）
const COLOR_VALUE_BG = "FFFFFF";  // 值格底色
const COLOR_ALT_BG = "FCE4D6";    // 组合表第二行底色（浅橙）

// 字号（half-points）
const SZ_TITLE = 60;      // 30pt 主标题
const SZ_SUBTITLE = 36;   // 18pt 副标题
const SZ_COVER3 = 28;     // 14pt 课程大纲行
const SZ_HEADING = 28;    // 14pt 章节标题
const SZ_BODY = 28;       // 14pt 正文/列表
const SZ_CELL = 19;       // 9.5pt 单元格
const SZ_HEADER = 18;     // 9pt 页眉页脚

// ============ 输入 JSON Schema ============
/**
 * {
 *   "title": "课程主标题",
 *   "subtitle": "——副标题",
 *   "coverLine3": "课  程  大  纲",          // 可选
 *   "courseName": "页眉用的完整课程名",
 *   "basicInfo": [                          // 4列2行
 *     {"label1":"【课程时长】","value1":"...","label2":"【课程对象】","value2":"..."},
 *     {"label1":"【授课形式】","value1":"...","label2":"【课程说明】","value2":"..."}
 *   ],
 *   "learningGoals": ["..."],
 *   "modulesIntro": "本课程包含N大模块...",
 *   "modules": [
 *     {"module":"模块一 ...","theme":"主题","detail":"· 要点1· 要点2"},
 *     {"module":"","theme":"同模块下主题","detail":"..."}   // module 留空 = 同组（跨行合并）
 *   ],
 *   "combos": [{"plan":"方案","includes":"模块","duration":"时长"}],
 *   "features": ["🗺 ..."],
 *   "outcomes": ["..."],      // 可选
 *   "prep": ["..."],          // 可选
 *   "lecturer": "李家贵",
 *   "lecturerTitle": "西安交大数字经济学院首席科学家"
 * }
 */

// ============ 通用样式构造 ============
function runProps(extra = {}) {
  return {
    font: { name: FONT, hint: "eastAsia" },
    ...extra,
  };
}

// 章节标题段落（一二三、xxx）
function headingPara(text) {
  return new Paragraph({
    spacing: { before: 360, after: 120 },
    children: [
      new TextRun(
        runProps({
          text,
          size: SZ_HEADING,
          color: COLOR_BLUE,
          bold: true,
        })
      ),
    ],
  });
}

// 模块说明段（章节标题下方的一句话）
function notePara(text) {
  return new Paragraph({
    spacing: { before: 80, after: 120 },
    children: [
      new TextRun(
        runProps({
          text,
          size: SZ_BODY,
          color: COLOR_NOTE,
        })
      ),
    ],
  });
}

// 列表项段落
function bulletPara(text) {
  return new Paragraph({
    spacing: { before: 40, after: 40 },
    numbering: { reference: "outline-bullets", level: 0 },
    children: [
      new TextRun(
        runProps({
          text,
          size: SZ_BODY,
          color: COLOR_TEXT,
        })
      ),
    ],
  });
}

// 空行段（间距用）
function gapPara(before = 60, after = 60) {
  return new Paragraph({
    spacing: { before, after },
    children: [new TextRun(runProps({ text: "", size: SZ_BODY }))],
  });
}

// ============ 表格构造 ============
const BORDER = { style: BorderStyle.SINGLE, size: 4, color: "auto" };
const CELL_BORDERS = {
  top: BORDER,
  bottom: BORDER,
  left: BORDER,
  right: BORDER,
};

// 把 detail 文本按「·」拆成多段，每段前加「· 」前缀；
// 第一段为正常 TextRun，后续每段用 break:1 在前面插入 <w:br/>，复刻模板软换行效果。
function buildDetailRuns(text, size, color) {
  // 兼容「· A· B」与「A· B」两种输入
  // 先把所有 · 拆开，过滤空段
  const parts = String(text || "")
    .split(/·/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  if (parts.length === 0) {
    return [new TextRun(runProps({ text: String(text || ""), size, color }))];
  }

  const runs = [];
  parts.forEach((p, idx) => {
    if (idx === 0) {
      runs.push(new TextRun(runProps({ text: `· ${p}`, size, color })));
    } else {
      // break: 1 会在该 run 前插入一个 <w:br/>，实现单元格内软换行
      runs.push(
        new TextRun(
          runProps({
            text: `· ${p}`,
            size,
            color,
            break: 1,
          })
        )
      );
    }
  });
  return runs;
}

// 通用单元格构造
// opts.multiline=true 时按「·」拆成多行（软换行），用于 detail 列；
// 其他单元格保持单段。
function makeCell(text, opts = {}) {
  const {
    width,
    shading = null,
    color = COLOR_TEXT,
    bold = false,
    size = SZ_CELL,
    align = "left",
    multiline = false,
  } = opts;

  let runs;
  if (multiline) {
    runs = buildDetailRuns(text, size, color);
  } else {
    runs = [
      new TextRun(
        runProps({
          text,
          size,
          color,
          bold,
        })
      ),
    ];
  }

  const cellOpts = {
    width: { size: width, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    verticalAlign: VerticalAlign.CENTER,
    borders: CELL_BORDERS,
    children: [
      new Paragraph({
        alignment: AlignmentType[align.toUpperCase()] || AlignmentType.LEFT,
        children: runs,
      }),
    ],
  };
  if (shading) {
    cellOpts.shading = { fill: shading, type: ShadingType.CLEAR };
  }
  return new TableCell(cellOpts);
}

// 跨行单元格（用于模块表第一列）
function makeRowSpanCell(text, rowSpan, width) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    verticalAlign: VerticalAlign.CENTER,
    borders: CELL_BORDERS,
    rowSpan,
    shading: { fill: COLOR_LABEL_BG, type: ShadingType.CLEAR },
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun(
            runProps({
              text,
              size: SZ_CELL,
              color: COLOR_TITLE,
              bold: true,
            })
          ),
        ],
      }),
    ],
  });
}

// 课程基本信息表（4列2行）
function basicInfoTable(rows) {
  const colW = [1600, 3080, 1600, 3080];
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: colW,
    rows: rows.map(
      (r) =>
        new TableRow({
          children: [
            makeCell(r.label1, { width: colW[0], shading: COLOR_LABEL_BG, color: COLOR_TITLE, bold: true }),
            makeCell(r.value1, { width: colW[1], shading: COLOR_VALUE_BG, color: COLOR_TEXT }),
            makeCell(r.label2, { width: colW[2], shading: COLOR_LABEL_BG, color: COLOR_TITLE, bold: true }),
            makeCell(r.value2, { width: colW[3], shading: COLOR_VALUE_BG, color: COLOR_TEXT }),
          ],
        })
    ),
  });
}

// 模块结构表（3列，首列跨行合并）
function modulesTable(modules) {
  const colW = [2564, 2132, 4664];
  const rows = [];

  // 表头
  rows.push(
    new TableRow({
      children: [
        makeCell("模块", { width: colW[0], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
        makeCell("主题", { width: colW[1], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
        makeCell("主题细节内容", { width: colW[2], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
      ],
    })
  );

  // 按模块名分组（module 字段为空表示同组）
  let i = 0;
  while (i < modules.length) {
    const groupName = modules[i].module;
    let end = i;
    if (groupName) {
      for (let k = i + 1; k < modules.length; k++) {
        if (modules[k].module === "" || modules[k].module === groupName) {
          end = k;
        } else {
          break;
        }
      }
    }
    const groupSize = end - i + 1;

    for (let k = i; k <= end; k++) {
      const children = [];
      if (k === i && groupName) {
        children.push(makeRowSpanCell(groupName, groupSize, colW[0]));
      } else if (k === i && !groupName) {
        // 没有 module 名，单独成行
        children.push(makeCell("", { width: colW[0], shading: COLOR_LABEL_BG }));
      }
      children.push(
        makeCell(modules[k].theme, { width: colW[1], shading: COLOR_THEME_BG, color: COLOR_BLUE, align: "left" }),
        makeCell(modules[k].detail, {
          width: colW[2],
          shading: COLOR_VALUE_BG,
          color: COLOR_TEXT,
          align: "left",
          multiline: true,
        })
      );
      rows.push(new TableRow({ children }));
    }
    i = end + 1;
  }

  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: colW,
    rows,
  });
}

// 模块组合建议表（3列，方案列交替底色）
function combosTable(combos) {
  const colW = [2200, 4400, 2760];
  const altShadings = [COLOR_LABEL_BG, COLOR_ALT_BG, COLOR_VALUE_BG];

  const rows = [];
  // 表头
  rows.push(
    new TableRow({
      children: [
        makeCell("组合方案", { width: colW[0], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
        makeCell("包含模块", { width: colW[1], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
        makeCell("建议时长", { width: colW[2], shading: COLOR_HEADER_BG, color: COLOR_WHITE, bold: true, align: "center" }),
      ],
    })
  );

  combos.forEach((c, idx) => {
    const shd = altShadings[idx % altShadings.length];
    rows.push(
      new TableRow({
        children: [
          makeCell(c.plan, { width: colW[0], shading: shd, color: COLOR_TITLE, bold: true }),
          makeCell(c.includes, { width: colW[1], shading: COLOR_VALUE_BG, color: COLOR_TEXT }),
          makeCell(c.duration, { width: colW[2], shading: COLOR_VALUE_BG, color: COLOR_TEXT, align: "center" }),
        ],
      })
    );
  });

  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: colW,
    rows,
  });
}

// ============ 主构建函数 ============
function buildDocument(data) {
  const lecturer = data.lecturer || "李家贵";
  const lecturerTitle = data.lecturerTitle || "西安交大数字经济学院首席科学家";
  const coverLine3 = data.coverLine3 || "课  程  大  纲";
  const courseName = data.courseName || data.title;

  const children = [];

  // ====== 封面三行（居中，与模板一致） ======
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 100 },
      children: [
        new TextRun(
          runProps({
            text: data.title,
            size: SZ_TITLE,
            color: COLOR_TITLE,
            bold: true,
          })
        ),
      ],
    })
  );
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 480, after: 80 },
      children: [
        new TextRun(
          runProps({
            text: data.subtitle,
            size: SZ_SUBTITLE,
            color: COLOR_BLUE,
            bold: true,
          })
        ),
      ],
    })
  );
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 360 },
      children: [
        new TextRun(
          runProps({
            text: coverLine3,
            size: SZ_COVER3,
            color: COLOR_GRAY,
          })
        ),
      ],
    })
  );

  // 空行
  children.push(gapPara(0, 360));

  // ====== 一、课程基本信息 ======
  children.push(headingPara("课程基本信息"));
  children.push(basicInfoTable(data.basicInfo));
  children.push(gapPara(60, 60));

  // ====== 二、学习目标 ======
  children.push(headingPara("学习目标"));
  for (const g of data.learningGoals) {
    children.push(bulletPara(g));
  }
  children.push(gapPara(60, 60));

  // ====== 三、课程模块结构 ======
  children.push(headingPara("课程模块结构"));
  if (data.modulesIntro) {
    children.push(notePara(data.modulesIntro));
  }
  children.push(gapPara(0, 60));
  children.push(modulesTable(data.modules));
  children.push(gapPara(60, 60));

  // ====== 四、模块组合建议 ======
  if (data.combos && data.combos.length) {
    children.push(headingPara("模块组合建议"));
    children.push(combosTable(data.combos));
    children.push(gapPara(60, 60));
  }

  // ====== 五、课程特色 ======
  children.push(headingPara("课程特色"));
  for (const f of data.features) {
    children.push(bulletPara(f));
  }

  // ====== 六、课程成果（可选） ======
  if (data.outcomes && data.outcomes.length) {
    children.push(headingPara("课程成果"));
    for (const o of data.outcomes) {
      children.push(bulletPara(o));
    }
  }

  // ====== 七、课前准备与实施建议（可选） ======
  if (data.prep && data.prep.length) {
    children.push(headingPara("课前准备与实施建议"));
    for (const item of data.prep) {
      children.push(bulletPara(item));
    }
  }

  // ====== 讲师署名 ======
  children.push(gapPara(360, 0));
  children.push(
    new Paragraph({
      spacing: { before: 40, after: 40 },
      children: [
        new TextRun(
          runProps({
            text: `讲师：${lecturer}`,
            size: SZ_BODY,
            color: COLOR_TITLE,
            bold: true,
          })
        ),
      ],
    })
  );
  children.push(
    new Paragraph({
      spacing: { before: 40, after: 40 },
      children: [
        new TextRun(
          runProps({
            text: lecturerTitle,
            size: SZ_BODY,
            color: COLOR_TEXT,
          })
        ),
      ],
    })
  );

  // ====== 文档构建 ======
  const doc = new Document({
    creator: lecturer,
    title: courseName,
    styles: {
      default: {
        document: {
          run: { font: { name: FONT, hint: "eastAsia" }, size: SZ_BODY, color: COLOR_TEXT },
        },
      },
    },
    numbering: {
      config: [
        {
          reference: "outline-bullets",
          levels: [
            {
              level: 0,
              format: LevelFormat.BULLET,
              text: "·",
              alignment: AlignmentType.LEFT,
              style: {
                paragraph: { indent: { left: 360, hanging: 200 } },
                run: { font: { name: FONT }, size: SZ_BODY, color: COLOR_TEXT },
              },
            },
          ],
        },
      ],
    },
    sections: [
      {
        properties: {
          page: {
            size: { width: 11906, height: 16838 }, // A4
            margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
          },
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: courseName,
                    font: { name: FONT, hint: "eastAsia" },
                    size: SZ_HEADER,
                    color: "808080",
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: "第 ",
                    font: { name: FONT, hint: "eastAsia" },
                    size: SZ_HEADER,
                    color: "808080",
                  }),
                  new TextRun({ children: [PageNumber.CURRENT], size: SZ_HEADER, color: "808080" }),
                  new TextRun({
                    text: " 页",
                    font: { name: FONT, hint: "eastAsia" },
                    size: SZ_HEADER,
                    color: "808080",
                  }),
                ],
              }),
            ],
          }),
        },
        children,
      },
    ],
  });

  return doc;
}

// ============ CLI ============
function main() {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.error("用法: node generate_docx.js <input.json> <output.docx>");
    process.exit(1);
  }
  const inputPath = path.resolve(args[0]);
  const outputPath = path.resolve(args[1]);

  if (!fs.existsSync(inputPath)) {
    console.error(`输入文件不存在: ${inputPath}`);
    process.exit(1);
  }

  const data = JSON.parse(fs.readFileSync(inputPath, "utf8"));
  const doc = buildDocument(data);

  Packer.toBuffer(doc).then((buffer) => {
    fs.writeFileSync(outputPath, buffer);
    console.log(`✅ 已生成: ${outputPath}`);
    console.log(`   排版完全复刻 standard_template.docx（楷体 / 主标题30pt深蓝 / 章节14pt蓝 / 单元格9.5pt）`);
  });
}

main();
